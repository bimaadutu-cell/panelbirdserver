FOLDER ASSETS
=============
Letakkan gambar berikut di folder ini (boleh ganti kapan saja):

- welcome.jpg       : Banner halaman sambutan / /start
- panel.jpg         : Ditampilkan setelah panel Pterodactyl berhasil dibuat
- bimzcreated.jpg   : Ditampilkan pada menu BimzCreated (APK CPanel)
- apkbug.jpg        : Ditampilkan pada menu APK BUG
- bonus.jpg         : Ditampilkan pada menu Bonus Harian
- profile.jpg       : Ditampilkan pada menu Profil
- announcement.jpg  : Ditampilkan pada menu Pengumuman
- qris.jpg          : Gambar QRIS pembayaran
- logo.jpg          : Logo toko
- banner.jpg        : Banner umum

Bot akan otomatis mendeteksi file yang ada. Bila salah satu tidak ada,
bot tetap berjalan tanpa gambar tersebut. Tidak perlu mengedit source
code — cukup taruh/timpa file di folder ini.
