const cron = require("node-cron");
const panelCfg = require("../config/panel");
const panelCheckerCfg = require("../config/panelChecker");
const analyzer = require("../services/panel/analyzer");
const orderSvc = require("../services/order/orderService");
const db = require("../database/db");
const logger = require("../utils/logger");

function start() {
  // Auto delete panel expired
  cron.schedule(panelCfg.autoDeleteCron || "*/10 * * * *", async () => {
    try {
      const n = await orderSvc.deleteExpiredPanels();
      if (n) logger.info(`[scheduler] deleted ${n} expired panels`);
    } catch (e) { logger.error("scheduler delete err:", e.message); }
  });

  // Expire invoices stale tiap menit
  cron.schedule("*/1 * * * *", () => {
    try { db.expireStaleInvoices(); } catch {}
  });

  // Panel Health Check
  if (panelCheckerCfg.enabled) {
    const interval = panelCheckerCfg.intervalMinutes || 5;
    cron.schedule(`*/${interval} * * * *`, async () => {
      try {
        const results = await analyzer.checkAll(panelCfg.servers);
        const down = results.filter(r => !r.online);
        if (down.length > 0 && panelCheckerCfg.notifyAdminOnDown) {
          // Notify logic could be added here via bot.notifyAdmin
          logger.warn(`[scheduler] ${down.length} panels are DOWN: ${down.map(d => d.key).join(", ")}`);
        }
      } catch (e) { logger.error("scheduler health check err:", e.message); }
    });
  }

  logger.success("Scheduler started (auto-delete + invoice expiry + health check)");
}

module.exports = { start };
