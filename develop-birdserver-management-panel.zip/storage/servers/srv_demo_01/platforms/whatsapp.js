const {
  default: makeWASocket, useMultiFileAuthState, DisconnectReason,
  fetchLatestBaileysVersion, downloadMediaMessage, Browsers,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const path = require("path");
const fs = require("fs");
const qrcode = require("qrcode-terminal");
const { handleMessage } = require("../handlers/flow");
const owners = require("../config/owner");
const db = require("../database/db");
const logger = require("../utils/logger");

const SESSION_DIR = path.join(__dirname, "..", "sessions", "wa");
let sock = null;

function isAdmin(jid) { return owners.some((o) => o.waJid === jid); }

function makeCtx(jid) {
  return {
    platform: "whatsapp",
    chatId: jid,
    userJid: jid,
    text: "",
    isImage: false,
    imageBuffer: null,
    callbackData: null,
    isAdmin: isAdmin(jid),
    reply: async (text, opts = {}) => {
      const msg = { text };
      if (opts.buttons?.length) {
        // WhatsApp interactive buttons kadang tak konsisten — fallback ke daftar teks
        msg.text = `${text}\n\n` + opts.buttons.map((b, i) => `${i + 1}. ${b.text}  → ketik ${b.id}`).join("\n");
      }
      if (opts.image && fs.existsSync(opts.image)) {
        return sock.sendMessage(jid, { image: fs.readFileSync(opts.image), caption: msg.text });
      }
      return sock.sendMessage(jid, msg);
    },
    notifyAdmin: async (m) => {
      for (const o of owners) if (o.waJid) await sock.sendMessage(o.waJid, { text: m }).catch(() => {});
    },
    broadcast: async (user, m) => {
      if (user.platform === "whatsapp") await sock.sendMessage(user.chat_id, { text: m });
    },
  };
}

async function start() {
  if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion().catch(() => ({ version: [2, 3000, 0] }));
  sock = makeWASocket({
    version, auth: state, printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    browser: Browsers.macOS("Chrome"),
    generateHighQualityLinkPreview: false,
  });

  sock.ev.on("creds.update", saveCreds);
  sock.ev.on("connection.update", (u) => {
    if (u.qr) { logger.info("Scan QR WhatsApp:"); qrcode.generate(u.qr, { small: true }); }
    if (u.connection === "open") logger.success("WhatsApp connected");
    if (u.connection === "close") {
      const code = u.lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) start();
      else logger.warn("WA logged out — hapus folder sessions/wa untuk pair ulang.");
    }
  });

  sock.ev.on("messages.upsert", async ({ messages }) => {
    for (const m of messages) {
      if (!m.message || m.key.fromMe) continue;
      const jid = m.key.remoteJid;
      if (jid.endsWith("@g.us")) continue; // ignore group
      const ctx = makeCtx(jid);
      const t = m.message.conversation || m.message.extendedTextMessage?.text || m.message.imageMessage?.caption || "";
      ctx.text = t;
      // Parse tombol WA (user reply "pick_admin:..." dsb)
      if (/^[a-z_]+:/i.test(t.trim())) ctx.callbackData = t.trim();
      if (m.message.imageMessage) {
        try {
          ctx.isImage = true;
          ctx.imageBuffer = await downloadMediaMessage(m, "buffer", {});
        } catch (e) { logger.warn("WA image dl:", e.message); }
      }
      db.upsertUser({ platform: "whatsapp", chatId: jid, jid });
      handleMessage(ctx).catch((e) => logger.error("WA handler:", e.message));
    }
  });

  logger.success("WhatsApp service started");
}

module.exports = { start };
