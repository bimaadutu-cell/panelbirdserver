// ==============================================
// PLATFORM TELEGRAM (V3.2)
// ==============================================
// - Halaman SAMBUTAN dengan banner welcome.jpg + tombol
//   "📖 Lihat Ketentuan" & "✅ Saya Mengerti".
// - User TIDAK bisa masuk menu utama sebelum menekan
//   "Saya Mengerti" DAN lolos verifikasi Join Channel + Grup.
// - Menu inline keyboard + editMessageText.
// - Kontak WhatsApp/Telegram dari config/contact.js.
// - Gambar dari config/images.js.
// ==============================================
const TelegramBot = require("node-telegram-bot-api");
const axios = require("axios");
const fs = require("fs");
const { handleMessage } = require("../handlers/flow");
const menu = require("../handlers/menu");
const owners = require("../config/owner");
const panelCfg = require("../config/panel");
const pricesCfg = require("../config/prices");
const bimzCfg = require("../config/bimzcreated");
const tgCfg = require("../config/telegram");
const contactCfg = require("../config/contact");
const images = require("../config/images");
const announcementCfg = require("../config/announcement");
const db = require("../database/db");
const logger = require("../utils/logger");
const mediaHelper = require("../helpers/media");
const { checkMembership, deniedKeyboard } = require("../middlewares/verifyJoin");

let bot = null;

function isAdmin(chatId) {
  return owners.some((o) => String(o.telegramChatId) === String(chatId));
}

/** Konversi buttons cross-platform (flow.js) → inline_keyboard TG. Support url. */
function toInlineKeyboard(buttons) {
  return {
    inline_keyboard: buttons.map((b) => [
      b.url ? { text: b.text, url: b.url } : { text: b.text, callback_data: b.id },
    ]),
  };
}

async function safeEdit(chatId, messageId, text, reply_markup) {
  try {
    return await bot.editMessageText(text, {
      chat_id: chatId, message_id: messageId, parse_mode: "Markdown",
      reply_markup, disable_web_page_preview: true,
    });
  } catch (e) {
    if (/message is not modified/i.test(e.message)) return;
    return bot.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup });
  }
}

function makeCtx(chatId, from) {
  return {
    platform: "telegram",
    chatId: String(chatId),
    userJid: from?.username || String(from?.id),
    text: "", isImage: false, imageBuffer: null, callbackData: null,
    isAdmin: isAdmin(chatId),
    reply: async (text, opts = {}) => {
      const options = { parse_mode: "Markdown" };
      if (opts.buttons?.length) options.reply_markup = toInlineKeyboard(opts.buttons);
      
      if (opts.image && fs.existsSync(opts.image)) {
        const type = mediaHelper.getMediaType(opts.image);
        if (type === "video") {
          return bot.sendVideo(chatId, opts.image, { caption: text, ...options });
        } else if (type === "gif") {
          return bot.sendAnimation(chatId, opts.image, { caption: text, ...options });
        }
        return bot.sendPhoto(chatId, opts.image, { caption: text, ...options });
      }
      return bot.sendMessage(chatId, text, options);
    },
    editMessage: async (messageId, text, opts = {}) => {
      const options = { chat_id: chatId, message_id: messageId, parse_mode: "Markdown" };
      if (opts.buttons?.length) options.reply_markup = toInlineKeyboard(opts.buttons);
      try { return await bot.editMessageText(text, options); }
      catch (e) { if (!/message is not modified/i.test(e.message)) throw e; }
    },
    sendDocument: async (filePath, fileName) => {
      return bot.sendDocument(chatId, filePath, {}, { filename: fileName || "file.zip", contentType: "application/zip" });
    },
    notifyAdmin: async (msg) => {
      for (const o of owners) if (o.telegramChatId)
        await bot.sendMessage(o.telegramChatId, msg).catch(() => {});
    },
    broadcast: async (user, msg) => {
      if (user.platform === "telegram") await bot.sendMessage(user.chat_id, msg);
    },
  };
}

// ==============================================
// HALAMAN SAMBUTAN + KETENTUAN
// ==============================================
const WELCOME_TEXT =
  `👋 *Selamat Datang di Bimz Digital Store*\n\n` +
  `Terima kasih telah menggunakan layanan kami.\n\n` +
  `Bot ini merupakan *Digital Store otomatis* yang menyediakan berbagai layanan:\n\n` +
  `🖥️ Panel Pterodactyl\n` +
  `📱 BimzCreated (APK CPanel)\n` +
  `🐛 APK BUG\n` +
  `🎁 Bonus Harian\n` +
  `👤 Profil\n` +
  `📜 Riwayat Order\n` +
  `📢 Pengumuman\n\n` +
  `━━━━━━━━━━━━━━━━━━\n` +
  `⚠️ Sebelum melakukan pemesanan, harap membaca seluruh *syarat dan ketentuan* yang berlaku.\n\n` +
  `Dengan menggunakan bot ini, Anda dianggap telah memahami seluruh informasi yang tersedia.\n` +
  `━━━━━━━━━━━━━━━━━━`;

const TERMS_TEXT =
  `📖 *SYARAT & KETENTUAN*\n\n` +
  `1. Semua transaksi bersifat *final* — tidak dapat dibatalkan setelah panel/produk terkirim.\n` +
  `2. Bukti pembayaran WAJIB *jelas, asli,* dan sesuai invoice. Bot menolak bukti palsu / berbeda nominal / berbeda merchant.\n` +
  `3. Verifikasi otomatis menggunakan OCR — pastikan foto tidak buram.\n` +
  `4. Panel Pterodactyl dibuat otomatis setelah pembayaran valid.\n` +
  `5. BimzCreated (APK CPanel) akan diaktivasi manual oleh admin setelah pembayaran valid.\n` +
  `6. APK BUG *tidak menggunakan pembayaran otomatis*. Pemesanan dilanjutkan langsung ke Yanzz.\n` +
  `7. User dilarang mengirim bukti pembayaran yang sama lebih dari 1 invoice.\n` +
  `8. Pelanggaran ketentuan dapat menyebabkan akun di-*banned* tanpa pengembalian dana.\n` +
  `9. Data akun (username / password) yang Anda isi menjadi tanggung jawab Anda sendiri.\n` +
  `10. Dengan menekan *Saya Mengerti*, Anda dianggap telah membaca dan menyetujui seluruh ketentuan.`;

function welcomeKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "📖 Lihat Ketentuan", callback_data: "welcome:terms" }],
      [{ text: "✅ Saya Mengerti", callback_data: "welcome:agree" }],
    ],
  };
}
function termsKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "✅ Saya Mengerti", callback_data: "welcome:agree" }],
      [{ text: "⬅ Kembali", callback_data: "welcome:back" }],
    ],
  };
}

async function sendWelcome(chatId) {
  const media = mediaHelper.getMediaPath("welcome");
  if (media) {
    const options = { caption: WELCOME_TEXT, parse_mode: "Markdown", reply_markup: welcomeKeyboard() };
    if (media.type === "video") return bot.sendVideo(chatId, media.path, options);
    if (media.type === "gif") return bot.sendAnimation(chatId, media.path, options);
    return bot.sendPhoto(chatId, media.path, options);
  }
  return bot.sendMessage(chatId, WELCOME_TEXT, {
    parse_mode: "Markdown", reply_markup: welcomeKeyboard(),
  });
}

async function sendDenied(chatId, messageId) {
  const text = tgCfg.messages.denied;
  const kb = deniedKeyboard();
  if (messageId) return safeEdit(chatId, messageId, text, kb);
  return bot.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: kb });
}

async function sendHome(chatId, messageId) {
  return safeEdit(chatId, messageId, menu.txtHome(), menu.kbMain());
}

async function sendHomeFresh(chatId) {
  const media = mediaHelper.getMediaPath("welcome");
  if (media) {
    const options = { caption: menu.txtHome(), parse_mode: "Markdown", reply_markup: menu.kbMain() };
    if (media.type === "video") return bot.sendVideo(chatId, media.path, options);
    if (media.type === "gif") return bot.sendAnimation(chatId, media.path, options);
    return bot.sendPhoto(chatId, media.path, options);
  }
  return bot.sendMessage(chatId, menu.txtHome(), {
    parse_mode: "Markdown", reply_markup: menu.kbMain(),
  });
}

// Menu dengan gambar khusus tiap section
async function sendMenuSection(chatId, messageId, kind) {
  const kindKey = kind.replace("m:", "");
  const map = {
    "panel":       [menu.txtPanelDev(),        menu.kbPanelDev()],
    "bimz":        [menu.txtBimz(),            menu.kbBimz()],
    "apk":         [menu.txtApk(),             menu.kbApk()],
    "topup":       [menu.txtTopUp(),           menu.kbBack()],
    "bonus":       [menu.txtBonus(String(chatId), "telegram"), menu.kbBonus()],
    "riwayat":     [menu.txtRiwayat(String(chatId)), menu.kbBack()],
    "profil":      [menu.txtProfil(String(chatId), "telegram"), menu.kbBack()],
    "pengumuman":  [menu.txtPengumuman(),      menu.kbBack()],
    "support":     [menu.txtSupport(),         menu.kbSupport ? menu.kbSupport() : menu.kbBack()],
    "pengaturan":  [menu.txtPengaturan(),      menu.kbBack()],
  };
  const entry = map[kindKey];
  if (!entry) return;
  const [text, kb] = entry;
  
  const media = mediaHelper.getMediaPath(kindKey === "panel" ? "panel" : (kindKey === "apk" ? "apkbug" : kindKey));
  if (media) {
    // hapus msg lama & kirim media baru
    await bot.deleteMessage(chatId, messageId).catch(() => {});
    const options = { caption: text, parse_mode: "Markdown", reply_markup: kb };
    if (media.type === "video") return bot.sendVideo(chatId, media.path, options);
    if (media.type === "gif") return bot.sendAnimation(chatId, media.path, options);
    return bot.sendPhoto(chatId, media.path, options);
  }
  return safeEdit(chatId, messageId, text, kb);
}

async function routeMenu(chatId, messageId, data, from) {
  if (data === "m:home") return sendHome(chatId, messageId);
  if (data.startsWith("m:")) return sendMenuSection(chatId, messageId, data);

  // Bonus claim inline
  if (data === "b:bonus:claim") {
    const ctx = makeCtx(chatId, from);
    await require("../handlers/flow").claimBonus(ctx);
    return sendMenuSection(chatId, messageId, "m:bonus").catch(() => {});
  }

  if (data.startsWith("p:srv:")) {
    const key = data.split(":")[2];
    const s = panelCfg.servers.find((x) => x.key === key);
    if (!s) return safeEdit(chatId, messageId, "Server tidak ditemukan.", menu.kbBack("m:panel"));
    return safeEdit(chatId, messageId, menu.txtPanelRoles(s), menu.kbPanelRoles(key));
  }
  if (data.startsWith("p:role:")) {
    const [, , key, role] = data.split(":");
    const s = panelCfg.servers.find((x) => x.key === key);
    if (!s || !pricesCfg[key]?.[role])
      return safeEdit(chatId, messageId, "Harga tidak tersedia.", menu.kbBack("m:panel"));
    return safeEdit(chatId, messageId, menu.txtPanelSizes(s, role), menu.kbPanelSizes(key, role));
  }
  if (data.startsWith("p:size:") || data.startsWith("b:pkg:") || data.startsWith("a:item:")) {
    const ctx = makeCtx(chatId, from);
    if (data.startsWith("p:size:")) {
      const [, , key, role, size] = data.split(":");
      ctx.callbackData = `size:${key}:${role}:${size}`;
    } else if (data.startsWith("b:pkg:")) {
      const [, , k] = data.split(":");
      const p = bimzCfg.packages[k];
      if (!p) return safeEdit(chatId, messageId, "Paket tidak ditemukan.", menu.kbBack("m:bimz"));
      return safeEdit(chatId, messageId, menu.txtBimzDetail(k), menu.kbBimzDetail(k));
    } else if (data.startsWith("a:item:")) {
      ctx.callbackData = `apkitem:${data.split(":")[2]}`;
    }
    await handleMessage(ctx);
    return;
  }
  if (data.startsWith("b:buy:")) {
    const role = data.split(":")[2];
    const ctx = makeCtx(chatId, from);
    ctx.callbackData = `bimzbuy:${role}`;
    await handleMessage(ctx);
    return;
  }
}

// ==============================================
// START
// ==============================================
async function start() {
  const token = (process.env.TELEGRAM_BOT_TOKEN || "").trim();
  if (!token) { logger.warn("TELEGRAM_BOT_TOKEN kosong — skip platform Telegram."); return; }

  bot = new TelegramBot(token, { polling: true });
  try {
    const me = await bot.getMe();
    logger.success(`Telegram: @${me.username}`);
  } catch (e) {
    logger.error("Telegram connect fail:", e.message); return;
  }

  bot.on("message", async (m) => {
    try {
      db.upsertUser({
        platform: "telegram", chatId: String(m.chat.id),
        name: m.from?.first_name, username: m.from?.username,
      });

      const text = (m.text || "").trim().toLowerCase();
      const isStart = /^\/start$|^start$|^menu$|^p$|^halo$|^hai$|^hi$/.test(text);

      if (isStart) {
        const u = db.getUser(String(m.chat.id), "telegram") || {};
        // Belum menyetujui ketentuan → tampilkan halaman sambutan
        if (!u.terms_accepted_at) return sendWelcome(m.chat.id);
        // Verifikasi Join
        const chk = await checkMembership(bot, m.from.id);
        if (!chk.ok) return sendDenied(m.chat.id);
        return sendHomeFresh(m.chat.id);
      }

      const ctx = makeCtx(m.chat.id, m.from);
      ctx.text = m.text || m.caption || "";
      if (m.photo?.length) {
        ctx.isImage = true;
        const link = await bot.getFileLink(m.photo[m.photo.length - 1].file_id);
        const r = await axios.get(link, { responseType: "arraybuffer" });
        ctx.imageBuffer = Buffer.from(r.data);
      }
      await handleMessage(ctx);
    } catch (e) { logger.error("TG msg:", e.message); }
  });

  bot.on("callback_query", async (q) => {
    try {
      await bot.answerCallbackQuery(q.id).catch(() => {});
      const chatId = q.message.chat.id;
      const messageId = q.message.message_id;
      const data = q.data || "";

      // ==== Welcome / terms ====
      if (data === "welcome:terms") {
        return safeEdit(chatId, messageId, TERMS_TEXT, termsKeyboard()).catch(async () => {
          // if original was a photo (caption), edit caption
          try {
            await bot.editMessageCaption(TERMS_TEXT, {
              chat_id: chatId, message_id: messageId,
              parse_mode: "Markdown", reply_markup: termsKeyboard(),
            });
          } catch {
            await bot.sendMessage(chatId, TERMS_TEXT, {
              parse_mode: "Markdown", reply_markup: termsKeyboard(),
            });
          }
        });
      }
      if (data === "welcome:back") {
        // Kembali ke halaman sambutan
        try {
          await bot.editMessageCaption(WELCOME_TEXT, {
            chat_id: chatId, message_id: messageId,
            parse_mode: "Markdown", reply_markup: welcomeKeyboard(),
          });
        } catch {
          try {
            await safeEdit(chatId, messageId, WELCOME_TEXT, welcomeKeyboard());
          } catch {
            await sendWelcome(chatId);
          }
        }
        return;
      }
      if (data === "welcome:agree") {
        db.upsertUser({
          platform: "telegram", chatId: String(chatId),
          terms_accepted_at: Date.now(),
        });
        // Lanjut verifikasi join
        const chk = await checkMembership(bot, q.from.id);
        if (!chk.ok) {
          try { await bot.deleteMessage(chatId, messageId); } catch {}
          return sendDenied(chatId);
        }
        try { await bot.deleteMessage(chatId, messageId); } catch {}
        return sendHomeFresh(chatId);
      }

      // ==== Verify re-check ====
      if (data === "verify:recheck") {
        const chk = await checkMembership(bot, q.from.id);
        if (!chk.ok) {
          await bot.answerCallbackQuery(q.id, { text: "Belum join!", show_alert: true }).catch(() => {});
          return safeEdit(chatId, messageId, tgCfg.messages.stillNotJoined, deniedKeyboard());
        }
        try { await bot.deleteMessage(chatId, messageId); } catch {}
        return sendHomeFresh(chatId);
      }

      // Gate: user harus menyetujui ketentuan dan lolos verifikasi
      const u = db.getUser(String(chatId), "telegram") || {};
      if (!u.terms_accepted_at) {
        try { await bot.deleteMessage(chatId, messageId); } catch {}
        return sendWelcome(chatId);
      }
      const chk = await checkMembership(bot, q.from.id);
      if (!chk.ok) return sendDenied(chatId, messageId);

      // Menu router
      if (data.startsWith("m:") || data.startsWith("p:") || data.startsWith("b:") || data.startsWith("a:")) {
        return routeMenu(chatId, messageId, data, q.from);
      }

      // Fallback ke flow lama (payment method, agreement dsb)
      const ctx = makeCtx(chatId, q.from);
      ctx.callbackData = data;
      await handleMessage(ctx);
    } catch (e) { logger.error("TG cb:", e.message); }
  });

  bot.on("polling_error", (e) => logger.error("TG polling:", e.message));
}

module.exports = { start };
