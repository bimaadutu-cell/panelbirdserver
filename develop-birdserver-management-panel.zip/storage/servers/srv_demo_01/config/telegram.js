// ==============================================
// KONFIGURASI VERIFIKASI JOIN TELEGRAM (V3)
// ==============================================
// Ganti data di bawah lalu simpan. TIDAK perlu edit source code.
//
//  channelId / groupId  -> bisa berupa "@usernamechannel" atau numeric ID (-100xxxxxxxxxx)
//  channelInvite / groupInvite -> link t.me/... untuk tombol Join
//
//  Bot HARUS di-add sebagai ADMIN di channel & grup agar getChatMember berhasil.
// ==============================================
module.exports = {
  enabled: true, // set false untuk mematikan verifikasi

  channel: {
    id: "",                  // atau -1001234567890
    invite: "",
    title: "📢 Channel Bimz Store",
  },
  group: {
    id: "-1003730370866",                    // atau -1009876543210
    invite: "https://t.me/+-Q1DLWZpYAxhYTBl",
    title: "👥 Grup Produk Y4anzz",
  },

  messages: {
    denied:
      "⚠️ *AKSES DITOLAK*\n\n" +
      "Sebelum menggunakan bot, silakan bergabung terlebih dahulu ke:\n" +
      "📢 Channel Telegram\n" +
      "👥 Grup Telegram\n\n" +
      "Setelah bergabung tekan tombol *✅ Saya Sudah Join*.",
    stillNotJoined:
      "❌ Kamu belum bergabung di salah satu (Channel/Grup).\n" +
      "Silakan join dulu lalu tekan tombol *✅ Saya Sudah Join* kembali.",
    success:
      "✅ *VERIFIKASI BERHASIL*\n\n" +
      "Selamat datang di BIMZ DIGITAL STORE.\n" +
      "Silakan pilih layanan pada menu di bawah.",
  },
};
