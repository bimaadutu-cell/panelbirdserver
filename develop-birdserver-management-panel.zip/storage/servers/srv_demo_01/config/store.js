const { overlay } = require("./_overlay");
// Identitas toko. Ubah bebas — tidak perlu edit source code.
const _base = {
  name: "BIMZ STORE",
  developer: "Bimz",
  logo: "media/logo.jpg",
  banner: "media/banner.jpg",
  welcomeImage: "media/welcome.jpg",
  footer: "© BIMZ STORE — Powered by BOT STORE V2",
  announcement: "Selamat datang di BIMZ STORE. Order 24 jam otomatis 🚀",
  contact: {
    whatsapp: "wa.me//+6283115955196",
    telegram: "@t.me/bimzaja009",
    email: "inilagiah@gmail.com",
  },
  social: {
    instagram: "",
    tiktok: "",
    youtube: "",
  },
  timezone: "Asia/Jakarta",
};
module.exports = overlay("store", _base);
