// ==============================================
// KONFIGURASI MULTI AI BUILDER (V3.3 UPGRADE)
// ==============================================
// Semua Builder untuk FileBotBuild dikonfigurasi di sini.
// Admin bisa mengubah apiKey, endpoint, enable, priority, model, timeoutMs
// tanpa menyentuh source code utama.
//
// PRIORITY: angka KECIL = dicoba LEBIH DULU.
// ENABLE   : true/false — matikan builder tanpa menghapus config.
// API KEY  : bisa diisi di sini ATAU lewat environment variable.
//            Env var lebih diutamakan jika diisi.
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  // ─────────────────────────────────────────
  // 1. LOVABLE AI  (OpenAI-compatible gateway)
  // ─────────────────────────────────────────
  lovable: {
    label:    "Lovable AI",
    apiKey:   "",                // atau env: LOVABLE_API_KEY
    endpoint: "https://ai.gateway.lovable.dev/v1/chat/completions",
    enabled:  true,
    priority: 1,
    model:    "openai/gpt-4o",
    timeoutMs: 120000,
    // format API: "openai" (chat completions standar)
    apiFormat: "openai",
    headers: {
      "X-Lovable-AIG-SDK": "bot-store-v3",
    },
  },

  // ─────────────────────────────────────────
  // 2. MANUS AI  (OpenAI-compatible)
  // ─────────────────────────────────────────
  manus: {
    label:    "Manus AI",
    apiKey:   "",                // atau env: MANUS_API_KEY
    endpoint: "https://api.manus.ai/v1/chat/completions",
    enabled:  true,              // aktif — API key via env: MANUS_API_KEY
    priority: 2,
    model:    "manus-1",
    timeoutMs: 120000,
    apiFormat: "openai",
    headers:  {},
  },

  // ─────────────────────────────────────────
  // 3. REPLIT AI  (OpenAI-compatible)
  // ─────────────────────────────────────────
  replit: {
    label:    "Replit AI",
    apiKey:   "",                // atau env: REPLIT_AI_API_KEY
    endpoint: "https://replit.com/api/v0/ai/claude/v1/chat/completions",
    enabled:  false,             // nonaktif
    priority: 3,
    model:    "claude-3-7-sonnet",
    timeoutMs: 120000,
    apiFormat: "openai",
    headers:  {},
  },

  // ─────────────────────────────────────────
  // 4. GEMINI AI  (Google Generative Language)
  // ─────────────────────────────────────────
  gemini: {
    label:    "Gemini AI",
    apiKey:   "",                // atau env: GEMINI_API_KEY
    // endpoint dipakai sebagai base; model di-append otomatis
    endpoint: "https://generativelanguage.googleapis.com/v1beta/models",
    enabled:  true,
    priority: 4,
    model:    "gemini-2.5-flash",
    timeoutMs: 90000,
    // format API: "gemini" — beda struktur request/response
    apiFormat: "gemini",
    headers:  {},
  },

  // ─────────────────────────────────────────
  // 5. OPENAI / CHATGPT  (OpenAI-compatible)
  // ─────────────────────────────────────────
  openai: {
    label:    "OpenAI / ChatGPT",
    apiKey:   "",                // atau env: OPENAI_API_KEY
    endpoint: "https://api.openai.com/v1/chat/completions",
    enabled:  false,             // aktifkan jika sudah punya API key
    priority: 5,
    model:    "gpt-4o-mini",
    timeoutMs: 90000,
    apiFormat: "openai",
    headers:  {},
  },

  // 
  custom1: {
     label:    "bazar ai",
      apiKey:   "sk-bl-IF2-oziJAP0j4q4dec4t71q4EvEIDFfVSkZU3bVlvTkOsng4",
    endpoint: "https://bazaarlink.ai/api/v1/chat/completions",
    enabled:  false,
    priority: 6,
     model:    "Bazarlink-1",
     timeoutMs: 90000,
    apiFormat: "openai",
     headers:  {},
  },─────────────────────────────────────────
  // SLOT CADANGAN — tambah builder custom di sini
  // ─────────────────────────────────────────
  // custom1: {
  //   label:    "Custom Builder",
  //   apiKey:   "",
  //   endpoint: "https://your-endpoint/v1/chat/completions",
  //   enabled:  false,
  //   priority: 6,
  //   model:    "your-model",
  //   timeoutMs: 90000,
  //   apiFormat: "openai",
  //   headers:  {},
  // },
};

module.exports = overlay("builders", _base);
