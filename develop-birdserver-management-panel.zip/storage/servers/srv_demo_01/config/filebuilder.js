// ==============================================
// KONFIGURASI FILEBOTBUILD (V5 UPGRADE)
// ==============================================
// Provider AI ada di config/providers.js.
// Metode koneksi WhatsApp/Telegram ada di config/connections.js.
// ==============================================
const path = require("path");
const { overlay } = require("./_overlay");
const connCfg = require("./connections");

function resolveLibraryHint(platform) {
  const p = connCfg[platform];
  if (!p) return "";
  const method = p.defaultMethod;
  return p.methods?.[method]?.libraryHint || "";
}

const _base = {
  enabled: true,

  // Direktori kerja
  workDir: path.join(__dirname, "..", "logs", "filebuilder"),

  // ── V5.1: batas input ide user dinaikkan menjadi 100.000 kata.
  //          maxIdeaChars tetap ada sebagai safety guard teknis agar proses
  //          bot tidak kehabisan memory saat menerima pesan sangat besar.
  maxIdeaWords: 100000,
  maxIdeaChars: 900000,

  // Ukuran chunk (karakter) saat prompt terlalu panjang.
  // Diteruskan ke multiBuilder.generate({ chunkChars }).
  chunkChars: 18000,
  maxChunks: 80,

  // Batas file & bundle hasil generate
  maxFiles: 40,
  maxBundleBytes: 5 * 1024 * 1024, // 5 MB

  // Timeout total 1 proses build (ms)
  timeoutMs: 300000,

  // Delay animasi progress (jeda antar step)
  progressDelayMs: 500,

  project: {
    authorFallback: "BimzCreated",
    licenseFallback: "MIT",
    versionFallback: "1.0.0",
  },

  platforms: {
    whatsapp: {
      key: "whatsapp",
      label: "📱 WhatsApp Only",
      get libraryHint() { return resolveLibraryHint("whatsapp"); },
    },
    telegram: {
      key: "telegram",
      label: "🤖 Telegram Only",
      get libraryHint() { return resolveLibraryHint("telegram"); },
    },
  },
};

module.exports = overlay("filebuilder", _base);
