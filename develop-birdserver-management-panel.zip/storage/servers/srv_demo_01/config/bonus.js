// ==============================================
// KONFIGURASI BONUS HARIAN (V3.2)
// ==============================================
// Admin bebas mengubah nominal, cooldown, status enable, dan message
// tanpa mengedit source code (juga bisa via /setbonus <field> <value>).
// File ini adalah source of truth (dailyBonus.js sudah tidak dipakai).
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  enable: true,
  enabled: true,          // alias — kompatibilitas lama
  amount: 10000,            // nominal (Rp)
  cooldown: 24,           // cooldown (jam) — alias baru
  cooldownHours: 24,      // alias — kompatibilitas lama
  label: "🎁 Bonus Harian",
  message: "Kamu berhasil klaim bonus harian sebesar {amount}. Total saldo: {balance}.",
};

const merged = overlay("bonus", _base);

// Sinkronkan alias biar tetap kompatibel dengan file lama.
if (merged.cooldown && !merged.cooldownHours) merged.cooldownHours = merged.cooldown;
if (merged.cooldownHours && !merged.cooldown) merged.cooldown = merged.cooldownHours;
if (typeof merged.enable === "boolean" && typeof merged.enabled !== "boolean") merged.enabled = merged.enable;
if (typeof merged.enabled === "boolean" && typeof merged.enable !== "boolean") merged.enable = merged.enabled;

module.exports = merged;
