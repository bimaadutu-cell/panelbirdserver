// ==============================================
// KONFIGURASI KONTAK (V3.2)
// ==============================================
// Semua nomor WhatsApp & username Telegram di sini.
// Bot TIDAK boleh hardcode nomor di source. Ubah bebas di file ini.
//
// Format WhatsApp : 62xxxxxxxxxxx (tanpa '+', tanpa spasi)
// Format Telegram : username tanpa '@' (contoh: "bimzaja009")
//                   atau link penuh https://t.me/bimzaja009
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  // ---- OWNER / ADMIN UTAMA ----
  owner: {
    name: "Admin Bimz",
    whatsapp: "wa.me//+6283115955196",
    telegramUsername: "@bimzaja009",
  },

  // ---- BIMZCREATED (APK CPANEL) ----
  bimzcreated: {
    name: "Admin BimzCreated",
    whatsapp: "wa.me//+6283115955196",
    telegramUsername: "@bimzaja009",
  },

  // ---- APK BUG (YANZZ) ----
  apkBug: {
    name: "Yanzz",
    whatsapp: "wa nya lagi kenon,chat tele aja",
    telegramUsername: "@y4nzzpokke",
  },

  // ---- SUPPORT UMUM ----
  support: {
    name: "Support",
    whatsapp: "wa.me//+6283115955196",
    telegramUsername: "bimzsupport",
  },
};

function waLink(number, prefill = "") {
  const clean = String(number || "").replace(/\D/g, "");
  const q = prefill ? `?text=${encodeURIComponent(prefill)}` : "";
  return clean ? `https://wa.me/${clean}${q}` : "";
}
function tgLink(username) {
  const u = String(username || "").replace(/^@|^https?:\/\/t\.me\//i, "");
  return u ? `https://t.me/${u}` : "";
}

module.exports = Object.assign(overlay("contact", _base), { waLink, tgLink });
