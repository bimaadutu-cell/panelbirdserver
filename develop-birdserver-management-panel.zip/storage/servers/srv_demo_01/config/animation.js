// ==============================================
// KONFIGURASI ANIMASI FILEBOTBUILD (V3.3 UPGRADE)
// ==============================================
// Semua pengaturan animasi progress build ada di sini.
// Admin bebas mengubah emoji, teks, delay, dan langkah progress
// tanpa mengedit source code utama.
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  // Lebar progress bar (jumlah blok)
  barWidth: 10,

  // Karakter blok terisi dan kosong
  blockFilled: "█",
  blockEmpty:  "░",

  // Delay antar update progress (ms)
  stepDelayMs: 700,

  // Langkah-langkah progress (persen) yang ditampilkan
  steps: [
    { pct: 5,   label: "⚙️ Memeriksa konfigurasi builder dulu nih sayangg..." },
    { pct: 10,  label: "⚙️ Memvalidasi ide dulu nih sayangg..." },
    { pct: 20,  label: "🤖 Mencari builder terbaik nih sayangkuu🤭." },
    { pct: 30,  label: "🚀 Halo ai builder ada yang mau buat file nihh☎️🙂‍↔️" },
    { pct: 50,  label: "🧠 AI sedang menulis kode nih sayang tunggu yakkk." },
    { pct: 65,  label: "📁 Menyusun struktur project duluu nihh" },
    { pct: 80,  label: "✍️ Menulis file ke workspace nihh sayang,hampir selesai" },
    { pct: 90,  label: "🗜️ Mengompres menjadi ZIP Dannn....." },
    { pct: 100, label: "✅ Build selesai sayangg selamat mencoba!" },
  ],

  // Teks header saat mulai build
  buildingHeader: "⚙️ *FILEBOTBUILD — Multi AI Builder*",

  // Teks fallback ke builder berikutnya
  fallbackText: "⚠️ Builder gagal, beralih ke builder berikutnya...",

  // Teks error semua builder habis
  allFailedText: "❌ Semua AI Builder tidak tersedia saat ini. Silakan coba beberapa saat lagi.",

  // Format teks progress bar
  // {header} {label}\n[{bar}] {pct}%\n{extra}
  format: "{header}\n{label}\n[{bar}] {pct}%",
};

module.exports = overlay("animation", _base);
