// ==============================================
// KONFIGURASI PRODUK BIMZCREATED (V3.1)
// ==============================================
// Role USER / RESELLER / OWNER HANYA muncul di menu BimzCreated.
// Harga & isi paket boleh diubah tanpa mengedit source code
// (juga via /setbimzprice yang menulis ke config/_overrides.json).
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  title: "📱 BIMZCREATED",
  description: "Script Premium BimzCreated. Pilih role di bawah.",
  packages: {
    user: {
      label: "👤 USER",
      price: 1500,
      masaAktif: "30 Hari",
      limit: "10 nomor / hari",
      features: ["Akses semua fitur dasar", "Update rutin", "Support grup"],
      info: "Cocok untuk pengguna pribadi.",
      warning: "Dilarang dijual ulang. Akun terdeteksi share = banned.",
    },
    reseller: {
      label: "💼 RESELLER",
      price: 20000,
      masaAktif: "30 Hari",
      limit: "50 nomor / hari",
      features: [
        "Semua fitur USER",
        "Akses reseller panel",
        "Support prioritas",
        "Boleh dijual kembali",
      ],
      info: "Cocok untuk membuka toko / reseller.",
      warning: "Dilarang membagikan source code.",
    },
    owner: {
      label: "👑 OWNER",
      price: 35000,
      masaAktif: "Permanen",
      limit: "Unlimited nomor",
      features: [
        "Semua fitur RESELLER",
        "Whitelabel",
        "Support VVIP 24 jam",
        "Update lifetime",
      ],
      info: "Untuk pemilik bisnis penuh.",
      warning: "Akun personal — dilarang share credential.",
    },
  },
};

module.exports = overlay("bimzcreated", _base);
