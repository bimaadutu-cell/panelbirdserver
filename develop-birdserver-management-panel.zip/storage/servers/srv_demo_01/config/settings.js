// Pengaturan runtime bot.
module.exports = {
  platforms: {
    telegram: true,
    whatsapp: true,
  },
  security: {
    rateLimitPerMinute: 20,      // max pesan / menit / user
    antiSpamCooldownMs: 800,     // jeda min antar pesan user
    maxConcurrentOrdersPerUser: 3,
    invoiceExpireMinutes: 30,    // fallback bila config/payment.js dikosongkan
  },
  queue: {
    createPanelConcurrency: 2,
    retry: { attempts: 3, backoffMs: 2000 },
  },
  status: {
    checkIntervalMs: 60_000,     // interval cek status server
    pingTimeoutMs: 5000,
  },
  admin: {
    // prefix perintah admin
    prefix: "/",
  },
};
