module.exports = {
  maxRetry: 3,
  retryDelayMs: 2000,
  maxContextMessages: 10,
  timeoutMs: 30000,
  systemPrompt: "Anda adalah AI Assistant profesional untuk Bot Store. Gunakan Markdown untuk memformat jawaban Anda. Gunakan blok kode untuk skrip.",
  fallbackModel: "gemini",
  autoFixPrompt: true,
  autoContinue: true
};
