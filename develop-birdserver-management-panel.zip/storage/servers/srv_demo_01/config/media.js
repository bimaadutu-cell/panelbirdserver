module.exports = {
  assetsDir: "media",
  supportedImages: [".jpg", ".jpeg", ".png", ".webp"],
  supportedVideos: [".mp4", ".mov", ".gif"],
  defaultBanner: "banner.jpg",
  mapping: {
    welcome: ["welcome.mp4", "welcome.jpg"],
    panel: ["panel.mp4", "panel.jpg"],
    apkbug: ["apkbug.mp4", "apkbug.jpg"],
    bimzcreated: ["bimzcreated.mp4", "bimzcreated.jpg"],
    bonus: ["bonus.mp4", "bonus.jpg"],
    profile: ["profile.mp4", "profile.jpg"],
    announcement: ["announcement.mp4", "announcement.jpg"]
  }
};
