module.exports = {
  enabled: true,
  intervalMinutes: 5, // Cek setiap 5 menit
  notifyAdminOnDown: true,
  retryAttempts: 3,
  timeoutMs: 15000
};
