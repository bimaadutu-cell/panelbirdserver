// ==============================================
// KONFIGURASI PROVIDER AI (V5 — FILEBOTBUILD PRO)
// ==============================================
// SATU-SATUNYA sumber kebenaran untuk semua endpoint / model / API key /
// parameter AI Builder. TIDAK ADA endpoint yang boleh di-hardcode di
// source code utama. Admin cukup mengubah file ini apabila dokumentasi
// resmi provider berubah.
//
// FIELD:
//   label      : nama tampil di log & progress
//   enabled    : true/false — non-aktifkan tanpa hapus config
//   priority   : urutan fallback (kecil = lebih dulu)
//   apiKey     : bisa diisi di sini ATAU via env (env diprioritaskan)
//   envKey     : nama environment variable untuk apiKey
//   apiFormat  : "openai" | "gemini"
//   baseUrl    : base URL — dipakai jika endpoint kosong
//   endpoint   : full path chat completion (openai) atau base models (gemini)
//   endpoints  : daftar fallback endpoint (dicoba berurutan jika 404/DNS/timeout)
//   model      : model default
//   models     : daftar model fallback (dicoba jika model utama gagal)
//   timeoutMs  : timeout per-request
//   retry      : { attempts, backoffMs } — retry di provider yang sama
//   headers    : header tambahan (opsional)
//   temperature, maxTokens : parameter generation
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  // ─────────────────────────────────────────
  // 1. MANUS AI  (OpenAI-compatible)
  // ─────────────────────────────────────────
  manus: {
    label:    "Manus AI",
    enabled:  true,
    priority: 2,
    apiKey:   "",
    envKey:   "MANUS_API_KEY",
    apiFormat: "openai",
    baseUrl:  "https://api.manus.ai/v1",
    endpoint: "https://api.manus.ai/v1/chat/completions",
    // Endpoint fallback: dicoba berurutan bila endpoint utama 404 / DNS gagal.
    // Ubah daftar ini bila dokumentasi Manus AI berubah — TIDAK perlu edit source code.
    endpoints: [
      "https://api.manus.ai/v1/chat/completions",
      "https://api.manus.im/v1/chat/completions",
      "https://openrouter.ai/api/v1/chat/completions",
    ],
    model:    "manus-1",
    models:   ["manus-1", "manus-pro", "manus-1-mini"],
    timeoutMs: 120000,
    retry:    { attempts: 3, backoffMs: 1500 },
    headers:  {},
    temperature: 0.7,
    maxTokens: 8192,
  },

  // ─────────────────────────────────────────
  // 2. GEMINI AI  (Google Generative Language) — priority 1 = dicoba pertama
  // ─────────────────────────────────────────
  gemini: {
    label:    "Gemini AI",
    enabled:  true,
    priority: 1,
    apiKey:   "",
    envKey:   "GEMINI_API_KEY",
    apiFormat: "gemini",
    baseUrl:  "https://generativelanguage.googleapis.com/v1beta",
    endpoint: "https://generativelanguage.googleapis.com/v1beta/models",
    endpoints: [
      "https://generativelanguage.googleapis.com/v1beta/models",
      "https://generativelanguage.googleapis.com/v1/models",
    ],
    model:    "gemini-2.5-flash",
    models:   ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash", "gemini-1.5-flash"],
    timeoutMs: 90000,
    retry:    { attempts: 3, backoffMs: 1500 },
    headers:  {},
    temperature: 0.7,
    maxTokens: 8192,
  },

  // ─────────────────────────────────────────
  // 3. LOVABLE AI  (OpenAI-compatible gateway)
  // ─────────────────────────────────────────
  lovable: {
    label:    "Lovable AI",
    enabled:  true,
    priority: 3,
    apiKey:   "",
    envKey:   "LOVABLE_API_KEY",
    apiFormat: "openai",
    baseUrl:  "https://ai.gateway.lovable.dev/v1",
    endpoint: "https://ai.gateway.lovable.dev/v1/chat/completions",
    endpoints: [
      "https://ai.gateway.lovable.dev/v1/chat/completions",
    ],
    model:    "openai/gpt-5.5",
    models:   ["openai/gpt-5.5", "openai/gpt-5.4-mini", "google/gemini-3.5-flash"],
    timeoutMs: 120000,
    retry:    { attempts: 3, backoffMs: 1500 },
    headers:  { "X-Lovable-AIG-SDK": "bot-store-v5" },
    temperature: 0.7,
    maxTokens: 8192,
  },

  // ─────────────────────────────────────────
  // 4. OPENAI / CHATGPT  (fallback tambahan)
  // ─────────────────────────────────────────
  openai: {
    label:    "OpenAI / ChatGPT",
    enabled:  false,
    priority: 4,
    apiKey:   "",
    envKey:   "OPENAI_API_KEY",
    apiFormat: "openai",
    baseUrl:  "https://api.openai.com/v1",
    endpoint: "https://api.openai.com/v1/chat/completions",
    endpoints: ["https://api.openai.com/v1/chat/completions"],
    model:    "gpt-4o-mini",
    models:   ["gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo"],
    timeoutMs: 90000,
    retry:    { attempts: 3, backoffMs: 1500 },
    headers:  {},
    temperature: 0.7,
    maxTokens: 8192,
  },
};

module.exports = overlay("providers", _base);
