// Role untuk produk PANEL. Field yang dikirim ke Pterodactyl: ram/cpu/disk (0 = unlimited).
module.exports = {
  user: {
    label: "USER",
    ramMultiplier: 1,
    cpuPerGB: 40,
    diskPerGB: 1024,
  },
  reseller: {
    label: "RESELLER",
    ramMultiplier: 1,
    cpuPerGB: 60,
    diskPerGB: 2048,
  },
  owner: {
    label: "OWNER",
    ramMultiplier: 0, // unlimited
    cpuPerGB: 0,
    diskPerGB: 0,
  },
};
