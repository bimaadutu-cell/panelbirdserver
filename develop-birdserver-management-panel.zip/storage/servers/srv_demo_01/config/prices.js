const { overlay } = require("./_overlay");
// Harga per paket panel per server & role. 0 = unlimited (harga permanen).
// Struktur: prices[serverKey][role][sizeGB] = harga
// sizeGB "unlimited" untuk paket unlimited.
const _base = {
  bimz: {
    user: {
      1: 1500, 2: 3000, 3: 4500, 4: 6000, 5: 7500,
      6: 9000, 7: 10500, 8: 12000, 9: 13500, 10: 15000,
      unlimited: 25000,
    }
  },
  yanzz: {
    user: {
      1: 2000, 2: 3500, 3: 5000, 4: 6500, 5: 8000,
      6: 9500, 7: 11000, 8: 12500, 9: 14000, 10: 15500,
      unlimited: 27000,
    }
  },
};
module.exports = overlay("prices", _base);
