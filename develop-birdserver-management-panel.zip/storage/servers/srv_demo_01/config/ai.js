// ==============================================
// KONFIGURASI MODE AI (V3.3)
// ==============================================
// Pengaturan umum fitur ModeAI (chat AI langsung dari user).
// Ubah bebas tanpa mengedit source code.
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  enabled: true,

  // Model default saat pertama kali user memilih ModeAI (opsional).
  // Kosongkan agar user tetap harus memilih model tiap membuka ModeAI.
  defaultModel: "",

  // Batas memory percakapan (jumlah pasangan Q&A yang disimpan).
  memory: {
    enabled: true,
    maxTurns: 20,       // jumlah pesan (user+assistant) yang diingat
    ttlMinutes: 60,     // durasi memory dalam menit sejak pesan terakhir
  },

  // System prompt utama untuk seluruh model AI.
  systemPrompt:
    "Kamu adalah asisten AI profesional bernama BimzAI. " +
    "Balas dalam Bahasa Indonesia yang natural, ramah, dan mudah dipahami, " +
    "kecuali user meminta bahasa lain. " +
    "Kamu ahli di bidang programming: HTML, CSS, JavaScript, TypeScript, " +
    "Node.js, Python, PHP, React, Next.js, Express, API, Database, AI, " +
    "Pterodactyl, Telegram Bot, WhatsApp Bot, UI/UX, JSON, Docker, dan Linux. " +
    "Jelaskan dengan detail, tampilkan contoh kode dalam blok ```lang```, " +
    "dan bantu user coding, debug, membuat website, membuat bot, " +
    "membuat prompt, membuat file, serta menjelaskan error. " +
    "Jangan menjawab seperti bot command — jawablah seperti manusia.",

  // Batasi panjang balasan agar aman untuk Telegram (4096 char cap).
  maxResponseChars: 3800,

  // Tampilan
  ui: {
    thinkingText: "🧠 Sedang memproses...",
    unknownModel: "⚠️ Model tidak dikenali.",
    notConfigured: "⚠️ Model ini belum dikonfigurasi Admin.",
    comingSoon: "🚧 Akan Hadir",
  },
};

module.exports = overlay("ai", _base);
