/**
 * Configuration for Report Feature
 */

module.exports = {
  mode: "telegram", // "telegram" or "whatsapp"
  telegram: {
    chatId: "8594277330", // Fill with Admin Telegram Chat ID
    username: "@b1mxzstore" // Fill with Admin Telegram Username (without @)
  },
  whatsapp: {
    number: "" // Fill with Admin WhatsApp Number (628xxx)
  }
};
