// ==============================================
// KONFIGURASI BONUS HARIAN
// ==============================================
// Admin dapat mengubah nominal & cooldown tanpa mengedit source code
// (juga via /setbonus <field> <value>).
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  enabled: true,
  amount: 10000,          // Rp300 saldo
  cooldownHours: 24,    // klaim setiap 24 jam
  label: "🎁 Bonus Harian",
  message: "Kamu berhasil klaim bonus harian sebesar {amount}. Total saldo: {balance}.",
};

module.exports = overlay("dailyBonus", _base);
