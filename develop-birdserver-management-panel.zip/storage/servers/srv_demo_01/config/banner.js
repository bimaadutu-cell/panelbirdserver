// Banner & pesan yang tampil di bot. Semuanya boleh diedit.
const store = require("./store");
module.exports = {
  welcome:
`━━━━━━━━━━━━━━━━━━
    ${store.name}
━━━━━━━━━━━━━━━━━━
${store.announcement}

Ketik *menu* untuk mulai order,
atau ketik *status* untuk cek order Anda.`,
  menuHeader:
`━━━━━━━━━━━━━━━━━━
    ORDER MENU — ${store.name}
━━━━━━━━━━━━━━━━━━`,
  footer: store.footer,
};
