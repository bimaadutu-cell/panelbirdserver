// ==============================================
// KONFIGURASI LOVABLE AI GATEWAY (V3.3)
// ==============================================
// Digunakan oleh ModeAI (Lovable) DAN FileBotBuild sebagai backend generator.
// Semua parameter di sini bisa diubah tanpa mengedit source code.
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  endpoint: "https://ai.gateway.lovable.dev/v1/chat/completions",
  // API key: kosongkan agar dibaca dari env LOVABLE_API_KEY
  apiKey: "",
  // Model default untuk chat & builder
  chatModel: "openai/gpt-5.5",
  builderModel: "openai/gpt-5.5",
  // Timeout request (ms)
  timeoutMs: 120000,
  // Header tambahan
  headers: {
    "X-Lovable-AIG-SDK": "bot-store-v3",
  },
};

module.exports = overlay("lovable", _base);
