// ==============================================
// KONFIGURASI PENGUMUMAN (V3.2)
// ==============================================
// Admin bebas mengubah teks pengumuman tanpa edit source.
// Bisa juga via /announce <text> yang menulis ke _overrides.json.
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  title: "📢 Pengumuman Resmi",
  text:
    "Selamat datang di *BIMZ DIGITAL STORE*.\n\n" +
    "• Layanan Panel Pterodactyl otomatis 24 jam.\n" +
    "• BimzCreated (APK CPanel) tersedia dengan role USER/RESELLER/OWNER.\n" +
    "• APK BUG tersedia via order manual ke Yanzz.\n\n" +
    "Terima kasih telah mempercayai layanan kami.",
  updatedAt: null,
};

module.exports = overlay("announcement", _base);
