const { overlay } = require("./_overlay");
// Metode pembayaran. Enable/disable & ubah data via config.
const _base = {
  // Nama merchant WAJIB — dipakai OCR untuk mencocokkan bukti pembayaran.
  // Ubah sesuai nama merchant yang tampil pada struk QRIS / bukti transfer.
  merchantName: "BIMZ OFFICIAL",
  merchantAliases: ["BIMZ OFFICIAL", "BIMZOFFICIAL", "BIMZ STORE", "BIMZ"],

  invoiceExpireMinutes: 30,
  paymentExpireMinutes: 60,

  // Toggle OCR ketat. Bila true (default) bot WAJIB membaca isi gambar
  // dan mencocokkan nominal, status, tanggal, merchant, referensi.
  strictOCR: true,

  methods: {
    qris: {
      enabled: true,
      label: "QRIS (semua e-wallet & bank)",
      image: "media/qris.jpg",
      name: "BIMZ OFFICIAL",
    },
    dana: {
      enabled: true,
      label: "DANA",
      number: "083179632346",
      name: "BimzOfficial",
    },
    gopay: {
      enabled: true,
      label: "GoPay",
      number: "083179632346",
      name: "Tiaa",
    },
    ovo: {
      enabled: false,
      label: "OVO",
      number: "",
      name: "",
    },
    transfer: {
      enabled: true,
      label: "Transfer Bank BCA",
      number: "",
      name: "",
    },
    saldo: {
      enabled: true,
      label: "💰 Bayar Menggunakan Saldo",
      internal: true,
    },
  },
  // Toleransi selisih nominal (rupiah)
  amountTolerance: 500,
  // Maksimal percobaan bukti pembayaran per invoice
  maxProofAttempts: 3,
};
module.exports = overlay("payment", _base);
