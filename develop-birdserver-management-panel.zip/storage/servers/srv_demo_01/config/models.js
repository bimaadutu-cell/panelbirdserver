// ==============================================
// DAFTAR MODEL AI (V3.3)
// ==============================================
// Semua model yang tampil di menu ModeAI diambil dari sini.
// Admin bebas mengatur enable/disable, ganti API key, atau menambah model.
//
// API Key Gemini bisa diletakkan di sini ATAU di env GEMINI_API_KEY.
// API Key OpenAI (ChatGPT) diletakkan di env OPENAI_API_KEY / config ini.
// Lovable AI menggunakan env LOVABLE_API_KEY (tidak perlu dari user).
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  // ================= GEMINI =================
  gemini: {
    label: "🟢 Gemini",
    enabled: true,
    // Isi API key di sini ATAU biarkan kosong dan set GEMINI_API_KEY di .env
    apiKey: "AQ.Ab8RN6IOsnEh9lKVdgUi95koyTtt_H4IK5UXyUP5QEwZkRiiow",
    // Model default yang dipakai saat user memilih Gemini
    defaultModel: "gemini-2.5-flash",
    // Daftar model Gemini yang boleh dipilih (opsional untuk pengembangan lanjut)
    models: [
      "gemini-2.5-flash",
      "gemini-2.5-pro",
      "gemini-2.0-flash",
      "gemini-1.5-flash",
      "gemini-1.5-pro",
    ],
    // Endpoint API Google Generative Language
    endpoint: "https://generativelanguage.googleapis.com/v1beta/models",
    // Parameter tuning
    generationConfig: {
      temperature: 0.7,
      topP: 0.95,
      topK: 40,
      maxOutputTokens: 2048,
    },
  },

  // ================= CHATGPT =================
  chatgpt: {
    label: "🟢 ChatGPT",
    enabled: false,                    // biarkan false → tampil "Akan Hadir"
    apiKey: "",                        // atau OPENAI_API_KEY di .env
    defaultModel: "gpt-4o-mini",
    models: ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"],
    endpoint: "https://api.openai.com/v1/chat/completions",
    generationConfig: {
      temperature: 0.7,
      max_tokens: 2048,
    },
  },

  // ================= LOVABLE AI =================
  lovable: {
    label: "🟢 Lovable AI",
    enabled: true,
    // Tidak perlu API key dari user — pakai LOVABLE_API_KEY dari environment.
    // (Boleh diisi manual di sini untuk override.)
    apiKey: "",
    defaultModel: "openai/gpt-5.5",
    models: [
      "openai/gpt-5.5",
      "openai/gpt-5.4-mini",
      "openai/gpt-5.4-nano",
      "google/gemini-3.5-flash",
      "google/gemini-3.1-pro-preview",
    ],
    endpoint: "https://ai.gateway.lovable.dev/v1/chat/completions",
    generationConfig: {
      temperature: 0.7,
    },
  },
};

module.exports = overlay("models", _base);
