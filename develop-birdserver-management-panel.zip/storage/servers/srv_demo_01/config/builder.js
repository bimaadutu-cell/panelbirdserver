module.exports = {
  maxPipelineRetries: 3,
  fallbackProvider: "gemini",
  zipOutput: true,
  stages: [
    "analysis", "planning", "folder", "config", "commands", 
    "events", "handler", "database", "utils", "review"
  ],
  autoFixPrompt: true,
  aiReview: true
};
