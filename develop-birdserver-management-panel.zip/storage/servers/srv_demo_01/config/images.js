// ==============================================
// KONFIGURASI GAMBAR / ASSET (V5.2)
// ==============================================
// Bot mencari file di folder /assets terlebih dahulu, lalu /media.
// Admin bebas mengganti gambar tanpa mengedit source code.
// Cukup timpa file di folder /assets.
// ==============================================
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");
const ASSETS_DIR = path.join(ROOT, "assets");
const MEDIA_DIR = path.join(ROOT, "media");

function resolve(name) {
  const candidates = [
    path.join(ASSETS_DIR, name),
    path.join(MEDIA_DIR, name),
  ];
  for (const c of candidates) if (fs.existsSync(c)) return c;
  return null;
}

const IMAGES = {
  welcome:      "welcome.jpg",
  panel:        "panel.jpg",
  bimzcreated:  "bimzcreated.jpg",
  apkbug:       "apkbug.jpg",
  bonus:        "bonus.jpg",
  profile:      "profile.jpg",
  announcement: "announcement.jpg",
  qris:         "qris.jpg",
  logo:         "logo.jpg",
  banner:       "banner.jpg",
};

const api = {};
for (const [k, name] of Object.entries(IMAGES)) {
  api[k] = () => resolve(name);
}
api.resolve = resolve;
api.list = () => Object.fromEntries(Object.entries(IMAGES).map(([k, n]) => [k, resolve(n)]));

module.exports = api;
