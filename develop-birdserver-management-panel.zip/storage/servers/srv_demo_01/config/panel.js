const { overlay } = require("./_overlay");
// KONFIGURASI PANEL PTERODACTYL
// Admin CUKUP mengisi: name, url, ptla.
// Node / Nest / Egg / Location diambil OTOMATIS oleh bot lewat Application API.
// Jika lebih dari satu tersedia, bot memakai "defaults" di bawah (opsional).
// Jika defaults kosong, bot memilih yang pertama.
const _base = {
  servers: [
    {
      key: "bimz",
      name: "Bimz Server V1",
      url: "https://panelrixzzofficial.psxysanz.biz.id",
      ptla: "ptla_23CbESPSSX4oDoKmrR8ODopj5H8gXR5penuaAweBi6W",
      defaults: {
        // OPSIONAL — kosongkan biar auto pilih pertama
        // nodeName: "Node-1",
        // nestName: "Pterodactyl Nest",
        // eggName: "NodeJS VIP",
        // locationShort: "sg",
      },
    },
    {
      key: "yanzz",
      name: "Yanzz Server V1",
      url: "https://panel2.domain.com",
      ptla: "ptla_xxxxxxxxxxxxxxxxxxxxx",
      defaults: {},
    },
  ],
  // Masa aktif default (hari) untuk panel yang dibuat otomatis.
  defaultExpireDays: 30,
  // Interval scheduler cek expired panel (cron string).
  autoDeleteCron: "*/10 * * * *", // tiap 10 menit
  // Cache TTL untuk node/nest/egg/location (detik).
  metaCacheTTL: 3600,
};
module.exports = overlay("panel", _base);
