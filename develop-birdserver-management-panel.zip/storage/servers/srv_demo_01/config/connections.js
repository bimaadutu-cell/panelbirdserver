// ==============================================
// KONFIGURASI METODE KONEKSI (V3.3 UPGRADE)
// ==============================================
// Pengaturan metode koneksi yang digunakan dalam template bot yang digenerate.
// Admin bebas mengubah metode default, deskripsi, dan library hint
// tanpa mengedit source code.
// ==============================================
const { overlay } = require("./_overlay");

const _base = {
  // ─────────────────────────────────────────
  // WHATSAPP
  // ─────────────────────────────────────────
  whatsapp: {
    // Metode koneksi default untuk bot WhatsApp yang digenerate.
    // Pilihan: "pairing_code" | "qr_code"
    defaultMethod: "pairing_code",

    methods: {
      // Baileys Pairing Code (resmi, disarankan)
      pairing_code: {
        label:       "📱 Baileys Pairing Code (Resmi)",
        enabled:     true,
        libraryHint:
          "Gunakan @whiskeysockets/baileys versi 6.7.x dengan pairing code " +
          "(requestPairingCode). Simpan session di folder ./auth. " +
          "Dukung graceful reconnect saat DisconnectReason.restartRequired.",
        envHint:     "PAIRING_NUMBER=628xxxxxxxxxx",
      },

      // Baileys QR Code (resmi)
      qr_code: {
        label:       "📷 Baileys QR Code (Resmi)",
        enabled:     true,
        libraryHint:
          "Gunakan @whiskeysockets/baileys versi 6.7.x dengan " +
          "printQRInTerminal: true. Simpan session di folder ./auth.",
        envHint:     "",
      },
    },
  },

  // ─────────────────────────────────────────
  // TELEGRAM
  // ─────────────────────────────────────────
  telegram: {
    // Metode koneksi default untuk bot Telegram yang digenerate.
    // Pilihan: "polling" | "webhook"
    defaultMethod: "polling",

    methods: {
      // Telegram Bot API Polling (resmi, mudah dijalankan)
      polling: {
        label:       "🤖 Telegram Bot API Polling (Resmi)",
        enabled:     true,
        libraryHint:
          "Gunakan node-telegram-bot-api versi ^0.66.x dengan " +
          "{ polling: true }. Baca BOT_TOKEN dari .env.",
        envHint:     "BOT_TOKEN=isi_dari_BotFather",
      },

      // Telegram Bot API Webhook
      webhook: {
        label:       "🌐 Telegram Bot API Webhook",
        enabled:     true,
        libraryHint:
          "Gunakan node-telegram-bot-api dengan webHook. " +
          "Butuh HTTPS endpoint. Baca BOT_TOKEN dan WEBHOOK_URL dari .env.",
        envHint:     "BOT_TOKEN=isi_dari_BotFather\nWEBHOOK_URL=https://your-domain.com/bot",
      },
    },
  },
};

module.exports = overlay("connections", _base);
