// Nomor / user ID yang boleh mengakses menu admin.
// telegramChatId = user id Telegram (angka).
// waJid          = 62xxxx@s.whatsapp.net
module.exports = [
  {
    id: "bimz",
    name: "Bimz",
    telegramChatId: "8594277330",
    waJid: "6283115955196@s.whatsapp.net",
  },
];
