// Produk NON-PANEL (APK Yanzz, dll). Panel dibuat via config/prices.js + config/panel.js.
module.exports = {
  categories: [
    {
      id: "apk_yanzz",
      label: "APK YANZZ",
      items: [
        { id: "yanzz_basic_1m",   name: "Basic 1 Bulan",   price: 15000, features: ["Fitur basic", "Support 1 device"] },
        { id: "yanzz_basic_perm", name: "Basic Permanen",  price: 50000, features: ["Fitur basic", "Lifetime"] },
        { id: "yanzz_vip_1m",     name: "VIP 1 Bulan",     price: 30000, features: ["Semua fitur VIP", "Priority support"] },
        { id: "yanzz_vip_perm",   name: "VIP Permanen",    price: 120000, features: ["Semua fitur VIP", "Lifetime", "Priority support"] },
      ],
    },
  ],
};
