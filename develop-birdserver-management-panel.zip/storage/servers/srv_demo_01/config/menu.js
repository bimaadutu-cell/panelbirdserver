/**
 * Configuration for Main Menu Presets
 * This file is managed by the bot and can be overridden by config/_overrides.json
 */

module.exports = {
  activePreset: 1, // Default preset
  presets: {
    1: [
      { text: "🐛 APK BUG", callback_data: "m:apk" },
      { text: "🖥️ Panel Pterodactyl", callback_data: "m:panel" },
      { text: "👤 Profil", callback_data: "m:profil" },
      { text: "🎁 Bonus Harian", callback_data: "m:bonus" },
      { text: "📞 Support", callback_data: "m:support" }
    ],
    2: [
      { text: "🐛 APK BUG", callback_data: "m:apk" },
      { text: "🖥️ Panel Pterodactyl", callback_data: "m:panel" },
      { text: "👤 Profil", callback_data: "m:profil" },
      { text: "📱 BimzCreated (APK CPanel)", callback_data: "m:bimz" },
      { text: "📞 Support", callback_data: "m:support" }
    ],
    3: [
      { text: "🐛 APK BUG", callback_data: "m:apk" },
      { text: "🖥️ Panel Pterodactyl", callback_data: "m:panel" },
      { text: "👤 Profil", callback_data: "m:profil" },
      { text: "📞 Support", callback_data: "m:support" },
      { text: "🎁 Bonus Harian", callback_data: "m:bonus" },
      { text: "📱 BimzCreated (APK CPanel)", callback_data: "m:bimz" }
    ],
    4: [
      { text: "🐛 APK BUG", callback_data: "m:apk" },
      { text: "🖥️ Panel Pterodactyl", callback_data: "m:panel" },
      { text: "🎁 Bonus Harian", callback_data: "m:bonus" },
      { text: "📜 Riwayat Order", callback_data: "m:riwayat" },
      { text: "👤 Profil", callback_data: "m:profil" },
      { text: "📞 Support", callback_data: "m:support" },
      { text: "📱 BimzCreated (APK CPanel)", callback_data: "m:bimz" }
    ],
    5: [
      { text: "🐛 APK BUG", callback_data: "m:apk" },
      { text: "🖥️ Panel Pterodactyl", callback_data: "m:panel" },
      { text: "📜 Riwayat Order", callback_data: "m:riwayat" },
      { text: "👤 Profil", callback_data: "m:profil" },
      { text: "📞 Support", callback_data: "m:support" },
      { text: "🧠 ModeAI", callback_data: "ai:open" },
      { text: "📦 FileBotBuild", callback_data: "fbb:open" },
      { text: "📱 BimzCreated (APK CPanel)", callback_data: "m:bimz" }
    ]
  }
};
