module.exports = {
  cacheEnabled: true,
  cacheTTL: 300, // 5 menit
  asyncTimeout: 15000,
  maxConcurrentTasks: 5,
  retryControlled: true,
  dbOptimization: true
};
