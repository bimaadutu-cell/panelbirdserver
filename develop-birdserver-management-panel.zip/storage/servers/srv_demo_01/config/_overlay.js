// Helper: merge override JSON ke config file dasar.
// Dipakai config/*.js untuk membaca perubahan runtime dari _overrides.json.
const fs = require("fs");
const path = require("path");
const OVERRIDE_FILE = path.join(__dirname, "_overrides.json");

function loadOverrides() {
  try { return JSON.parse(fs.readFileSync(OVERRIDE_FILE, "utf8")); } catch { return {}; }
}
function deepMerge(a, b) {
  if (b === null || b === undefined) return a;
  if (typeof a !== "object" || typeof b !== "object" || Array.isArray(a) || Array.isArray(b)) return b;
  const out = { ...a };
  for (const k of Object.keys(b)) out[k] = deepMerge(a[k], b[k]);
  return out;
}
function overlay(name, base) {
  const all = loadOverrides();
  const patch = all[name];
  if (!patch) return base;
  return deepMerge(base, patch);
}
module.exports = { overlay, loadOverrides };
