const chalk = require("chalk");
const fs = require("fs");
const path = require("path");

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const LEVEL = LEVELS[(process.env.LOG_LEVEL || "info").toLowerCase()] || 20;

const LOG_DIR = path.join(__dirname, "..", "logs");
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

function stamp() {
  return new Date().toISOString().replace("T", " ").slice(0, 19);
}

function write(file, line) {
  try { fs.appendFileSync(path.join(LOG_DIR, file), line + "\n"); } catch {}
}

function log(level, color, ...args) {
  if (LEVELS[level] < LEVEL) return;
  const line = `[${stamp()}] [${level.toUpperCase()}] ${args.map(String).join(" ")}`;
  console.log(color(line));
  write(`${level}.log`, line);
  write("combined.log", line);
}

module.exports = {
  debug: (...a) => log("debug", chalk.gray, ...a),
  info:  (...a) => log("info",  chalk.cyan, ...a),
  warn:  (...a) => log("warn",  chalk.yellow, ...a),
  error: (...a) => log("error", chalk.red, ...a),
  success: (...a) => log("info", chalk.green, ...a),
  event: (name, data) => write("events.log", `[${stamp()}] ${name} ${JSON.stringify(data || {})}`),
};
