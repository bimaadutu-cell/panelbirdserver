// ==============================================
// AI STRUCTURED LOGGER (V5)
// ==============================================
// Log terstruktur untuk setiap panggilan AI Builder.
// Kolom: waktu, provider, model, endpoint, status, durasi(ms), error, response(preview).
// Ditulis ke logs/ai-build.log (append) dan juga console.
// ==============================================
const fs = require("fs");
const path = require("path");
const logger = require("./logger");

const LOG_DIR  = path.join(__dirname, "..", "logs");
const LOG_FILE = path.join(LOG_DIR, "ai-build.log");

try { fs.mkdirSync(LOG_DIR, { recursive: true }); } catch { /* noop */ }

function trim(s, n = 200) {
  s = String(s == null ? "" : s).replace(/\s+/g, " ").trim();
  return s.length > n ? s.slice(0, n) + "…" : s;
}

/**
 * @param {object} rec
 * @param {string} rec.provider
 * @param {string} rec.model
 * @param {string} rec.endpoint
 * @param {string} rec.status  - "ok" | "retry" | "fallback" | "error"
 * @param {number} rec.durationMs
 * @param {string} [rec.error]
 * @param {string} [rec.responsePreview]
 * @param {number} [rec.attempt]
 */
function log(rec) {
  const line = JSON.stringify({
    time: new Date().toISOString(),
    provider: rec.provider,
    model: rec.model,
    endpoint: rec.endpoint,
    status: rec.status,
    attempt: rec.attempt || 1,
    durationMs: rec.durationMs || 0,
    error: rec.error ? trim(rec.error, 300) : undefined,
    response: rec.responsePreview ? trim(rec.responsePreview, 200) : undefined,
  });
  try { fs.appendFileSync(LOG_FILE, line + "\n"); } catch { /* noop */ }

  const tag = `[AI:${rec.provider}/${rec.model}]`;
  if (rec.status === "ok") logger.success(`${tag} ok in ${rec.durationMs}ms`);
  else if (rec.status === "retry") logger.warn(`${tag} retry #${rec.attempt}: ${trim(rec.error, 120)}`);
  else if (rec.status === "fallback") logger.warn(`${tag} fallback: ${trim(rec.error, 120)}`);
  else logger.error(`${tag} error: ${trim(rec.error, 200)}`);
}

module.exports = { log };
