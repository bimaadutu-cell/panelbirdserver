// ==============================================
// STARTUP CONFIG VALIDATOR (V5)
// ==============================================
// Memeriksa file konfigurasi penting saat bot startup.
// Memberi pesan jelas jika ada yang salah — bot tetap jalan tapi
// admin diberi peringatan.
// ==============================================
const logger = require("./logger");

function safeRequire(rel) {
  try { return require(rel); } catch (e) { return { __error: e.message }; }
}

function check(name, cfg, requiredFields) {
  if (!cfg || cfg.__error) {
    logger.error(`[config] ${name}.js gagal dimuat: ${cfg?.__error || "unknown"}`);
    return false;
  }
  for (const f of requiredFields) {
    if (cfg[f] === undefined) {
      logger.warn(`[config] ${name}.js: field '${f}' tidak ditemukan.`);
    }
  }
  return true;
}

function validate() {
  logger.info("═══ Validasi Konfigurasi AI Builder ═══");

  const providers = safeRequire("../config/providers");
  const ai        = safeRequire("../config/ai");
  const builders  = safeRequire("../config/builders");
  const models    = safeRequire("../config/models");
  const lovable   = safeRequire("../config/lovable");

  check("providers", providers, []);
  check("ai",        ai,        ["enabled", "systemPrompt"]);
  check("builders",  builders,  []);
  check("models",    models,    []);
  check("lovable",   lovable,   ["endpoint"]);

  // Cek provider siap
  let ready = 0;
  if (providers && !providers.__error) {
    for (const [key, p] of Object.entries(providers)) {
      if (!p || typeof p !== "object") continue;
      if (!p.enabled) continue;
      const apiKey = (process.env[p.envKey || ""] || p.apiKey || "").trim();
      if (!apiKey) {
        logger.warn(`[config] provider '${key}' aktif tapi API Key kosong (env ${p.envKey}).`);
        continue;
      }
      if (!p.endpoint && !(p.endpoints || []).length) {
        logger.warn(`[config] provider '${key}' tidak punya endpoint.`);
        continue;
      }
      if (!p.model && !(p.models || []).length) {
        logger.warn(`[config] provider '${key}' tidak punya nama model.`);
        continue;
      }
      ready++;
    }
  }

  if (ready === 0) {
    logger.error("[config] TIDAK ADA provider AI yang siap. FileBotBuild akan gagal.");
    logger.error("[config] Perbaiki config/providers.js atau isi API Key di .env");
  } else {
    logger.success(`[config] ${ready} provider AI siap dipakai.`);
  }

  logger.info("══════════════════════════════════════");
}

module.exports = { validate };
