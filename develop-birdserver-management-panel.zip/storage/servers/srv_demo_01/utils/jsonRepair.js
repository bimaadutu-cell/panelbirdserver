// ==============================================
// JSON REPAIR UTIL (V5)
// ==============================================
// Parser tahan banting untuk response AI:
//  1. Buang markdown fence ```json ... ```
//  2. Buang teks sebelum '{' dan setelah '}' terakhir
//  3. Ganti smart quotes → ASCII
//  4. Hapus trailing comma
//  5. Hapus komentar // dan /* */
//  6. Fallback: JSON.parse langsung
// ==============================================

function stripFences(s) {
  return s
    .replace(/^\uFEFF/, "")
    .replace(/^```(?:json|javascript|js)?\s*/i, "")
    .replace(/```\s*$/i, "")
    .replace(/```(?:json|javascript|js)?/gi, "")
    .replace(/```/g, "")
    .trim();
}

function extractBiggestJsonBlock(s) {
  const first = s.indexOf("{");
  const last  = s.lastIndexOf("}");
  if (first === -1 || last === -1 || last <= first) return s;
  return s.slice(first, last + 1);
}

function normalizeQuotes(s) {
  return s
    .replace(/[\u2018\u2019\u201A\u201B]/g, "'")
    .replace(/[\u201C\u201D\u201E\u201F]/g, '"');
}

function stripComments(s) {
  // Hapus /* ... */ dan // sampai akhir baris (aman untuk output AI generik)
  return s
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/(^|[^:"'\\])\/\/[^\n]*/g, "$1");
}

function removeTrailingCommas(s) {
  return s.replace(/,(\s*[}\]])/g, "$1");
}

function fixControlChars(s) {
  // Ganti karakter kontrol tak-ter-escape di dalam string JSON dengan spasi.
  // Best-effort: cukup untuk kasus umum.
  return s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, " ");
}

/**
 * Parse JSON dari raw string AI. Kembalikan objek atau lempar Error.
 */
function safeParseJSON(raw) {
  if (raw == null) throw new Error("respons kosong");
  let text = String(raw).trim();

  // 1. Coba langsung dulu (kasus paling umum)
  try { return JSON.parse(text); } catch { /* lanjut repair */ }

  // 2. Bersihkan bertahap
  text = stripFences(text);
  text = normalizeQuotes(text);
  text = extractBiggestJsonBlock(text);
  text = stripComments(text);
  text = removeTrailingCommas(text);
  text = fixControlChars(text);

  try { return JSON.parse(text); } catch (e1) {
    // 3. Coba re-quote key tanpa quote: { foo: 1 } → { "foo": 1 }
    const requoted = text.replace(
      /([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)(\s*:)/g,
      '$1"$2"$3'
    );
    try { return JSON.parse(requoted); } catch (e2) {
      throw new Error("JSON tidak valid: " + (e2.message || e1.message));
    }
  }
}

module.exports = { safeParseJSON };
