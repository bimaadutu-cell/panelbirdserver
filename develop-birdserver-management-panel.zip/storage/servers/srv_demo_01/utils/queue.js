// Antrian sederhana dengan concurrency + retry & backoff.
class Queue {
  constructor({ concurrency = 1, retry = { attempts: 1, backoffMs: 1000 } } = {}) {
    this.concurrency = concurrency;
    this.retry = retry;
    this.running = 0;
    this.pending = [];
  }
  push(taskFn) {
    return new Promise((resolve, reject) => {
      this.pending.push({ taskFn, resolve, reject, tries: 0 });
      this._drain();
    });
  }
  async _drain() {
    while (this.running < this.concurrency && this.pending.length) {
      const job = this.pending.shift();
      this.running++;
      this._runJob(job).finally(() => {
        this.running--;
        this._drain();
      });
    }
  }
  async _runJob(job) {
    try {
      const res = await job.taskFn();
      job.resolve(res);
    } catch (e) {
      job.tries++;
      if (job.tries < this.retry.attempts) {
        setTimeout(() => { this.pending.unshift(job); this._drain(); }, this.retry.backoffMs * job.tries);
      } else {
        job.reject(e);
      }
    }
  }
}
module.exports = { Queue };
