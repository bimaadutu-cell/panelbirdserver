# CHANGELOG V5.2

## Perbaikan & Peningkatan Menu
- **Fix /setfitur**: Sekarang menampilkan tombol Inline Keyboard (Set Fitur 1-5) secara benar. Admin cukup menekan tombol tanpa perlu mengetik angka.
- **Menu Dinamis**: Menu utama selalu dibangun ulang dari `config/menu.js` setiap kali user membuka Home, memastikan data selalu terbaru.
- **Realtime Reload**: Pergantian preset menghapus menu lama, menghapus cache, dan memuat menu baru secara instan tanpa perlu restart bot.
- **Pembersihan Tombol**: Menjamin tidak ada tombol sisa atau duplikasi menu saat berganti antar preset.

## Fitur Baru
- **🚨 Lapor ke Admin**: Fitur pelaporan baru. User masuk ke Mode Laporan, menulis pesan, dan bot otomatis meneruskannya ke Admin.
- **Mode Laporan**: Dilengkapi dengan tombol "❌ Keluar Mode Laporan" untuk kembali ke menu utama dengan mudah.
- **Config Report**: Penambahan `config/report.js` untuk mengatur tujuan laporan (Telegram/WhatsApp) dan identitas admin secara fleksibel.

## Penyederhanaan Panel
- **🖥️ Paket Basic**: Menu Panel Pterodactyl disederhanakan. Menghapus paket Premium, Unlimited, VIP, dll.
- **Direct Access**: Saat memilih Panel, user langsung diarahkan ke pilihan spesifikasi di bawah Paket Basic.

## Teknis
- **Non-Cache Require**: Implementasi `delete require.cache` pada modul konfigurasi sensitif untuk mendukung perubahan realtime yang benar-benar sinkron.
- **Cross-Platform Compatibility**: Memastikan format tombol bekerja baik di Telegram maupun WhatsApp.
