# CHANGELOG — BOT STORE V5 (FILEBOTBUILD PRO)

## 🚀 Upgrade Total AI Builder

### 1. Batas input ide → 50.000 karakter
- `config/filebuilder.js` → `maxIdeaChars: 50000`.
- Prompt panjang otomatis **di-chunk** (default 12.000 char/chunk, konfigurable
  via `chunkChars`) lalu digabung menjadi satu proyek utuh.

### 2. Konfigurasi provider terpusat — `config/providers.js`
- Satu file untuk semua provider (Manus, Gemini, Lovable, OpenAI, dst).
- `endpoints[]` = daftar fallback endpoint per provider (Manus AI 404 → coba
  endpoint berikutnya di config, TANPA edit source).
- `models[]` = daftar fallback model.
- `retry: { attempts, backoffMs }` = retry per provider.
- **Tidak ada URL yang di-hardcode** di source code utama.

### 3. Perbaikan Manus AI (404 Not Found)
- Preflight cek base URL, endpoint, API key, model, koneksi.
- Bila endpoint utama 404/DNS gagal → otomatis pindah ke endpoint
  cadangan di `config/providers.js` (`endpoints[]`).
- Bila semua endpoint gagal → baru fallback ke provider berikutnya.

### 4. Perbaikan Gemini (JSON Error)
- Parser baru `utils/jsonRepair.js`:
  - hapus markdown fence, smart quotes, komentar, trailing comma
  - ambil blok JSON terbesar
  - re-quote key tanpa quote
  - fix karakter kontrol
- Request Gemini dipaksa `responseMimeType: application/json`.
- Bila JSON masih rusak → retry (attempts×) sebelum fallback provider.

### 5. Auto Retry
- 3× percobaan per provider dengan **exponential backoff**
  (`backoffMs * attempt`).
- Baru fallback ke provider berikutnya setelah 3× gagal.

### 6. Fallback Provider
Urutan (dari `priority` di `config/providers.js`):
1. Manus AI → 2. Gemini → 3. Lovable AI → 4. OpenAI → …

### 7. Progress Build Baru (edit pesan berurutan)
- 🔍 Memeriksa Konfigurasi
- 🌐 Menghubungkan AI
- 🧠 Menganalisis Ide *(bagian n/total bila di-chunk)*
- 📂 Membuat Struktur Folder
- ⚙️ Membuat Source Code
- 📦 Membuat Package
- 📖 Membuat README
- 🗜️ Mengarsipkan Project
- ✅ Build Berhasil

### 8. Logging terstruktur — `logs/ai-build.log`
JSON per baris: waktu, provider, model, endpoint, status, attempt, durasi,
error, preview response.

### 9. Validasi konfigurasi saat startup
`utils/validateConfig.js` dijalankan di `index.js`:
- Cek `providers.js`, `ai.js`, `builders.js`, `models.js`, `lovable.js`.
- Beri peringatan jelas bila API key kosong / endpoint tidak valid.

### 10. Hasil Build
Project ZIP berisi:
- Struktur folder rapi (config/ commands/ events/ utils/ database/ dst)
- `package.json`, `README.md`, `.env.example`, `.gitignore`
- `index.js` entrypoint siap jalan
- Dokumentasi instalasi & penggunaan di `README.md`

## Kompatibilitas
- File `config/builders.js` lama tetap ada untuk backward-compat, namun
  **provider utama yang dipakai adalah `config/providers.js`**.
- Handler & UX Bot Store lainnya (order, panel, payment) tidak diubah.
