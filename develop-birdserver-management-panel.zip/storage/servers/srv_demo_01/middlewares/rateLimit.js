const settings = require("../config/settings");
const buckets = new Map();

function check(chatId) {
  const now = Date.now();
  const key = String(chatId);
  const b = buckets.get(key) || { count: 0, resetAt: now + 60_000, lastAt: 0 };
  if (now > b.resetAt) { b.count = 0; b.resetAt = now + 60_000; }
  if (now - b.lastAt < settings.security.antiSpamCooldownMs) {
    return { allowed: false, reason: "spam" };
  }
  b.count++; b.lastAt = now;
  buckets.set(key, b);
  if (b.count > settings.security.rateLimitPerMinute) return { allowed: false, reason: "rate" };
  return { allowed: true };
}

module.exports = { check };
