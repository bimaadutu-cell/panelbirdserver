// ==============================================
// MIDDLEWARE VERIFIKASI JOIN CHANNEL + GRUP
// ==============================================
// Dipanggil setiap user berinteraksi dengan bot Telegram.
// Menggunakan Telegram Bot API getChatMember.
// ==============================================
const tgCfg = require("../config/telegram");
const logger = require("../utils/logger");

const OK_STATUS = new Set(["creator", "administrator", "member", "restricted"]);

/**
 * @param {import('node-telegram-bot-api')} bot  instance Telegram bot
 * @param {number|string} userId  telegram user id
 * @returns {Promise<{ok:boolean, channel:boolean, group:boolean}>}
 */
async function checkMembership(bot, userId) {
  if (!tgCfg.enabled) return { ok: true, channel: true, group: true };

  const targets = [
    { key: "channel", id: tgCfg.channel?.id },
    { key: "group", id: tgCfg.group?.id },
  ].filter((t) => t.id);

  const result = { ok: true, channel: true, group: true };

  for (const t of targets) {
    try {
      const m = await bot.getChatMember(t.id, userId);
      const joined = m && OK_STATUS.has(m.status);
      result[t.key] = joined;
      if (!joined) result.ok = false;
    } catch (e) {
      // status "left" throws pada beberapa channel; anggap belum join
      logger.warn(`verifyJoin ${t.key} (${t.id}) fail: ${e.message}`);
      result[t.key] = false;
      result.ok = false;
    }
  }
  return result;
}

/** Inline keyboard untuk halaman "AKSES DITOLAK". */
function deniedKeyboard() {
  const rows = [];
  if (tgCfg.channel?.invite)
    rows.push([{ text: "📢 Join Channel", url: tgCfg.channel.invite }]);
  if (tgCfg.group?.invite)
    rows.push([{ text: "👥 Join Grup", url: tgCfg.group.invite }]);
  rows.push([{ text: "✅ Saya Sudah Join", callback_data: "verify:recheck" }]);
  return { inline_keyboard: rows };
}

module.exports = { checkMembership, deniedKeyboard };
