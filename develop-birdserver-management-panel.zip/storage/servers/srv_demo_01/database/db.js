// SQLite (better-sqlite3) — sinkron, ringan, tahan crash. Semua tabel dibuat otomatis.
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const DIR = path.join(__dirname);
if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });
const db = new Database(path.join(DIR, "store.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform TEXT, chat_id TEXT, jid TEXT,
  name TEXT, username TEXT, email TEXT, whatsapp TEXT,
  created_at INTEGER, updated_at INTEGER,
  UNIQUE(platform, chat_id)
);
CREATE TABLE IF NOT EXISTS sessions (
  chat_id TEXT PRIMARY KEY,
  platform TEXT,
  data TEXT,
  updated_at INTEGER
);
CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY,
  order_id TEXT,
  chat_id TEXT,
  platform TEXT,
  amount INTEGER,
  method TEXT,
  status TEXT,     -- pending | paid | expired | rejected
  expires_at INTEGER,
  created_at INTEGER,
  paid_at INTEGER
);
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  invoice_id TEXT,
  chat_id TEXT,
  platform TEXT,
  type TEXT,         -- panel | apk | other
  server_key TEXT,
  role TEXT,
  size TEXT,
  amount INTEGER,
  customer TEXT,     -- json (name, username, email, wa)
  status TEXT,       -- awaiting_payment | verifying | processing | delivered | failed | expired
  panel TEXT,        -- json (user, pass, url, ram, cpu, disk, server_id, expired_at)
  expired_at INTEGER,
  created_at INTEGER,
  updated_at INTEGER
);
CREATE TABLE IF NOT EXISTS panels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id TEXT,
  server_key TEXT,
  panel_user_id INTEGER,
  panel_server_id INTEGER,
  username TEXT,
  password TEXT,
  url TEXT,
  ram INTEGER, cpu INTEGER, disk INTEGER,
  expired_at INTEGER,
  status TEXT,   -- active | deleted | failed
  created_at INTEGER
);
CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_id TEXT,
  amount INTEGER,
  method TEXT,
  reported_amount INTEGER,
  reference TEXT,
  proof_path TEXT,
  status TEXT,   -- pending | valid | invalid
  reason TEXT,
  created_at INTEGER
);
CREATE TABLE IF NOT EXISTS logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT, level TEXT, message TEXT, meta TEXT, created_at INTEGER
);
CREATE TABLE IF NOT EXISTS announcements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  text TEXT, created_at INTEGER, active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS server_meta (
  server_key TEXT PRIMARY KEY,
  data TEXT,   -- json cache node/nest/egg/location
  updated_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_expired ON orders(expired_at);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
`);

// ---- Migrations (idempotent) ----
function hasColumn(table, col) {
  return db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === col);
}
if (!hasColumn("users", "balance"))    db.exec(`ALTER TABLE users ADD COLUMN balance INTEGER DEFAULT 0`);
if (!hasColumn("users", "role"))       db.exec(`ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'user'`);
if (!hasColumn("users", "total_order"))db.exec(`ALTER TABLE users ADD COLUMN total_order INTEGER DEFAULT 0`);
if (!hasColumn("users", "terms_accepted_at")) db.exec(`ALTER TABLE users ADD COLUMN terms_accepted_at INTEGER`);
if (!hasColumn("payments","attempts")) db.exec(`ALTER TABLE payments ADD COLUMN attempts INTEGER DEFAULT 1`);

db.exec(`
CREATE TABLE IF NOT EXISTS bonus_claims (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform TEXT, chat_id TEXT,
  amount INTEGER,
  claimed_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_bonus_chat ON bonus_claims(platform,chat_id,claimed_at);

CREATE TABLE IF NOT EXISTS balance_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform TEXT, chat_id TEXT,
  type TEXT,          -- credit_bonus | credit_topup | debit_order | admin_adjust
  amount INTEGER,     -- positif=masuk, negatif=keluar
  balance_after INTEGER,
  note TEXT,
  created_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_bal_chat ON balance_history(platform,chat_id,created_at);

CREATE TABLE IF NOT EXISTS bimz_orders (
  id TEXT PRIMARY KEY,
  invoice_id TEXT,
  platform TEXT, chat_id TEXT,
  role TEXT, price INTEGER,
  customer TEXT,
  status TEXT,        -- awaiting_payment | delivered | failed
  created_at INTEGER
);
`);


const now = () => Date.now();

module.exports = {
  raw: db,
  // ---- users ----
  upsertUser(u) {
    const existing = db.prepare(`SELECT id FROM users WHERE platform=? AND chat_id=?`).get(u.platform, u.chatId);
    if (existing) {
      db.prepare(`UPDATE users SET name=COALESCE(?,name), username=COALESCE(?,username),
        email=COALESCE(?,email), whatsapp=COALESCE(?,whatsapp),
        terms_accepted_at=COALESCE(?,terms_accepted_at), updated_at=? WHERE id=?`)
        .run(u.name || null, u.username || null, u.email || null, u.whatsapp || null,
             u.terms_accepted_at || null, now(), existing.id);
      return existing.id;
    }
    const info = db.prepare(`INSERT INTO users(platform,chat_id,jid,name,username,email,whatsapp,terms_accepted_at,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?)`)
      .run(u.platform, u.chatId, u.jid || null, u.name || null, u.username || null,
           u.email || null, u.whatsapp || null, u.terms_accepted_at || null, now(), now());
    return info.lastInsertRowid;
  },
  // ---- session ----
  getSession(chatId) {
    const row = db.prepare(`SELECT data FROM sessions WHERE chat_id=?`).get(String(chatId));
    return row ? JSON.parse(row.data) : null;
  },
  setSession(chatId, platform, data) {
    if (data === null) {
      db.prepare(`DELETE FROM sessions WHERE chat_id=?`).run(String(chatId));
      return;
    }
    db.prepare(`INSERT INTO sessions(chat_id,platform,data,updated_at) VALUES(?,?,?,?)
      ON CONFLICT(chat_id) DO UPDATE SET data=excluded.data, updated_at=excluded.updated_at`)
      .run(String(chatId), platform, JSON.stringify(data), now());
  },
  // ---- invoice ----
  createInvoice(inv) {
    db.prepare(`INSERT INTO invoices(id,order_id,chat_id,platform,amount,method,status,expires_at,created_at)
      VALUES(?,?,?,?,?,?,?,?,?)`)
      .run(inv.id, inv.orderId, inv.chatId, inv.platform, inv.amount, inv.method, "pending", inv.expiresAt, now());
    return inv;
  },
  getInvoice(id) { return db.prepare(`SELECT * FROM invoices WHERE id=?`).get(id); },
  getActiveInvoiceByChat(chatId) {
    return db.prepare(`SELECT * FROM invoices WHERE chat_id=? AND status='pending' ORDER BY created_at DESC LIMIT 1`).get(String(chatId));
  },
  markInvoicePaid(id) {
    db.prepare(`UPDATE invoices SET status='paid', paid_at=? WHERE id=?`).run(now(), id);
  },
  markInvoiceExpired(id) {
    db.prepare(`UPDATE invoices SET status='expired' WHERE id=?`).run(id);
  },
  markInvoiceRejected(id) {
    db.prepare(`UPDATE invoices SET status='rejected' WHERE id=?`).run(id);
  },
  expireStaleInvoices() {
    db.prepare(`UPDATE invoices SET status='expired' WHERE status='pending' AND expires_at < ?`).run(now());
  },
  // ---- order ----
  createOrder(o) {
    db.prepare(`INSERT INTO orders(id,invoice_id,chat_id,platform,type,server_key,role,size,amount,customer,status,expired_at,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(o.id, o.invoiceId, o.chatId, o.platform, o.type, o.serverKey || null, o.role || null,
           o.size ? String(o.size) : null, o.amount, JSON.stringify(o.customer || {}), o.status || "awaiting_payment",
           o.expiredAt || null, now(), now());
    return o;
  },
  getOrder(id) {
    const r = db.prepare(`SELECT * FROM orders WHERE id=?`).get(id);
    if (!r) return null;
    r.customer = r.customer ? JSON.parse(r.customer) : {};
    r.panel = r.panel ? JSON.parse(r.panel) : null;
    return r;
  },
  updateOrder(id, patch) {
    const cur = this.getOrder(id); if (!cur) return null;
    const merged = { ...cur, ...patch, updated_at: now() };
    db.prepare(`UPDATE orders SET status=?, panel=?, expired_at=?, updated_at=? WHERE id=?`)
      .run(merged.status, merged.panel ? JSON.stringify(merged.panel) : null,
           merged.expired_at || null, merged.updated_at, id);
    return merged;
  },
  ordersByChat(chatId, limit = 10) {
    return db.prepare(`SELECT * FROM orders WHERE chat_id=? ORDER BY created_at DESC LIMIT ?`).all(String(chatId), limit);
  },
  expiredActivePanels() {
    return db.prepare(`SELECT * FROM orders WHERE type='panel' AND status='delivered' AND expired_at IS NOT NULL AND expired_at < ?`).all(now());
  },
  // ---- panel ----
  savePanel(p) {
    db.prepare(`INSERT INTO panels(order_id,server_key,panel_user_id,panel_server_id,username,password,url,ram,cpu,disk,expired_at,status,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(p.orderId, p.serverKey, p.panelUserId, p.panelServerId, p.username, p.password, p.url,
           p.ram, p.cpu, p.disk, p.expiredAt, "active", now());
  },
  panelByOrder(orderId) {
    return db.prepare(`SELECT * FROM panels WHERE order_id=?`).get(orderId);
  },
  markPanelDeleted(orderId) {
    db.prepare(`UPDATE panels SET status='deleted' WHERE order_id=?`).run(orderId);
  },
  // ---- payment ----
  savePayment(p) {
    db.prepare(`INSERT INTO payments(invoice_id,amount,method,reported_amount,reference,proof_path,status,reason,created_at)
      VALUES(?,?,?,?,?,?,?,?,?)`)
      .run(p.invoiceId, p.amount, p.method, p.reportedAmount || null, p.reference || null,
           p.proofPath || null, p.status, p.reason || null, now());
  },
  // ---- server meta cache ----
  getServerMeta(key) {
    const r = db.prepare(`SELECT * FROM server_meta WHERE server_key=?`).get(key);
    if (!r) return null;
    return { data: JSON.parse(r.data), updatedAt: r.updated_at };
  },
  setServerMeta(key, data) {
    db.prepare(`INSERT INTO server_meta(server_key,data,updated_at) VALUES(?,?,?)
      ON CONFLICT(server_key) DO UPDATE SET data=excluded.data, updated_at=excluded.updated_at`)
      .run(key, JSON.stringify(data), now());
  },
  // ---- logs ----
  log(category, level, message, meta) {
    db.prepare(`INSERT INTO logs(category,level,message,meta,created_at) VALUES(?,?,?,?,?)`)
      .run(category, level, message, meta ? JSON.stringify(meta) : null, now());
  },
  // ---- announcements ----
  addAnnouncement(text) {
    db.prepare(`INSERT INTO announcements(text,created_at,active) VALUES(?,?,1)`).run(text, now());
  },
  listAnnouncements() {
    return db.prepare(`SELECT * FROM announcements WHERE active=1 ORDER BY created_at DESC`).all();
  },
  allUsers() { return db.prepare(`SELECT * FROM users`).all(); },
};

// ---- Extended API: user profile, balance, bonus ----
const api = module.exports;

api.getUser = function (chatId, platform) {
  const row = platform
    ? db.prepare(`SELECT * FROM users WHERE chat_id=? AND platform=?`).get(String(chatId), platform)
    : db.prepare(`SELECT * FROM users WHERE chat_id=?`).get(String(chatId));
  return row || null;
};

api.getBalance = function (chatId, platform) {
  const u = api.getUser(chatId, platform);
  return u ? Number(u.balance || 0) : 0;
};

api.addBalance = function ({ chatId, platform, amount, type, note }) {
  const u = api.getUser(chatId, platform);
  if (!u) throw new Error("User tidak ditemukan.");
  const newBal = Number(u.balance || 0) + Number(amount);
  if (newBal < 0) throw new Error("Saldo tidak mencukupi.");
  db.prepare(`UPDATE users SET balance=?, updated_at=? WHERE id=?`).run(newBal, now(), u.id);
  db.prepare(`INSERT INTO balance_history(platform,chat_id,type,amount,balance_after,note,created_at)
    VALUES(?,?,?,?,?,?,?)`)
    .run(u.platform, u.chat_id, type, amount, newBal, note || null, now());
  return newBal;
};

api.balanceHistory = function (chatId, platform, limit = 20) {
  return db.prepare(`SELECT * FROM balance_history WHERE chat_id=? AND platform=?
    ORDER BY created_at DESC LIMIT ?`).all(String(chatId), platform, limit);
};

api.incrementOrderCount = function (chatId, platform) {
  const u = api.getUser(chatId, platform); if (!u) return;
  db.prepare(`UPDATE users SET total_order=COALESCE(total_order,0)+1, updated_at=? WHERE id=?`)
    .run(now(), u.id);
};

// ---- Bonus harian ----
api.lastBonusClaim = function (chatId, platform) {
  return db.prepare(`SELECT * FROM bonus_claims WHERE chat_id=? AND platform=?
    ORDER BY claimed_at DESC LIMIT 1`).get(String(chatId), platform);
};
api.recordBonusClaim = function ({ chatId, platform, amount }) {
  db.prepare(`INSERT INTO bonus_claims(platform,chat_id,amount,claimed_at) VALUES(?,?,?,?)`)
    .run(platform, String(chatId), amount, now());
};
api.bonusHistory = function (chatId, platform, limit = 20) {
  return db.prepare(`SELECT * FROM bonus_claims WHERE chat_id=? AND platform=?
    ORDER BY claimed_at DESC LIMIT ?`).all(String(chatId), platform, limit);
};

// ---- Payment attempts helper ----
api.paymentAttempts = function (invoiceId) {
  const r = db.prepare(`SELECT COUNT(*) as c FROM payments WHERE invoice_id=?`).get(invoiceId);
  return r ? r.c : 0;
};

// ---- BimzCreated orders ----
api.createBimzOrder = function (o) {
  db.prepare(`INSERT INTO bimz_orders(id,invoice_id,platform,chat_id,role,price,customer,status,created_at)
    VALUES(?,?,?,?,?,?,?,?,?)`)
    .run(o.id, o.invoiceId, o.platform, String(o.chatId), o.role, o.price,
         JSON.stringify(o.customer || {}), o.status || "awaiting_payment", now());
};
api.getBimzOrder = function (id) {
  const r = db.prepare(`SELECT * FROM bimz_orders WHERE id=?`).get(id);
  if (r && r.customer) r.customer = JSON.parse(r.customer);
  return r;
};
api.markBimzDelivered = function (id) {
  db.prepare(`UPDATE bimz_orders SET status='delivered' WHERE id=?`).run(id);
};
