const fs = require("fs");
const path = require("path");
const mediaCfg = require("../config/media");

function getMediaPath(kind) {
  const assetsDir = path.join(__dirname, "..", mediaCfg.assetsDir || "media");
  const options = mediaCfg.mapping[kind] || [];
  
  for (const filename of options) {
    const fullPath = path.join(assetsDir, filename);
    if (fs.existsSync(fullPath)) {
      return {
        path: fullPath,
        type: getMediaType(filename),
        ext: path.extname(filename).toLowerCase()
      };
    }
  }
  
  // Fallback to default banner
  const defaultPath = path.join(assetsDir, mediaCfg.defaultBanner || "banner.jpg");
  if (fs.existsSync(defaultPath)) {
    return {
      path: defaultPath,
      type: getMediaType(mediaCfg.defaultBanner),
      ext: path.extname(mediaCfg.defaultBanner).toLowerCase()
    };
  }
  
  return null;
}

function getMediaType(filename) {
  const ext = path.extname(filename).toLowerCase();
  if (mediaCfg.supportedImages.includes(ext)) return "image";
  if (mediaCfg.supportedVideos.includes(ext)) return "video";
  if (ext === ".gif") return "gif";
  return "unknown";
}

module.exports = { getMediaPath, getMediaType };
