const store = require("../config/store");

const rupiah = (n) => "Rp" + Number(n || 0).toLocaleString("id-ID");

const genUsername = (name) =>
  (name || "user").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 12) +
  Math.floor(Math.random() * 900 + 100);

const genPassword = () =>
  Math.random().toString(36).slice(2, 8) + Math.random().toString(36).slice(2, 6).toUpperCase();

const genInvoiceId = () =>
  "INV" +
  new Date().toISOString().slice(2, 10).replace(/-/g, "") +
  Math.floor(Math.random() * 9000 + 1000);

const genOrderId = () =>
  "ORD" + Date.now().toString(36).toUpperCase() +
  Math.floor(Math.random() * 900 + 100);

const fmtDate = (ts) =>
  new Date(ts).toLocaleString("id-ID", { timeZone: store.timezone, hour12: false });

module.exports = { rupiah, genUsername, genPassword, genInvoiceId, genOrderId, fmtDate };
