// ==============================================
// FILEBOTBUILD — TEMPLATES (V3.3)
// ==============================================
// Kerangka minimal proyek bot yang selalu digenerate.
// AI (Lovable) akan menambahkan/meng-override file commands, events, utils
// sesuai deskripsi user.
// ==============================================

function pkg({ name, platform, version, author }) {
  const deps = platform === "whatsapp"
    ? {
        "@whiskeysockets/baileys": "^6.7.9",
        "pino": "^9.4.0",
        "qrcode-terminal": "^0.12.0",
        "dotenv": "^16.4.5",
      }
    : {
        "node-telegram-bot-api": "^0.66.0",
        "dotenv": "^16.4.5",
      };
  return JSON.stringify({
    name: name || `bot-${platform}`,
    version: version || "1.0.0",
    description: `AI-generated ${platform} bot by BimzCreated FileBotBuild`,
    main: "index.js",
    scripts: {
      start: "node index.js",
      dev: "node --watch index.js",
    },
    author: author || "BimzCreated",
    license: "MIT",
    engines: { node: ">=18" },
    dependencies: deps,
  }, null, 2);
}

function envExample(platform) {
  if (platform === "whatsapp") {
    return `# WhatsApp bot (Baileys 6.7 pairing code)
OWNER_NUMBER=628xxxxxxxxxx
PAIRING_NUMBER=628xxxxxxxxxx
PREFIX=.
`;
  }
  return `# Telegram bot
BOT_TOKEN=isi_token_dari_@BotFather
OWNER_ID=123456789
PREFIX=/
`;
}

function readme({ name, platform, idea }) {
  return `# ${name || `Bot ${platform}`}\n\n` +
`> Dihasilkan otomatis oleh **BimzCreated FileBotBuild** (BOT STORE V3).\n\n` +
`## 📌 Deskripsi\n${idea}\n\n` +
`## 🚀 Cara Menjalankan\n` +
`1. \`npm install\`\n` +
`2. Salin \`.env.example\` menjadi \`.env\` lalu isi.\n` +
`3. \`npm start\`\n\n` +
(platform === "whatsapp"
  ? `## 📱 Pairing (WhatsApp)\nSaat pertama jalan, masukkan nomor WhatsApp — bot akan menampilkan **pairing code** untuk dimasukkan di WhatsApp → Perangkat Tertaut.\n\n`
  : `## 🤖 Telegram\nIsi \`BOT_TOKEN\` dari @BotFather di \`.env\` kemudian jalankan.\n\n`) +
`## 📁 Struktur\n\n\`\`\`\n${name || `bot-${platform}`}/\n├── config/\n├── commands/\n├── events/\n├── utils/\n├── index.js\n├── .env.example\n├── package.json\n└── README.md\n\`\`\`\n`;
}

function configFile(platform) {
  return `// config/index.js
require("dotenv").config();
module.exports = {
  prefix: process.env.PREFIX || "${platform === "whatsapp" ? "." : "/"}",
  owner: process.env.${platform === "whatsapp" ? "OWNER_NUMBER" : "OWNER_ID"} || "",
  ${platform === "telegram" ? 'botToken: process.env.BOT_TOKEN || "",' : 'pairingNumber: process.env.PAIRING_NUMBER || "",'}
};
`;
}

function indexFile(platform) {
  if (platform === "whatsapp") {
    return `// index.js — WhatsApp bot (Baileys 6.7 pairing code)
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const readline = require("readline");
const path = require("path");
const fs = require("fs");
const config = require("./config");
const { loadCommands } = require("./utils/loader");
const events = require("./events");

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState(path.join(__dirname, "auth"));
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    auth: state,
    printQRInTerminal: false,
    browser: ["FileBotBuild", "Chrome", "1.0"],
  });

  // Pairing code
  if (!sock.authState.creds.registered) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const num = await new Promise((r) => rl.question("Nomor WhatsApp (628xxx): ", r));
    rl.close();
    const code = await sock.requestPairingCode(num.replace(/\\D/g, ""));
    console.log("Pairing Code:", code);
  }

  const commands = loadCommands(path.join(__dirname, "commands"));
  sock.ev.on("creds.update", saveCreds);
  sock.ev.on("connection.update", (u) => events.connection(sock, u, start));
  sock.ev.on("messages.upsert", (m) => events.message(sock, m, commands, config));
}
start().catch(console.error);
`;
  }
  return `// index.js — Telegram bot
require("dotenv").config();
const TelegramBot = require("node-telegram-bot-api");
const path = require("path");
const config = require("./config");
const { loadCommands } = require("./utils/loader");
const events = require("./events");

if (!config.botToken) {
  console.error("BOT_TOKEN belum diisi di .env");
  process.exit(1);
}

const bot = new TelegramBot(config.botToken, { polling: true });
const commands = loadCommands(path.join(__dirname, "commands"));

bot.on("message", (msg) => events.message(bot, msg, commands, config));
bot.on("polling_error", (e) => console.error("polling_error", e.message));
console.log("✅ Bot Telegram aktif.");
`;
}

function loaderUtil() {
  return `// utils/loader.js
const fs = require("fs");
const path = require("path");
function loadCommands(dir) {
  const map = new Map();
  if (!fs.existsSync(dir)) return map;
  for (const f of fs.readdirSync(dir)) {
    if (!f.endsWith(".js")) continue;
    try {
      const mod = require(path.join(dir, f));
      if (mod?.name && typeof mod.run === "function") map.set(mod.name.toLowerCase(), mod);
    } catch (e) { console.error("load fail", f, e.message); }
  }
  return map;
}
module.exports = { loadCommands };
`;
}

function eventsIndex(platform) {
  if (platform === "whatsapp") {
    return `// events/index.js
const { DisconnectReason } = require("@whiskeysockets/baileys");
module.exports = {
  connection(sock, u, restart) {
    const { connection, lastDisconnect } = u;
    if (connection === "close") {
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log("closed. reconnect?", shouldReconnect);
      if (shouldReconnect) restart();
    } else if (connection === "open") {
      console.log("✅ Bot WhatsApp terhubung.");
    }
  },
  async message(sock, m, commands, config) {
    const msg = m.messages?.[0];
    if (!msg?.message || msg.key.fromMe) return;
    const from = msg.key.remoteJid;
    const text = msg.message.conversation
      || msg.message.extendedTextMessage?.text
      || msg.message.imageMessage?.caption
      || "";
    if (!text.startsWith(config.prefix)) return;
    const [cmd, ...args] = text.slice(config.prefix.length).trim().split(/\\s+/);
    const handler = commands.get(cmd.toLowerCase());
    if (!handler) return;
    try { await handler.run({ sock, msg, from, args, text, config }); }
    catch (e) { await sock.sendMessage(from, { text: "❌ " + e.message }); }
  },
};
`;
  }
  return `// events/index.js
module.exports = {
  async message(bot, msg, commands, config) {
    const text = msg.text || "";
    if (!text.startsWith(config.prefix)) return;
    const [cmd, ...args] = text.slice(config.prefix.length).trim().split(/\\s+/);
    const handler = commands.get(cmd.toLowerCase());
    if (!handler) return;
    try { await handler.run({ bot, msg, args, text, config }); }
    catch (e) { await bot.sendMessage(msg.chat.id, "❌ " + e.message); }
  },
};
`;
}

function pingCommand(platform) {
  if (platform === "whatsapp") {
    return `// commands/ping.js
module.exports = {
  name: "ping",
  desc: "Cek bot",
  async run({ sock, from }) {
    await sock.sendMessage(from, { text: "🏓 Pong! Bot aktif." });
  },
};
`;
  }
  return `// commands/ping.js
module.exports = {
  name: "ping",
  desc: "Cek bot",
  async run({ bot, msg }) {
    await bot.sendMessage(msg.chat.id, "🏓 Pong! Bot aktif.");
  },
};
`;
}

function menuCommand(platform) {
  if (platform === "whatsapp") {
    return `// commands/menu.js
module.exports = {
  name: "menu",
  desc: "Daftar perintah",
  async run({ sock, from, config }) {
    const list = [
      "📖 *MENU BOT*",
      "━━━━━━━━━━━━━",
      config.prefix + "ping — cek bot",
      config.prefix + "menu — tampilkan menu",
    ].join("\\n");
    await sock.sendMessage(from, { text: list });
  },
};
`;
  }
  return `// commands/menu.js
module.exports = {
  name: "menu",
  desc: "Daftar perintah",
  async run({ bot, msg, config }) {
    const list = [
      "📖 *MENU BOT*",
      "━━━━━━━━━━━━━",
      config.prefix + "ping — cek bot",
      config.prefix + "menu — tampilkan menu",
    ].join("\\n");
    await bot.sendMessage(msg.chat.id, list, { parse_mode: "Markdown" });
  },
};
`;
}

function gitignore() {
  return `node_modules\n.env\nauth/\n*.log\n`;
}

function baseFiles({ name, platform, idea, author, version }) {
  return {
    "package.json": pkg({ name, platform, version, author }),
    ".env.example": envExample(platform),
    ".gitignore": gitignore(),
    "README.md": readme({ name, platform, idea }),
    "config/index.js": configFile(platform),
    "utils/loader.js": loaderUtil(),
    "events/index.js": eventsIndex(platform),
    "index.js": indexFile(platform),
    "commands/ping.js": pingCommand(platform),
    "commands/menu.js": menuCommand(platform),
  };
}

module.exports = { baseFiles };
