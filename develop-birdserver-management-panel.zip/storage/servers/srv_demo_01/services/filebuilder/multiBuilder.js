// ==============================================
// MULTI AI BUILDER ENGINE (V5.1 — RESILIENT PIPELINE)
// ==============================================
// Perbaikan utama:
//   ✔ Tidak wajib JSON — text, markdown, code block tetap diproses
//   ✔ Retry 3x per provider, lalu fallback provider berikutnya
//   ✔ Pipeline bertahap: analisis → planning → folder → config → commands
//      → events → handler → utils → README → package.json → review
//   ✔ Partial merge — hasil provider/stage yang sukses tetap digabung
//   ✔ Auto repair response rusak menjadi struktur { name, files[] }
//   ✔ Error manusiawi untuk endpoint, API key, model, timeout, quota, format
// ==============================================
const axios = require("axios");
const providersCfg = require("../../config/providers");
const fbCfg = require("../../config/filebuilder");
const aiLogger = require("../../utils/aiLogger");
const { safeParseJSON } = require("../../utils/jsonRepair");

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const PIPELINE = [
  { key: "analysis", label: "Analisis", goal: "Analisis ide user, tujuan bot, role pengguna, command penting, dan risiko implementasi." },
  { key: "planning", label: "Planning", goal: "Buat rencana implementasi ringkas dan pembagian modul." },
  { key: "folder", label: "Folder", goal: "Usulkan struktur folder/file tambahan. Jangan buat file template inti." },
  { key: "config", label: "Config", goal: "Buat file konfigurasi tambahan bila dibutuhkan, misalnya config/fitur.js." },
  { key: "commands", label: "Commands", goal: "Buat command bot CommonJS di folder commands/*.js sesuai ide." },
  { key: "events", label: "Events", goal: "Buat event/helper event tambahan bila perlu. Jangan override events/index.js." },
  { key: "handler", label: "Handler", goal: "Buat handler bisnis di folder handlers/*.js bila dibutuhkan." },
  { key: "database", label: "Database", goal: "Buat skema database atau migrasi di folder database/*.js bila dibutuhkan." },
  { key: "utils", label: "Utils", goal: "Buat utilitas pendukung di folder utils/*.js. Jangan override utils/loader.js." },
  { key: "readme", label: "README", goal: "Buat dokumentasi tambahan di docs/ atau README.generated.md." },
  { key: "package", label: "package.json", goal: "Sebutkan dependency tambahan bila perlu dalam docs/dependencies.md. Jangan override package.json." },
  { key: "review", label: "Review", goal: "Review hasil, cari file rusak, dan beri patch tambahan bila perlu." },
];

function resolveKey(cfg) {
  const fromEnv = ((cfg.envKey && process.env[cfg.envKey]) || "").trim();
  const fromCfg = (cfg.apiKey || "").trim();
  return fromEnv || fromCfg;
}

function endpointsOf(cfg) {
  return (cfg.endpoints && cfg.endpoints.length)
    ? cfg.endpoints
    : (cfg.endpoint ? [cfg.endpoint] : []);
}

function modelsOf(cfg) {
  return (cfg.models && cfg.models.length) ? cfg.models : (cfg.model ? [cfg.model] : []);
}

function isReady(cfg) {
  if (!cfg || typeof cfg !== "object" || !cfg.enabled) return false;
  if (!resolveKey(cfg)) return false;
  if (!endpointsOf(cfg).length) return false;
  if (!modelsOf(cfg).length) return false;
  return true;
}

function getReadyProviders() {
  return Object.entries(providersCfg)
    .filter(([, cfg]) => isReady(cfg))
    .sort((a, b) => (a[1].priority || 99) - (b[1].priority || 99));
}

function listBuilders() {
  return Object.entries(providersCfg).map(([key, cfg]) => ({
    key,
    label: cfg.label || key,
    enabled: !!cfg.enabled,
    priority: cfg.priority || 99,
    ready: isReady(cfg),
  })).sort((a, b) => a.priority - b.priority);
}

function preflight(key, cfg) {
  const label = cfg.label || key;
  const apiKey = resolveKey(cfg);
  const endpoints = endpointsOf(cfg);
  const models = modelsOf(cfg);
  const problems = [];

  if (!cfg.enabled) problems.push(`${label} nonaktif di config/providers.js`);
  if (!apiKey) problems.push(`API Key ${label} kosong. Isi ${cfg.envKey || "apiKey"} di .env atau config/providers.js`);
  if (!models.length) problems.push(`Nama model ${label} kosong. Periksa field model/models di config/providers.js`);
  if (!endpoints.length) problems.push(`Endpoint ${label} kosong. Periksa field endpoint/endpoints di config/providers.js`);
  for (const url of endpoints) {
    try { new URL(url); } catch { problems.push(`Endpoint ${label} tidak valid: ${url}`); }
  }

  return { ok: problems.length === 0, problems, apiKey, endpoints, models };
}

function humanError(label, cfg, error, endpoint, model) {
  const status = error?.status || error?.response?.status || 0;
  const raw = error?.message || String(error || "unknown error");
  const lower = raw.toLowerCase();

  if (status === 401 || status === 403) {
    return `❌ API Key ${label} ditolak. Periksa ${cfg.envKey || "apiKey"} di .env atau config/providers.js.`;
  }
  if (status === 404) {
    return `❌ Endpoint ${label} tidak ditemukan. Periksa URL API pada config/providers.js (${endpoint}).`;
  }
  if (status === 408 || status === 504 || /timeout|etimedout|econnaborted/i.test(raw)) {
    return `❌ ${label} timeout. Naikkan timeoutMs atau cek koneksi internet/server provider.`;
  }
  if (status === 429 || /quota|rate.?limit|resource exhausted/i.test(lower)) {
    return `❌ Quota atau rate limit ${label} habis. Tunggu beberapa saat atau ganti API Key/provider.`;
  }
  if (status === 400 && /model|not found|does not exist|invalid/i.test(lower)) {
    return `❌ Nama model ${label} tidak valid (${model}). Periksa field model/models di config/providers.js.`;
  }
  if (/enotfound|eai_again|network|econnrefused|fetch failed/i.test(lower)) {
    return `❌ Koneksi internet/API ${label} bermasalah. Cek jaringan dan endpoint provider.`;
  }
  if (/json|format|parse|schema/i.test(lower)) {
    return `❌ ${label} mengembalikan format yang tidak sesuai. Builder sedang memperbaiki response...`;
  }
  return `❌ ${label} gagal: ${raw}`;
}

function buildSystemPrompt(platform, libraryHint, stage, partInfo) {
  const chunkNote = partInfo
    ? `\nIde user dibagi ${partInfo.total} bagian. Ini bagian ${partInfo.index}/${partInfo.total}. Jangan mengulang seluruh project.`
    : "";

  return [
    `Kamu adalah AI Builder profesional untuk source-code bot ${platform}.`,
    libraryHint || "",
    `Tahap saat ini: ${stage.label}.`,
    stage.goal,
    "Jangan membuat seluruh project sekaligus. Fokus hanya pada tahap ini.",
    "Output BOLEH JSON, markdown, text biasa, atau code block. Jika JSON, gunakan skema { name, files:[{path,content}] }.",
    "Jika membuat code block, tulis nama file di atasnya atau di fence seperti ```js filename=commands/menu.js.",
    "Path harus relatif, tanpa '..' dan tanpa '/'. Gunakan CommonJS require/module.exports.",
    "Jangan override file inti: index.js, package.json, README.md, config/index.js, events/index.js, utils/loader.js.",
    chunkNote,
  ].filter(Boolean).join("\n");
}

function buildUserPrompt({ platform, idea, stage, partInfo, memory }) {
  return [
    partInfo ? `Bagian ide ${partInfo.index}/${partInfo.total}:` : `Ide bot ${platform}:`,
    idea,
    "",
    memory ? `Ringkasan tahap sebelumnya:\n${memory.slice(-6000)}` : "",
    "",
    `Kerjakan tahap: ${stage.label}.`,
    "Balas dengan hasil yang bisa diubah menjadi file project. JSON tidak wajib.",
  ].filter(Boolean).join("\n");
}

async function callOpenAI(cfg, endpoint, model, system, user) {
  const apiKey = resolveKey(cfg);
  const headers = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${apiKey}`,
    ...(cfg.headers || {}),
  };

  if ((cfg.envKey || "").toUpperCase() === "LOVABLE_API_KEY") {
    headers["Lovable-API-Key"] = apiKey;
    delete headers.Authorization;
  }

  const res = await axios.post(endpoint, {
    model,
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
    temperature: cfg.temperature ?? 0.7,
    max_tokens: cfg.maxTokens || 8192,
  }, {
    headers,
    timeout: cfg.timeoutMs || 120000,
    validateStatus: () => true,
  });

  if (res.status >= 400) {
    const msg = res.data?.error?.message || res.data?.message || `HTTP ${res.status}`;
    const err = new Error(msg);
    err.status = res.status;
    throw err;
  }

  const text = res.data?.choices?.[0]?.message?.content || res.data?.choices?.[0]?.text;
  if (!text || !String(text).trim()) throw new Error("balasan kosong");
  return String(text).trim();
}

async function callGemini(cfg, endpoint, model, system, user) {
  const apiKey = resolveKey(cfg);
  const url = `${endpoint.replace(/\/+$/, "")}/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const res = await axios.post(url, {
    contents: [
      { role: "user", parts: [{ text: `[SYSTEM]\n${system}\n\n[USER]\n${user}` }] },
    ],
    generationConfig: {
      temperature: cfg.temperature ?? 0.7,
      topP: 0.95,
      topK: 40,
      maxOutputTokens: cfg.maxTokens || 8192,
    },
  }, {
    headers: { "Content-Type": "application/json" },
    timeout: cfg.timeoutMs || 90000,
    validateStatus: () => true,
  });

  if (res.status >= 400) {
    const msg = res.data?.error?.message || `HTTP ${res.status}`;
    const err = new Error(msg);
    err.status = res.status;
    throw err;
  }

  const cand = res.data?.candidates?.[0];
  const text = cand?.content?.parts?.map((p) => p.text).filter(Boolean).join("\n").trim();
  if (!text) throw new Error(`balasan kosong (finishReason=${cand?.finishReason || "UNKNOWN"})`);
  return text;
}

function stripFence(text) {
  return String(text || "")
    .replace(/^```[a-z0-9_-]*(?:\s+filename=[^\n]+)?\s*/i, "")
    .replace(/```$/i, "")
    .trim();
}

function safePath(p, fallback) {
  let rel = String(p || fallback || "").trim()
    .replace(/^filename=/i, "")
    .replace(/^file:/i, "")
    .replace(/^path:/i, "")
    .replace(/["'`]/g, "")
    .replace(/\\/g, "/");
  rel = rel.replace(/^\.?\/+/, "");
  if (!rel || rel.includes("..") || rel.startsWith("/") || /^[a-zA-Z]:/.test(rel)) return null;
  if (!/\.[a-z0-9]+$/i.test(rel)) return null;
  return rel.slice(0, 160);
}

function inferPathFromCode(code, lang, stage, index) {
  const firstLines = code.split("\n").slice(0, 5).join("\n");
  const marker = firstLines.match(/(?:file|path|filename)\s*[:=]\s*([\w./-]+\.[\w]+)/i)
    || firstLines.match(/\/\/\s*([\w./-]+\.[\w]+)/)
    || firstLines.match(/#\s*([\w./-]+\.[\w]+)/);
  if (marker) return safePath(marker[1]);

  const commandName = code.match(/name\s*:\s*["']([a-z0-9_-]+)["']/i)?.[1];
  if (commandName && /module\.exports|exports\./.test(code)) return `commands/${commandName}.js`;
  if (/module\.exports|require\(|async\s+function|\.sendMessage|bot\.sendMessage/i.test(code)) {
    if (stage.key === "utils") return `utils/${stage.key}-${index}.js`;
    if (stage.key === "handler") return `handlers/${stage.key}-${index}.js`;
    if (stage.key === "events") return `events/${stage.key}-${index}.js`;
    return `commands/${stage.key}-${index}.js`;
  }
  if (/json/i.test(lang)) return `docs/${stage.key}-${index}.json`;
  if (/md|markdown/i.test(lang)) return `docs/${stage.key}-${index}.md`;
  return `docs/${stage.key}-${index}.txt`;
}

function filesFromMarkdown(raw, stage) {
  const text = String(raw || "");
  const files = [];

  const namedBlock = /(?:^|\n)(?:#{1,6}\s*)?(?:file|path|filename|📄)\s*[:\-]\s*`?([\w./-]+\.[\w]+)`?\s*\n```([\w-]*)?\s*\n([\s\S]*?)```/gi;
  let m;
  while ((m = namedBlock.exec(text))) {
    const path = safePath(m[1]);
    if (path) files.push({ path, content: stripFence(m[3]) });
  }

  const fence = /```([\w-]*)(?:\s+filename=([^\n]+))?\s*\n([\s\S]*?)```/gi;
  let idx = 1;
  while ((m = fence.exec(text))) {
    const explicit = safePath(m[2]);
    const code = stripFence(m[3]);
    const rel = explicit || inferPathFromCode(code, m[1], stage, idx++);
    if (rel && !files.some((f) => f.path === rel)) files.push({ path: rel, content: code });
  }

  const inline = /(?:^|\n)(?:---|###|##|#)?\s*([\w./-]+\.[\w]+)\s*(?:---|:)?\s*\n([\s\S]*?)(?=\n(?:---|###|##|#)?\s*[\w./-]+\.[\w]+\s*(?:---|:)?\s*\n|$)/g;
  while ((m = inline.exec(text))) {
    const rel = safePath(m[1]);
    const content = stripFence(m[2]);
    if (rel && content && !files.some((f) => f.path === rel)) files.push({ path: rel, content });
  }

  return files;
}

function normalizeProject(parsed, raw, stage) {
  const out = { name: "", files: [] };
  if (parsed && typeof parsed === "object") {
    out.name = String(parsed.name || parsed.projectName || "").trim();
    const arr = Array.isArray(parsed.files) ? parsed.files
      : Array.isArray(parsed.file) ? parsed.file
      : Array.isArray(parsed.outputs) ? parsed.outputs
      : [];
    for (const f of arr) {
      const rel = safePath(f?.path || f?.file || f?.filename || f?.name);
      if (rel) out.files.push({ path: rel, content: String(f?.content ?? f?.code ?? f?.text ?? "") });
    }
  }
  if (!out.files.length) out.files.push(...filesFromMarkdown(raw, stage));
  return out;
}

function textFallback(raw, stage) {
  const body = String(raw || "").trim();
  if (!body) return { name: "", files: [] };
  const escaped = JSON.stringify(body.slice(0, 3500));
  if (["analysis", "planning", "folder", "readme", "package", "review"].includes(stage.key)) {
    return { name: "", files: [{ path: `docs/${stage.key}.md`, content: `# ${stage.label}\n\n${body}\n` }] };
  }
  if (stage.key === "commands") {
    return {
      name: "",
      files: [{
        path: "commands/ai-result.js",
        content: `// commands/ai-result.js\nmodule.exports = {\n  name: "ai-result",\n  desc: "Hasil build dari response AI bebas-format",\n  async run(ctx) {\n    const text = ${escaped};\n    if (ctx.sock && ctx.from) return ctx.sock.sendMessage(ctx.from, { text });\n    if (ctx.bot && ctx.msg) return ctx.bot.sendMessage(ctx.msg.chat.id, text);\n  },\n};\n`,
      }],
    };
  }
  return { name: "", files: [{ path: `docs/${stage.key}.txt`, content: body }] };
}

function parseAnyResponse(raw, stage) {
  let parsed = null;
  try { parsed = safeParseJSON(raw); } catch { parsed = null; }
  const normalized = normalizeProject(parsed, raw, stage);
  if (normalized.files.length) return normalized;
  return textFallback(raw, stage);
}

async function callProviderOnce(cfg, endpoint, model, system, prompt) {
  return cfg.apiFormat === "gemini"
    ? callGemini(cfg, endpoint, model, system, prompt)
    : callOpenAI(cfg, endpoint, model, system, prompt);
}

async function tryProvider(key, cfg, system, userPrompt, stage, onEvent) {
  const label = cfg.label || key;
  const pre = preflight(key, cfg);
  if (!pre.ok) throw new Error(pre.problems.join("; "));

  const attempts = Math.max(1, Number(cfg.retry?.attempts || 3));
  const backoffMs = Math.max(250, Number(cfg.retry?.backoffMs || 1500));
  let lastErr;

  for (const endpoint of pre.endpoints) {
    for (const model of pre.models) {
      for (let attempt = 1; attempt <= attempts; attempt++) {
        const started = Date.now();
        try {
          if (onEvent) await onEvent("attempt", { label, endpoint, model, attempt, attempts, stage });
          const raw = await callProviderOnce(cfg, endpoint, model, system, userPrompt);
          const parsed = parseAnyResponse(raw, stage);
          if (!parsed.files.length) throw new Error("response kosong setelah auto repair");
          aiLogger.log({ provider: label, model, endpoint, stage: stage.key, status: "ok", attempt, durationMs: Date.now() - started, responsePreview: raw.slice(0, 180) });
          return { parsed, raw, builderUsed: label, model, endpoint };
        } catch (e) {
          lastErr = e;
          const readable = humanError(label, cfg, e, endpoint, model);
          aiLogger.log({ provider: label, model, endpoint, stage: stage.key, status: attempt < attempts ? "retry" : "error", attempt, durationMs: Date.now() - started, error: readable });
          if (onEvent) await onEvent("error", { label, endpoint, model, attempt, attempts, stage, error: readable });

          const status = e.status || 0;
          if (status === 401 || status === 403) throw new Error(readable);
          if (attempt < attempts) await sleep(backoffMs * attempt);
        }
      }
    }
  }

  throw new Error(humanError(label, cfg, lastErr, pre.endpoints[0], pre.models[0]));
}

function chunkPrompt(idea, maxCharsPerChunk = 18000) {
  const maxChunks = Math.max(1, Number(fbCfg.maxChunks || 80));
  const text = String(idea || "");
  if (text.length <= maxCharsPerChunk) return [text];
  const chunks = [];
  let buf = "";
  const parts = text.split(/\n{2,}|(?<=[.!?])\s+/);
  for (const part of parts) {
    const next = buf ? `${buf}\n${part}` : part;
    if (next.length > maxCharsPerChunk && buf) {
      chunks.push(buf.trim());
      buf = part;
      if (chunks.length >= maxChunks) break;
    } else {
      buf = next;
    }
  }
  if (buf.trim() && chunks.length < maxChunks) chunks.push(buf.trim());
  return chunks.length ? chunks : [text.slice(0, maxCharsPerChunk)];
}

function mergeParsed(results) {
  const byPath = new Map();
  let name = "";
  for (const r of results) {
    if (!name && r.parsed?.name) name = r.parsed.name;
    for (const f of r.parsed?.files || []) {
      const rel = safePath(f.path);
      if (!rel) continue;
      const content = String(f.content || "").trim();
      if (!content) continue;
      if (!byPath.has(rel)) byPath.set(rel, { path: rel, content });
      else if (content.length > byPath.get(rel).content.length) byPath.set(rel, { path: rel, content });
    }
  }
  return { name: name || "bot", files: Array.from(byPath.values()) };
}

function diagnosticsMarkdown(errors) {
  if (!errors.length) return "";
  return [
    "# Build Diagnostics",
    "",
    "File ini dibuat otomatis karena sebagian provider/tahap AI gagal, tetapi builder tetap melanjutkan proses.",
    "",
    ...errors.map((e, i) => `${i + 1}. **${e.stage} / ${e.provider || "provider"}** — ${e.error}`),
    "",
  ].join("\n");
}

async function runStage({ stage, chunk, partInfo, platform, libraryHint, ready, memory, onEvent }) {
  const system = buildSystemPrompt(platform, libraryHint, stage, partInfo);
  const userPrompt = buildUserPrompt({ platform, idea: chunk, stage, partInfo, memory });
  const errors = [];

  for (const [key, cfg] of ready) {
    try {
      const result = await tryProvider(key, cfg, system, userPrompt, stage, onEvent);
      return { result, errors };
    } catch (e) {
      const message = e.message || String(e);
      errors.push({ stage: stage.label, provider: cfg.label || key, error: message });
      if (onEvent) await onEvent("fallback", { label: cfg.label || key, stage, error: message });
    }
  }
  return { result: null, errors };
}

async function generate({
  platform, idea, libraryHint, chunkChars,
  onBuilderAttempt, onBuilderFallback, onChunkProgress, onPipelineStep, onRepair,
}) {
  const ready = getReadyProviders();
  if (!ready.length) {
    throw new Error("❌ Tidak ada AI Builder yang siap. Periksa API Key, endpoint, model, dan enabled di config/providers.js.");
  }

  const chunks = chunkPrompt(String(idea || ""), chunkChars || 18000);
  const results = [];
  const stageErrors = [];
  let firstProviderUsed = null;
  let firstModel = "";
  let firstEndpoint = "";
  let memory = "";

  const onEvent = async (type, data) => {
    if (type === "attempt" && onBuilderAttempt) {
      await onBuilderAttempt(data.label, data.attempt, data.attempts, data.stage?.label).catch(() => {});
    } else if (type === "fallback" && onBuilderFallback) {
      await onBuilderFallback(data.label, data.error, data.stage?.label).catch(() => {});
    } else if (type === "error" && /format|JSON|response/i.test(data.error || "") && onRepair) {
      await onRepair(data.error).catch(() => {});
    }
  };

  for (let ci = 0; ci < chunks.length; ci++) {
    const partInfo = chunks.length > 1 ? { index: ci + 1, total: chunks.length } : null;
    if (onChunkProgress) await onChunkProgress(ci + 1, chunks.length).catch(() => {});

    for (const stage of PIPELINE) {
      if (onPipelineStep) await onPipelineStep(stage.label, ci + 1, chunks.length).catch(() => {});
      const { result, errors } = await runStage({
        stage, chunk: chunks[ci], partInfo, platform, libraryHint, ready, memory, onEvent,
      });
      stageErrors.push(...errors);
      if (!result) continue;
      results.push(result);
      firstProviderUsed = firstProviderUsed || result.builderUsed;
      firstModel = firstModel || result.model;
      firstEndpoint = firstEndpoint || result.endpoint;
      memory += `\n[${stage.label}] ${result.raw?.slice(0, 1200) || JSON.stringify(result.parsed).slice(0, 1200)}`;
    }
  }

  const merged = mergeParsed(results);
  const diagnostics = diagnosticsMarkdown(stageErrors);
  if (diagnostics) merged.files.push({ path: "docs/BUILD_DIAGNOSTICS.md", content: diagnostics });
  if (!merged.files.length) {
    merged.files.push({
      path: "docs/BUILD_DIAGNOSTICS.md",
      content: diagnostics || "# Build Diagnostics\n\nSemua provider gagal memberi file, tetapi template dasar tetap dibuat. Periksa config/providers.js.\n",
    });
  }

  return {
    parsed: merged,
    builderUsed: firstProviderUsed || "Template fallback",
    model: firstModel || "-",
    endpoint: firstEndpoint || "-",
    chunkCount: chunks.length,
    stageErrors,
  };
}

module.exports = { generate, getReadyProviders, listBuilders, parseAnyResponse };