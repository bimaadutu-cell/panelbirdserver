const axios = require("axios");
const logger = require("../../utils/logger");

class PanelAnalyzer {
  constructor() {
    this.cache = new Map();
  }

  async analyze(server) {
    const started = Date.now();
    const result = {
      key: server.key,
      name: server.name,
      url: server.url,
      online: false,
      status: "OFFLINE",
      latency: 0,
      httpCode: 0,
      apiValid: false,
      clientApiValid: false,
      maintenance: false,
      error: null,
      lastCheck: new Date().toISOString()
    };

    try {
      // 1. Check URL & HTTP Status
      const response = await axios.get(server.url, { 
        timeout: 10000,
        validateStatus: () => true 
      });
      result.httpCode = response.status;
      result.latency = Date.now() - started;

      if (response.status >= 200 && response.status < 400) {
        result.online = true;
        result.status = "ONLINE";
      } else if (response.status === 503) {
        result.maintenance = true;
        result.status = "MAINTENANCE";
      }

      // 2. Check Application API
      try {
        const appApi = axios.create({
          baseURL: server.url.replace(/\/$/, "") + "/api/application",
          headers: {
            Authorization: `Bearer ${server.ptla}`,
            Accept: "application/json"
          },
          timeout: 10000
        });
        const appRes = await appApi.get("/nodes");
        if (appRes.status === 200) {
          result.apiValid = true;
        }
      } catch (e) {
        result.apiValid = false;
        if (!result.error) result.error = "API Key Invalid or No Response";
      }

      // 3. Check Client API (if applicable, using same key or check if endpoint exists)
      // For Pterodactyl, usually we check if /api/client returns 401/403 (means endpoint exists)
      try {
        const clientApi = axios.create({
          baseURL: server.url.replace(/\/$/, "") + "/api/client",
          headers: { Accept: "application/json" },
          timeout: 5000
        });
        await clientApi.get("/account");
        result.clientApiValid = true;
      } catch (e) {
        // 401 is expected if no key provided, but means endpoint is there
        if (e.response && (e.response.status === 401 || e.response.status === 403)) {
          result.clientApiValid = true;
        }
      }

    } catch (e) {
      result.online = false;
      result.status = "OFFLINE";
      result.error = e.message;
    }

    this.cache.set(server.key, result);
    return result;
  }

  getCached(key) {
    return this.cache.get(key);
  }

  async checkAll(servers) {
    const results = [];
    for (const s of servers) {
      results.push(await this.analyze(s));
    }
    return results;
  }
}

module.exports = new PanelAnalyzer();
