// Pterodactyl Application API client — auto-discover node/nest/egg/location.
const axios = require("axios");
const panelCfg = require("../../config/panel");
const db = require("../../database/db");
const logger = require("../../utils/logger");
const { genPassword } = require("../../helpers/format");

const cacheTTL = (panelCfg.metaCacheTTL || 3600) * 1000;

function client(server) {
  return axios.create({
    baseURL: server.url.replace(/\/$/, "") + "/api/application",
    headers: {
      Authorization: `Bearer ${server.ptla}`,
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    timeout: 20_000,
  });
}

function findServer(key) {
  return panelCfg.servers.find((s) => s.key === key);
}

// ---- Meta discovery (nodes / nests / eggs / locations) ----
async function fetchAllPages(api, path) {
  let page = 1, out = [];
  while (true) {
    const res = await api.get(`${path}?page=${page}&per_page=100`);
    const items = (res.data.data || []).map((x) => x.attributes);
    out = out.concat(items);
    const pg = res.data.meta?.pagination;
    if (!pg || page >= pg.total_pages) break;
    page++;
  }
  return out;
}

async function discoverMeta(server, { force = false } = {}) {
  const cached = db.getServerMeta(server.key);
  if (!force && cached && Date.now() - cached.updatedAt < cacheTTL) return cached.data;

  const api = client(server);
  logger.info(`[panel:${server.key}] discovering meta (nodes/nests/eggs/locations)...`);
  const [nodes, nests, locations] = await Promise.all([
    fetchAllPages(api, "/nodes"),
    fetchAllPages(api, "/nests"),
    fetchAllPages(api, "/locations"),
  ]);
  const eggs = [];
  for (const nest of nests) {
    const res = await api.get(`/nests/${nest.id}/eggs?per_page=100`);
    for (const e of res.data.data) eggs.push({ ...e.attributes, nestId: nest.id });
  }
  const data = { nodes, nests, eggs, locations };
  db.setServerMeta(server.key, data);
  logger.success(`[panel:${server.key}] discovered ${nodes.length} nodes, ${nests.length} nests, ${eggs.length} eggs, ${locations.length} locations`);
  return data;
}

function pickDefault(list, wantedName, keyName = "name") {
  if (!list.length) throw new Error("empty list from panel");
  if (wantedName) {
    const hit = list.find((x) => (x[keyName] || "").toLowerCase() === wantedName.toLowerCase());
    if (hit) return hit;
  }
  return list[0];
}

// Prioritaskan egg NODE.JS (untuk bot WA/Telegram) dan TOLAK egg Minecraft.
const NODE_KEYWORDS = ["node", "nodejs", "node.js", "nodemon", "bot", "js", "javascript"];
const BAN_KEYWORDS  = ["minecraft", "spigot", "paper", "bukkit", "forge", "fabric",
                       "purpur", "sponge", "rust", "gmod", "csgo", "srcds", "steam"];

function isNodeEgg(e) {
  const hay = `${e.name || ""} ${e.description || ""} ${e.docker_image || ""}`.toLowerCase();
  if (BAN_KEYWORDS.some((k) => hay.includes(k))) return false;
  return NODE_KEYWORDS.some((k) => hay.includes(k));
}

async function pickConfig(server) {
  const meta = await discoverMeta(server);
  const d = server.defaults || {};
  const node = pickDefault(meta.nodes, d.nodeName, "name");
  const location = pickDefault(meta.locations, d.locationShort, "short");

  // 1. Cari egg node.js — utamakan default eggName kalau diisi & valid
  let egg = null;
  if (d.eggName) {
    egg = meta.eggs.find(
      (e) => (e.name || "").toLowerCase() === d.eggName.toLowerCase() && !BAN_KEYWORDS.some((k) => (e.name || "").toLowerCase().includes(k))
    );
  }
  if (!egg) egg = meta.eggs.find(isNodeEgg);
  if (!egg) {
    // Fallback: apapun kecuali yang di-ban (jangan pernah buat Minecraft)
    egg = meta.eggs.find((e) => {
      const hay = `${e.name || ""} ${e.docker_image || ""}`.toLowerCase();
      return !BAN_KEYWORDS.some((k) => hay.includes(k));
    });
  }
  if (!egg) throw new Error("Tidak ada egg Node.js yang tersedia di panel — hubungi admin.");

  const nest = meta.nests.find((n) => n.id === egg.nestId) || pickDefault(meta.nests, d.nestName, "name");
  return { node, nest, egg, location };
}

// ---- Create user + server ----
async function createUser(server, { name, username, email }) {
  const api = client(server);
  const password = genPassword();
  const payload = {
    email,
    username: username.toLowerCase(),
    first_name: name || username,
    last_name: "user",
    language: "en",
    password,
  };
  try {
    const res = await api.post("/users", payload);
    return { id: res.data.attributes.id, username: payload.username, password };
  } catch (e) {
    // Bila user sudah ada, cari
    if (e.response?.status === 422) {
      const list = await api.get(`/users?filter[email]=${encodeURIComponent(email)}`);
      const found = list.data.data[0]?.attributes;
      if (found) return { id: found.id, username: found.username, password };
    }
    throw new Error(`createUser failed: ${e.response?.data?.errors?.[0]?.detail || e.message}`);
  }
}

async function createServer(server, { user, ram, cpu, disk, egg, node, location, nameSuffix }) {
  const api = client(server);
  // fetch egg detail for docker_image + startup + env
  const eggDetail = await api.get(`/nests/${egg.nestId}/eggs/${egg.id}?include=variables`);
  const attrs = eggDetail.data.attributes;
  const environment = {};
  for (const v of attrs.relationships?.variables?.data || []) {
    environment[v.attributes.env_variable] = v.attributes.default_value ?? "";
  }
  const payload = {
    name: `${user.username}-${nameSuffix || "srv"}`,
    user: user.id,
    egg: egg.id,
    docker_image: attrs.docker_image,
    startup: attrs.startup,
    environment,
    limits: {
      memory: ram, swap: 0, disk, io: 500, cpu,
    },
    feature_limits: { databases: 2, backups: 1, allocations: 1 },
    deploy: {
      locations: [location.id],
      dedicated_ip: false,
      port_range: [],
    },
  };
  const res = await api.post("/servers", payload);
  return res.data.attributes; // includes id, identifier, uuid
}

async function deleteServer(server, panelServerId) {
  const api = client(server);
  await api.delete(`/servers/${panelServerId}`);
}

// ---- Server status (list servers + node stats) ----
async function serverStatus(server) {
  const started = Date.now();
  const api = client(server);
  try {
    const r = await api.get("/nodes");
    return {
      key: server.key,
      name: server.name,
      url: server.url,
      status: "ONLINE",
      apiOk: true,
      ping: Date.now() - started,
      nodes: r.data.data.length,
    };
  } catch (e) {
    return {
      key: server.key,
      name: server.name,
      url: server.url,
      status: "OFFLINE",
      apiOk: false,
      ping: Date.now() - started,
      error: e.message,
    };
  }
}

module.exports = {
  findServer,
  discoverMeta,
  pickConfig,
  createUser,
  createServer,
  deleteServer,
  serverStatus,
};
