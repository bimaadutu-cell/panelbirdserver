// Orkestrasi order end-to-end: create order, create panel, kirim akun.
const db = require("../../database/db");
const panelSvc = require("../panel/pterodactyl");
const rolesCfg = require("../../config/roles");
const pricesCfg = require("../../config/prices");
const panelCfg = require("../../config/panel");
const productsCfg = require("../../config/products");
const settings = require("../../config/settings");
const logger = require("../../utils/logger");
const { Queue } = require("../../utils/queue");
const { genOrderId, rupiah, fmtDate } = require("../../helpers/format");

const panelQueue = new Queue({
  concurrency: settings.queue.createPanelConcurrency,
  retry: settings.queue.retry,
});

function panelPrice(serverKey, role, size) {
  const t = pricesCfg[serverKey]?.[role];
  if (!t) return null;
  return t[size] ?? null;
}

function apkPrice(itemId) {
  for (const c of productsCfg.categories) {
    const it = c.items.find((i) => i.id === itemId);
    if (it) return { item: it, category: c };
  }
  return null;
}

function newOrder({ chatId, platform, type, ...rest }) {
  const id = genOrderId();
  const expiredAt = type === "panel"
    ? Date.now() + (panelCfg.defaultExpireDays * 86400_000)
    : null;
  const o = db.createOrder({
    id, chatId: String(chatId), platform, type,
    invoiceId: rest.invoiceId || null,
    serverKey: rest.serverKey || null,
    role: rest.role || null,
    size: rest.size || null,
    amount: rest.amount,
    customer: rest.customer || {},
    status: "awaiting_payment",
    expiredAt,
  });
  return { ...o, id, expiredAt };
}

function computeLimits(role, size) {
  const r = rolesCfg[role];
  if (!r) throw new Error(`Role ${role} tidak dikenal`);
  if (size === "unlimited") return { ram: 0, cpu: 0, disk: 0 };
  const gb = Number(size);
  const ram = gb * 1024 * (r.ramMultiplier || 1);
  const cpu = r.cpuPerGB ? gb * r.cpuPerGB : 0;
  const disk = r.diskPerGB ? gb * r.diskPerGB : 0;
  return { ram, cpu, disk };
}

async function fulfillPanel(order) {
  return panelQueue.push(async () => {
    const server = panelSvc.findServer(order.server_key);
    if (!server) throw new Error(`Server ${order.server_key} tidak ada di config/panel.js`);
    const cust = order.customer || {};
    db.updateOrder(order.id, { status: "processing" });
    const { node, egg, location } = await panelSvc.pickConfig(server);
    const user = await panelSvc.createUser(server, {
      name: cust.name, username: cust.username, email: cust.email,
    });
    const limits = computeLimits(order.role, order.size);
    const srv = await panelSvc.createServer(server, {
      user, ...limits, egg, node, location, nameSuffix: order.role,
    });
    const panelInfo = {
      username: user.username,
      password: user.password,
      url: server.url,
      ram: limits.ram, cpu: limits.cpu, disk: limits.disk,
      serverId: srv.id, serverIdentifier: srv.identifier,
      expiredAt: order.expired_at,
      role: order.role, size: order.size, serverName: server.name,
    };
    db.savePanel({
      orderId: order.id,
      serverKey: order.server_key,
      panelUserId: user.id,
      panelServerId: srv.id,
      username: user.username,
      password: user.password,
      url: server.url,
      ram: limits.ram, cpu: limits.cpu, disk: limits.disk,
      expiredAt: order.expired_at,
    });
    db.updateOrder(order.id, { status: "delivered", panel: panelInfo });
    logger.event("panel_created", { orderId: order.id, server: server.key, username: user.username });
    return panelInfo;
  });
}

function formatPanelDelivery(p) {
  return [
    "✅ *PANEL BERHASIL DIBUAT*",
    "━━━━━━━━━━━━━━━━━━",
    `Server  : ${p.serverName}`,
    `URL     : ${p.url}`,
    `Username: ${p.username}`,
    `Password: ${p.password}`,
    `RAM     : ${p.ram === 0 ? "Unlimited" : p.ram + " MB"}`,
    `CPU     : ${p.cpu === 0 ? "Unlimited" : p.cpu + " %"}`,
    `Disk    : ${p.disk === 0 ? "Unlimited" : p.disk + " MB"}`,
    `Expired : ${p.expiredAt ? fmtDate(p.expiredAt) : "Permanen"}`,
    `Status  : ACTIVE`,
    "━━━━━━━━━━━━━━━━━━",
    "Simpan data ini baik-baik!",
  ].join("\n");
}

async function deleteExpiredPanels() {
  const list = db.expiredActivePanels();
  for (const o of list) {
    try {
      const p = db.panelByOrder(o.id);
      if (!p) continue;
      const server = panelSvc.findServer(o.server_key);
      if (server) await panelSvc.deleteServer(server, p.panel_server_id);
      db.markPanelDeleted(o.id);
      db.updateOrder(o.id, { status: "expired" });
      logger.event("panel_deleted", { orderId: o.id });
    } catch (e) {
      logger.error("auto-delete failed:", o.id, e.message);
    }
  }
  return list.length;
}

module.exports = {
  panelPrice, apkPrice, newOrder, fulfillPanel, formatPanelDelivery, deleteExpiredPanels,
};
