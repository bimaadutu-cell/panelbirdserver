// ==============================================
// AI CLIENT — CHATGPT (V3.3)
// ==============================================
// Stub — tampil "Akan Hadir" bila belum dikonfigurasi.
// Bila admin mengaktifkan config/models.js .chatgpt.enabled dan mengisi
// apiKey (atau env OPENAI_API_KEY), client ini akan otomatis hidup.
// ==============================================
const axios = require("axios");
const modelsCfg = require("../../config/models");
const aiCfg = require("../../config/ai");

function getKey() {
  return (modelsCfg.chatgpt.apiKey || process.env.OPENAI_API_KEY || "").trim();
}

function isConfigured() {
  return modelsCfg.chatgpt.enabled && !!getKey();
}

async function chat({ history, model }) {
  if (!isConfigured()) {
    const err = new Error(aiCfg.ui.comingSoon);
    err.code = "COMING_SOON";
    throw err;
  }
  const usedModel = model || modelsCfg.chatgpt.defaultModel;
  const messages = [
    { role: "system", content: aiCfg.systemPrompt },
    ...history.map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || ""),
    })),
  ];
  try {
    const res = await axios.post(
      modelsCfg.chatgpt.endpoint,
      { model: usedModel, messages, ...(modelsCfg.chatgpt.generationConfig || {}) },
      {
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getKey()}` },
        timeout: 60000,
      },
    );
    const text = res.data?.choices?.[0]?.message?.content?.trim();
    if (!text) throw new Error("Balasan kosong dari ChatGPT.");
    return { text, model: usedModel };
  } catch (e) {
    const msg = e.response?.data?.error?.message || e.message;
    throw new Error(`ChatGPT error: ${msg}`);
  }
}

module.exports = { chat, isConfigured };
