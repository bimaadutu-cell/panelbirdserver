// ==============================================
// AI SESSION / MEMORY (V3.3)
// ==============================================
// Menyimpan riwayat percakapan ModeAI PER user (in-memory).
// TTL & maxTurns diambil dari config/ai.js .memory.
// ==============================================
const aiCfg = require("../../config/ai");

const memory = new Map(); // key: `${platform}:${chatId}` → { model, history:[], updatedAt }

function keyOf(platform, chatId) { return `${platform}:${String(chatId)}`; }

function get(platform, chatId) {
  const k = keyOf(platform, chatId);
  const s = memory.get(k);
  if (!s) return null;
  const ttl = (aiCfg.memory?.ttlMinutes || 60) * 60_000;
  if (Date.now() - s.updatedAt > ttl) { memory.delete(k); return null; }
  return s;
}

function set(platform, chatId, patch) {
  const k = keyOf(platform, chatId);
  const cur = memory.get(k) || { model: null, history: [], updatedAt: Date.now() };
  const next = { ...cur, ...patch, updatedAt: Date.now() };
  memory.set(k, next);
  return next;
}

function push(platform, chatId, role, content) {
  const k = keyOf(platform, chatId);
  const cur = memory.get(k) || { model: null, history: [], updatedAt: Date.now() };
  cur.history.push({ role, content: String(content || "") });
  const cap = aiCfg.memory?.maxTurns || 20;
  if (cur.history.length > cap) cur.history = cur.history.slice(-cap);
  cur.updatedAt = Date.now();
  memory.set(k, cur);
  return cur;
}

function reset(platform, chatId) {
  const k = keyOf(platform, chatId);
  const cur = memory.get(k);
  if (cur) { cur.history = []; cur.updatedAt = Date.now(); memory.set(k, cur); }
}

function clear(platform, chatId) {
  memory.delete(keyOf(platform, chatId));
}

module.exports = { get, set, push, reset, clear };
