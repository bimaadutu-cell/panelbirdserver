// ==============================================
// AI ROUTER (V3.3)
// ==============================================
// Dispatch chat request ke client model yang dipilih user.
// ==============================================
const gemini = require("./gemini");
const chatgpt = require("./chatgpt");
const lovable = require("./lovable");
const modelsCfg = require("../../config/models");
const aiCfg = require("../../config/ai");
const modeaiCfg = require("../../config/modeai");

const CLIENTS = {
  gemini,
  chatgpt,
  lovable,
};

function labelOf(key) {
  const c = modelsCfg[key];
  return c?.label || key;
}

function status(key) {
  const c = modelsCfg[key];
  const cli = CLIENTS[key];
  if (!c || !cli) return { key, ok: false, reason: aiCfg.ui.unknownModel };
  if (!c.enabled) return { key, ok: false, reason: aiCfg.ui.comingSoon };
  if (!cli.isConfigured()) return { key, ok: false, reason: aiCfg.ui.notConfigured };
  return { key, ok: true };
}

async function chat({ modelKey, history, retryCount = 0 }) {
  const st = status(modelKey);
  if (!st.ok) {
    // Fallback to another model if primary is not available
    if (modelKey !== modeaiCfg.fallbackModel) {
      return chat({ modelKey: modeaiCfg.fallbackModel, history, retryCount });
    }
    const e = new Error(st.reason);
    e.code = "MODEL_NOT_AVAILABLE";
    throw e;
  }

  try {
    // Inject System Prompt if not present
    const hasSystem = history.some(m => m.role === "system");
    const messages = hasSystem ? history : [{ role: "system", content: modeaiCfg.systemPrompt }, ...history];
    
    const response = await CLIENTS[modelKey].chat({ history: messages });
    
    // Auto Format Check (simple Markdown/Codeblock check)
    if (modeaiCfg.autoFormat && !response.includes("```") && response.length > 500) {
      // Suggest code block for long responses if they look like code
      if (response.includes("{") || response.includes("function") || response.includes("const")) {
        // Simple heuristic
      }
    }

    return response;
  } catch (e) {
    if (retryCount < modeaiCfg.maxRetry) {
      const delay = modeaiCfg.retryDelayMs * (retryCount + 1);
      await new Promise(r => setTimeout(r, delay));
      return chat({ modelKey, history, retryCount: retryCount + 1 });
    }
    
    // Final fallback to another model if current one fails after retries
    if (modelKey !== modeaiCfg.fallbackModel) {
      return chat({ modelKey: modeaiCfg.fallbackModel, history, retryCount: 0 });
    }

    throw new Error(`AI Failure after ${modeaiCfg.maxRetry} retries: ${e.message}`);
  }
}

module.exports = { chat, status, labelOf, CLIENTS };
