// ==============================================
// AI CLIENT — GEMINI (V3.3)
// ==============================================
// Client HTTP untuk Google Generative Language API.
// Mendukung history (memory percakapan) via `contents[]`.
// ==============================================
const axios = require("axios");
const modelsCfg = require("../../config/models");
const aiCfg = require("../../config/ai");

function getKey() {
  return (modelsCfg.gemini.apiKey || process.env.GEMINI_API_KEY || "").trim();
}

function isConfigured() {
  return modelsCfg.gemini.enabled && !!getKey();
}

// Konversi history [{role:'user'|'assistant', content}] → format Gemini
function toContents(history, systemPrompt) {
  const contents = [];
  // Gemini tidak punya role 'system' — kita gabung ke turn user pertama
  if (systemPrompt) {
    contents.push({
      role: "user",
      parts: [{ text: `[SYSTEM]\n${systemPrompt}\n\n[USER PERTAMA]` }],
    });
    contents.push({
      role: "model",
      parts: [{ text: "Baik, saya siap membantu." }],
    });
  }
  for (const m of history) {
    contents.push({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: String(m.content || "") }],
    });
  }
  return contents;
}

async function chat({ history, model }) {
  if (!isConfigured()) {
    const err = new Error(aiCfg.ui.notConfigured);
    err.code = "NOT_CONFIGURED";
    throw err;
  }
  const usedModel = model || modelsCfg.gemini.defaultModel;
  const url = `${modelsCfg.gemini.endpoint}/${usedModel}:generateContent?key=${getKey()}`;
  const contents = toContents(history, aiCfg.systemPrompt);

  try {
    const res = await axios.post(url, {
      contents,
      generationConfig: modelsCfg.gemini.generationConfig,
    }, {
      headers: { "Content-Type": "application/json" },
      timeout: 60000,
    });
    const cand = res.data?.candidates?.[0];
    const text = cand?.content?.parts?.map((p) => p.text).filter(Boolean).join("\n").trim();
    if (!text) {
      const finish = cand?.finishReason || "UNKNOWN";
      throw new Error(`Balasan kosong dari Gemini (finishReason=${finish}).`);
    }
    return { text, model: usedModel };
  } catch (e) {
    const msg = e.response?.data?.error?.message || e.message;
    throw new Error(`Gemini error: ${msg}`);
  }
}

module.exports = { chat, isConfigured };
