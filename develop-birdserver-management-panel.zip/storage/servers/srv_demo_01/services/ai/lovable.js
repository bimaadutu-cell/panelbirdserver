// ==============================================
// AI CLIENT — LOVABLE AI GATEWAY (V3.3)
// ==============================================
// Client OpenAI-compatible untuk Lovable AI Gateway.
// Dipakai oleh ModeAI (Lovable) dan FileBotBuild.
// ==============================================
const axios = require("axios");
const modelsCfg = require("../../config/models");
const lovableCfg = require("../../config/lovable");
const aiCfg = require("../../config/ai");

function getKey() {
  return (lovableCfg.apiKey || modelsCfg.lovable.apiKey || process.env.LOVABLE_API_KEY || "").trim();
}

function isConfigured() {
  return modelsCfg.lovable.enabled && !!getKey();
}

function headers() {
  return {
    "Content-Type": "application/json",
    "Lovable-API-Key": getKey(),
    ...(lovableCfg.headers || {}),
  };
}

function toMessages(history, systemPrompt) {
  const msgs = [];
  if (systemPrompt) msgs.push({ role: "system", content: systemPrompt });
  for (const m of history) {
    msgs.push({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || ""),
    });
  }
  return msgs;
}

async function chat({ history, model, systemOverride }) {
  if (!isConfigured()) {
    const err = new Error(aiCfg.ui.notConfigured);
    err.code = "NOT_CONFIGURED";
    throw err;
  }
  const usedModel = model || lovableCfg.chatModel || modelsCfg.lovable.defaultModel;
  const messages = toMessages(history, systemOverride || aiCfg.systemPrompt);

  const body = { model: usedModel, messages, ...(modelsCfg.lovable.generationConfig || {}) };
  // GPT-5.6 wajib reasoning_effort=none saat pakai tools; aman untuk semua.
  if (/^openai\/gpt-5\.6/.test(usedModel)) body.reasoning_effort = "none";

  try {
    const res = await axios.post(lovableCfg.endpoint, body, {
      headers: headers(),
      timeout: lovableCfg.timeoutMs || 120000,
    });
    const text = res.data?.choices?.[0]?.message?.content?.trim();
    if (!text) throw new Error("Balasan kosong dari Lovable AI.");
    return { text, model: usedModel };
  } catch (e) {
    const status = e.response?.status;
    const msg = e.response?.data?.error?.message || e.response?.data?.message || e.message;
    if (status === 402) throw new Error("Kredit Lovable AI habis — silakan top up di workspace billing.");
    if (status === 429) throw new Error("Rate limit Lovable AI — coba lagi beberapa saat.");
    throw new Error(`Lovable AI error: ${msg}`);
  }
}

// Non-chat call untuk builder: minta 1 balasan besar JSON.
async function complete({ prompt, model, systemOverride }) {
  return chat({
    history: [{ role: "user", content: prompt }],
    model,
    systemOverride,
  });
}

module.exports = { chat, complete, isConfigured };
