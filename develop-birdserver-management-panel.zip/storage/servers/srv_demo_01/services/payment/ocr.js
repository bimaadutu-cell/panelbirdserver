// ==============================================
// OCR STRICT PAYMENT VERIFIER (V3.2)
// ==============================================
// Menggunakan tesseract.js untuk membaca isi bukti pembayaran.
// Cek: nominal, status (berhasil/selesai), tanggal, waktu,
// referensi/ID transaksi, nama merchant, metode pembayaran.
//
// Bila tesseract.js tidak terinstall, verifier akan tetap
// mengecek metadata gambar (ukuran, dedup), namun disarankan
// menginstall dependency 'tesseract.js' agar OCR aktif.
// ==============================================

let tesseract = null;
try { tesseract = require("tesseract.js"); }
catch { tesseract = null; }

async function extractText(imageBuffer) {
  if (!tesseract || !Buffer.isBuffer(imageBuffer)) return "";
  try {
    // eng+ind supaya kata "Berhasil / Sukses" ikut kebaca
    const langs = "eng+ind";
    const { data } = await tesseract.recognize(imageBuffer, langs, { logger: () => {} });
    return String(data?.text || "");
  } catch {
    // fallback ke english saja bila ind gagal (belum download data)
    try {
      const { data } = await tesseract.recognize(imageBuffer, "eng", { logger: () => {} });
      return String(data?.text || "");
    } catch { return ""; }
  }
}

const SUCCESS_KEYWORDS = [
  "berhasil", "sukses", "success", "completed", "paid",
  "selesai", "tuntas", "settled", "berhasi", "successful",
  "transaksi berhasil", "pembayaran berhasil", "payment success",
];
const REJECT_KEYWORDS = [
  "gagal", "failed", "pending", "batal", "cancel", "canceled",
  "cancelled", "refund", "ditolak", "tidak berhasil", "expired",
  "kadaluarsa", "waiting", "menunggu",
];

function normalize(s) {
  return String(s || "").toLowerCase().replace(/\s+/g, " ").trim();
}
function stripSpace(s) {
  return String(s || "").toLowerCase().replace(/\s+/g, "");
}

function looksSuccessful(text) {
  const t = normalize(text);
  if (!t) return false;
  const badFirst = REJECT_KEYWORDS.some((k) => t.includes(k));
  if (badFirst) return false;
  return SUCCESS_KEYWORDS.some((k) => t.includes(k));
}

function containsAmount(text, amount, tolerance = 500) {
  if (!text || !amount) return false;
  const cleaned = stripSpace(text).replace(/rp/gi, "");
  const candidates = new Set();
  for (const n of [amount - tolerance, amount, amount + tolerance]) {
    if (n <= 0) continue;
    candidates.add(String(n));
    candidates.add(n.toLocaleString("id-ID"));                   // 1.500
    candidates.add(n.toLocaleString("en-US"));                   // 1,500
    candidates.add(n.toLocaleString("id-ID").replace(/\./g, "")); // 1500
    candidates.add(n.toLocaleString("id-ID") + ",00");
    candidates.add(n.toLocaleString("id-ID") + ".00");
  }
  for (const c of candidates) if (cleaned.includes(stripSpace(c))) return true;
  return false;
}

function hasMerchant(text, merchant, aliases = []) {
  const clean = stripSpace(text);
  if (!clean) return false;
  const list = [merchant, ...(aliases || [])].filter(Boolean);
  if (!list.length) return true; // tidak dikonfigurasi
  return list.some((m) => clean.includes(stripSpace(m)));
}

function hasReference(text, ref) {
  if (!ref) return true;
  return stripSpace(text).includes(stripSpace(ref));
}

// Cek ada indikasi tanggal/waktu (dd/mm/yyyy, yyyy-mm-dd, jam hh:mm, dsb)
function hasDateTime(text) {
  const t = normalize(text);
  const dateRe = /(\d{1,2}[\/\-\s](jan|feb|mar|apr|mei|jun|jul|agu|sep|okt|nov|des)[a-z]*[\/\-\s]?\d{2,4})|(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})|(\d{4}[\/\-]\d{2}[\/\-]\d{2})/i;
  const timeRe = /\d{1,2}:\d{2}(:\d{2})?/;
  return dateRe.test(t) && timeRe.test(t);
}

function hasPaymentMethodKeyword(text, method) {
  const t = normalize(text);
  const map = {
    qris: ["qris"],
    dana: ["dana"],
    gopay: ["gopay", "go-pay", "go pay"],
    ovo: ["ovo"],
    transfer: ["transfer", "bca", "mandiri", "bri", "bni", "bank"],
    saldo: [],
  };
  const keys = map[method] || [];
  if (!keys.length) return true;
  return keys.some((k) => t.includes(k));
}

/**
 * Analisis penuh bukti pembayaran. Return {ok, reason, extracted}.
 * Semua kriteria WAJIB terpenuhi baru dinyatakan valid.
 */
async function analyze({ imageBuffer, invoice, reportedAmount, reference, merchantName, merchantAliases, tolerance }) {
  const text = await extractText(imageBuffer);
  if (!tesseract) {
    // Tesseract belum terinstall — kembalikan status khusus
    return { ok: false, reason: "OCR belum aktif (paket tesseract.js belum terinstall). Jalankan `npm install` lalu ulangi.", extracted: "", ocrDisabled: true };
  }
  if (!text || text.length < 20) {
    return { ok: false, reason: "OCR gagal membaca gambar (kualitas foto terlalu rendah / buram).", extracted: text };
  }

  const checks = [];

  // 1. status transaksi
  const okStatus = looksSuccessful(text);
  checks.push({ name: "status transaksi berhasil", ok: okStatus });

  // 2. nominal cocok invoice
  const okAmount = containsAmount(text, invoice.amount, tolerance);
  checks.push({ name: `nominal Rp${invoice.amount.toLocaleString("id-ID")}`, ok: okAmount });

  // 3. nominal reported cocok invoice (dobel check)
  const reportedOk = Math.abs((reportedAmount || 0) - invoice.amount) <= (tolerance || 0);
  checks.push({ name: "nominal yang diketik user sesuai invoice", ok: reportedOk });

  // 4. tanggal + waktu terlihat di struk
  const okDate = hasDateTime(text);
  checks.push({ name: "tanggal & waktu transaksi", ok: okDate });

  // 5. merchant / penerima
  const okMerchant = hasMerchant(text, merchantName, merchantAliases);
  checks.push({ name: `merchant "${merchantName}"`, ok: okMerchant });

  // 6. metode pembayaran
  const okMethod = hasPaymentMethodKeyword(text, invoice.method);
  checks.push({ name: `metode pembayaran ${String(invoice.method).toUpperCase()}`, ok: okMethod });

  // 7. referensi / ID transaksi (jika user mengetik ref)
  const okRef = hasReference(text, reference);
  checks.push({ name: "kode referensi transaksi", ok: okRef });

  const failed = checks.filter((c) => !c.ok);
  if (failed.length) {
    return {
      ok: false,
      reason: "Bukti pembayaran tidak lolos: " + failed.map((f) => f.name).join(", ") + ".",
      extracted: text,
      checks,
    };
  }
  return { ok: true, extracted: text, checks };
}

module.exports = {
  extractText, analyze,
  looksSuccessful, containsAmount, hasMerchant, hasReference,
  hasDateTime, hasPaymentMethodKeyword,
  isAvailable: () => !!tesseract,
};
