// ==============================================
// VERIFIKASI BUKTI PEMBAYARAN — STRICT + OCR (V3.2)
// ==============================================
// Aturan wajib (semua harus terpenuhi):
//   1. Invoice ada, milik chatId ini, status pending, belum expired
//   2. Foto bukti WAJIB valid (>1KB) dan disimpan ke disk
//   3. Nominal reported user cocok invoice (dalam toleransi)
//   4. Kode referensi minimal 4 karakter alfanumerik
//   5. Bukti belum pernah dipakai di invoice lain (dedup SHA)
//   6. STRICT OCR: bot MEMBACA isi gambar & mencocokkan:
//        - Status transaksi (Berhasil / Selesai / Success)
//        - Nominal transaksi
//        - Tanggal & waktu
//        - Nama merchant / penerima  (dari config/payment.js)
//        - Metode pembayaran
//        - Referensi / ID transaksi
//   7. Bila attempt gagal > maxProofAttempts → invoice REJECTED PERMANEN
//
// Efek gagal:
//   ❌ Invoice tetap pending / rejected
//   ❌ Panel TIDAK dibuat
//   ❌ Saldo TIDAK ditambah
//   ❌ Produk TIDAK dikirim
//   ❌ Bot meminta user upload ulang bukti yang benar
// ==============================================
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const db = require("../../database/db");
const paymentCfg = require("../../config/payment");
const logger = require("../../utils/logger");
const ocr = require("./ocr");

const PROOF_DIR = path.join(__dirname, "..", "..", "media", "proofs");
if (!fs.existsSync(PROOF_DIR)) fs.mkdirSync(PROOF_DIR, { recursive: true });

function saveProof(buffer, invoiceId) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 512) return null;
  const hash = crypto.createHash("sha1").update(buffer).digest("hex").slice(0, 10);
  const file = path.join(PROOF_DIR, `${invoiceId}_${hash}.jpg`);
  fs.writeFileSync(file, buffer);
  return file;
}
function isDuplicateProof(invoiceId, buffer) {
  if (!Buffer.isBuffer(buffer)) return false;
  const hash = crypto.createHash("sha1").update(buffer).digest("hex").slice(0, 10);
  const like = `%_${hash}.jpg`;
  const row = db.raw
    .prepare(`SELECT id FROM payments WHERE proof_path LIKE ? AND invoice_id<>? LIMIT 1`)
    .get(like, invoiceId);
  return !!row;
}

async function verify({ invoiceId, reportedAmount, reference, imageBuffer, chatId }) {
  const inv = db.getInvoice(invoiceId);
  if (!inv)                        return { ok: false, reason: "Invoice tidak ditemukan." };
  if (String(inv.chat_id) !== String(chatId))
                                   return { ok: false, reason: "Invoice bukan milik akun ini." };
  if (inv.status === "paid")       return { ok: false, reason: "Invoice sudah dibayar sebelumnya." };
  if (inv.status === "expired")    return { ok: false, reason: "Invoice sudah kadaluarsa." };
  if (inv.status === "rejected")   return { ok: false, reason: "Invoice sudah ditolak permanen — buat order baru." };
  if (Date.now() > inv.expires_at) {
    db.markInvoiceExpired(inv.id);
    return { ok: false, reason: "Invoice sudah kadaluarsa." };
  }
  if (!Buffer.isBuffer(imageBuffer) || imageBuffer.length < 1024) {
    return { ok: false, reason: "Bukti pembayaran (foto) wajib dilampirkan dan valid." };
  }
  if (!Number.isFinite(reportedAmount) || reportedAmount <= 0) {
    return { ok: false, reason: "Nominal pembayaran tidak valid." };
  }
  const tol = paymentCfg.amountTolerance ?? 0;
  if (Math.abs(reportedAmount - inv.amount) > tol) {
    return { ok: false, reason: `Nominal tidak sesuai invoice (harus Rp${inv.amount.toLocaleString("id-ID")}, dikirim Rp${reportedAmount.toLocaleString("id-ID")}).` };
  }
  const ref = (reference || "").replace(/\s+/g, "");
  if (!/^[a-z0-9]{4,}$/i.test(ref)) {
    return { ok: false, reason: "Kode/referensi transaksi minimal 4 karakter alfanumerik." };
  }
  if (isDuplicateProof(invoiceId, imageBuffer)) {
    return { ok: false, reason: "Bukti pembayaran ini terdeteksi pernah dipakai di invoice lain." };
  }

  // ==== STRICT OCR ANALYSIS ====
  if (paymentCfg.strictOCR !== false && inv.method !== "saldo") {
    if (!ocr.isAvailable()) {
      logger.warn("OCR strict aktif tapi tesseract.js belum terinstall. Jalankan `npm install`.");
      return {
        ok: false,
        reason:
          "Verifikasi ketat memerlukan OCR (tesseract.js). Admin harus menjalankan `npm install` " +
          "agar bukti pembayaran bisa diproses. Untuk sementara bukti Anda tidak bisa diverifikasi otomatis.",
      };
    }
    const analysis = await ocr.analyze({
      imageBuffer,
      invoice: inv,
      reportedAmount,
      reference,
      merchantName: paymentCfg.merchantName,
      merchantAliases: paymentCfg.merchantAliases || [],
      tolerance: tol,
    });
    if (!analysis.ok) {
      return { ok: false, reason: analysis.reason, ocr: analysis };
    }
  }

  return { ok: true, invoice: inv };
}

function recordPayment({ invoice, reportedAmount, reference, imageBuffer, status, reason }) {
  const proofPath = imageBuffer ? saveProof(imageBuffer, invoice.id) : null;
  db.savePayment({
    invoiceId: invoice.id,
    amount: invoice.amount,
    method: invoice.method,
    reportedAmount, reference, proofPath, status, reason,
  });
  const attempts = db.paymentAttempts(invoice.id);
  const max = paymentCfg.maxProofAttempts || 3;
  if (status === "invalid" && attempts >= max && invoice.status === "pending") {
    db.markInvoiceRejected(invoice.id);
    logger.warn(`Invoice ${invoice.id} ditolak permanen setelah ${attempts} percobaan gagal.`);
    return { rejected: true, attempts, max };
  }
  return { rejected: false, attempts, max };
}

module.exports = { verify, recordPayment, saveProof };
