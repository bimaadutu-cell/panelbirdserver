const db = require("../../database/db");
const paymentCfg = require("../../config/payment");
const settings = require("../../config/settings");
const { genInvoiceId, rupiah, fmtDate } = require("../../helpers/format");

const expireMs = () =>
  ((paymentCfg.invoiceExpireMinutes || settings.security.invoiceExpireMinutes || 30) * 60 * 1000);

function createInvoice({ orderId, chatId, platform, amount, method }) {
  const inv = {
    id: genInvoiceId(),
    orderId, chatId: String(chatId), platform,
    amount, method,
    expiresAt: Date.now() + expireMs(),
  };
  db.createInvoice(inv);
  return inv;
}

function paymentInstruction(method, amount) {
  const cfg = paymentCfg.methods[method];
  if (!cfg || !cfg.enabled) return null;
  if (cfg.internal) {
    // metode internal (saldo) — tidak butuh instruksi transfer
    return { text: `${cfg.label}\nNominal: ${rupiah(amount)}`, image: null };
  }
  const lines = [
    `Metode : ${cfg.label}`,
    `Nominal: ${rupiah(amount)}`,
  ];
  if (cfg.number) lines.push(`Nomor  : ${cfg.number}`);
  if (cfg.name) lines.push(`A/N    : ${cfg.name}`);
  return { text: lines.join("\n"), image: cfg.image || null };
}

function activeMethods() {
  return Object.entries(paymentCfg.methods)
    .filter(([, v]) => v.enabled)
    .map(([k, v]) => ({ key: k, label: v.label }));
}

function invoiceCard(inv) {
  return [
    `🧾 *INVOICE ${inv.id}*`,
    `Order  : ${inv.order_id || inv.orderId}`,
    `Nominal: ${rupiah(inv.amount)}`,
    `Metode : ${inv.method.toUpperCase()}`,
    `Kadaluarsa: ${fmtDate(inv.expires_at || inv.expiresAt)}`,
    ``,
    `Kirim BUKTI TRANSFER (foto/gambar) ke chat ini.`,
    `Ketik *batal* untuk membatalkan.`,
  ].join("\n");
}

module.exports = { createInvoice, paymentInstruction, activeMethods, invoiceCard };
