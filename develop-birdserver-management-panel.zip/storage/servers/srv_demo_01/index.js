// ==============================================
// BOT STORE V3 — ENTRYPOINT
// ==============================================
// Skip logic:
//   - Jika TELEGRAM_BOT_TOKEN terisi → jalankan Telegram, SKIP pairing WhatsApp.
//   - Jika TELEGRAM_BOT_TOKEN kosong tapi settings.platforms.whatsapp = true →
//     SKIP Telegram, jalankan WhatsApp saja.
//   - Bisa juga jalan dua-duanya bila settings dibuat true dan token TG ada.
// ==============================================
require("dotenv").config();

const logger = require("./utils/logger");
const { validate: validateConfig } = require("./utils/validateConfig");
const settings = require("./config/settings");
const scheduler = require("./scheduler");
const panelCfg = require("./config/panel");
const panelSvc = require("./services/panel/pterodactyl");

process.on("uncaughtException", (e) => logger.error("uncaught:", e.message));
process.on("unhandledRejection", (e) => logger.error("unhandled:", e?.message || e));

(async () => {
  logger.info("═══════════════════════════════════════");
  logger.info("   BOT STORE V5 — FILEBOTBUILD PRO      ");
  validateConfig();
  logger.info("═══════════════════════════════════════");

  // Discover meta Pterodactyl di startup (best effort)
  for (const s of panelCfg.servers) {
    try { await panelSvc.discoverMeta(s); }
    catch (e) { logger.warn(`Panel ${s.key} discover skipped: ${e.message}`); }
  }

  scheduler.start();

  // === Auto skip logic ===
  const tgToken = (process.env.TELEGRAM_BOT_TOKEN || "").trim();
  const runTelegram = settings.platforms.telegram && !!tgToken;
  // Jika token Telegram ada → skip WhatsApp (kecuali user memaksa keduanya via env FORCE_WA=1)
  const forceWA = String(process.env.FORCE_WA || "").trim() === "1";
  const runWhatsapp = settings.platforms.whatsapp && (!tgToken || forceWA);

  logger.info(`Platform aktif → Telegram: ${runTelegram ? "YES" : "no"} | WhatsApp: ${runWhatsapp ? "YES" : "no"}`);

  const tasks = [];
  if (runTelegram) tasks.push(require("./platforms/telegram").start());
  if (runWhatsapp) tasks.push(require("./platforms/whatsapp").start());

  if (!tasks.length) {
    logger.error("Tidak ada platform aktif. Isi TELEGRAM_BOT_TOKEN di .env atau aktifkan WhatsApp.");
    return;
  }

  await Promise.allSettled(tasks);
  logger.success("Semua service jalan. Ctrl+C untuk stop.");
})();


process.stdin.resume();
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  const command = String(chunk).trim();
  if (!command) return;
  console.log(`[console] received command: ${command}`);
  if (command === "status") {
    console.log(`[status] uptime=${Math.floor(process.uptime())}s pid=${process.pid}`);
  } else if (command === "help") {
    console.log("Available commands: status, help, ping, echo <text>");
  } else if (command === "ping") {
    console.log("pong");
  } else if (command.startsWith("echo ")) {
    console.log(command.slice(5));
  }
});
