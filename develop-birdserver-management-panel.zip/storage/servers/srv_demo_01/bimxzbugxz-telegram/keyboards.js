// ============================================================
// keyboards.js — Semua inline keyboard bot
// ============================================================
import { InlineKeyboard } from 'grammy';

export function mainMenuKeyboard(isAdmin) {
  const kb = new InlineKeyboard()
    .text('🆕 CREATE AKUN BIMXZBUGXZ', 'create:start').row()
    .text('💎 MY LIMIT', 'limit:view')
    .text('💳 TAMBAH LIMIT', 'payment:limit').row()
    .text('📖 BANTUAN', 'help');
  if (isAdmin) {
    kb.row().text('⚙️ ADMIN PANEL', 'admin:menu');
  }
  return kb;
}

export function createStartKeyboard() {
  return new InlineKeyboard()
    .text('🚀 MULAI', 'create:start')
    .text('❌ BATAL', 'create:cancel');
}

export function roleKeyboard() {
  return new InlineKeyboard()
    .text('👤 PENGGUNA • 7 HARI', 'create:role:PENGGUNA').row()
    .text('🛒 RESELLER • 30 HARI', 'create:role:RESELLER').row()
    .text('👑 OWNER • 90 HARI', 'create:role:OWNER').row()
    .text('❌ BATAL', 'create:cancel');
}

export function confirmKeyboard() {
  return new InlineKeyboard()
    .text('💎 BAYAR PAKAI LIMIT', 'create:pay:limit').row()
    .text('📱 BAYAR PAKAI QR', 'create:pay:qr').row()
    .text('✏️ EDIT', 'create:edit')
    .text('❌ BATAL', 'create:cancel');
}

export function noLimitKeyboard() {
  return new InlineKeyboard()
    .text('📱 BAYAR PAKAI QR', 'create:pay:qr').row()
    .text('💳 TAMBAH LIMIT', 'payment:limit').row()
    .text('🏠 MENU', 'menu');
}

/** Keyboard saat API gagal di alur limit — user bisa coba lagi tanpa isi ulang data. */
export function apiFailKeyboard() {
  return new InlineKeyboard()
    .text('🔁 COBA LAGI', 'create:pay:limit').row()
    .text('📱 BAYAR PAKAI QR', 'create:pay:qr').row()
    .text('🏠 MENU', 'menu');
}

export function paymentKeyboard(paymentId) {
  return new InlineKeyboard()
    .text('📤 KIRIM BUKTI', `pay:proof:${paymentId}`).row()
    .text('❌ BATAL', `pay:cancel:${paymentId}`);
}

export function ownerReviewKeyboard(paymentId) {
  return new InlineKeyboard()
    .text('✅ KONFIRMASI', `pay:confirm:${paymentId}`)
    .text('❌ TOLAK', `pay:reject:${paymentId}`);
}

export function ownerRetryKeyboard(paymentId) {
  return new InlineKeyboard()
    .text('🔄 RETRY', `pay:retry:${paymentId}`)
    .text('❌ TUTUP', `pay:close:${paymentId}`);
}

export function accountResultKeyboard() {
  return new InlineKeyboard()
    .text('🆕 BUAT AKUN LAGI', 'create:start').row()
    .text('💎 MY LIMIT', 'limit:view').row()
    .text('🏠 MENU UTAMA', 'menu');
}

export function limitMenuKeyboard() {
  return new InlineKeyboard()
    .text('🆕 CREATE ACCOUNT', 'create:start').row()
    .text('💳 TAMBAH LIMIT', 'payment:limit').row()
    .text('🏠 MENU', 'menu');
}

export function backMenuKeyboard() {
  return new InlineKeyboard().text('🏠 MENU', 'menu');
}

export function adminMenuKeyboard() {
  return new InlineKeyboard()
    .text('👥 USERS', 'admin:users')
    .text('💰 PENDING PAYMENT', 'admin:pending').row()
    .text('📊 STATISTIK', 'admin:stats')
    .text('➕ TAMBAH LIMIT', 'admin:addlimit').row()
    .text('📋 ACCOUNT LOG', 'admin:log')
    .text('🔌 API STATUS', 'admin:apistatus').row()
    .text('🏠 MENU', 'menu');
}

export function adminBackKeyboard() {
  return new InlineKeyboard()
    .text('⚙️ ADMIN PANEL', 'admin:menu')
    .text('🏠 MENU', 'menu');
}
