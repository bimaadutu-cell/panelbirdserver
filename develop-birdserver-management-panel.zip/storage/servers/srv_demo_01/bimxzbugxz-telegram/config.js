// ============================================================
// config.js — Konfigurasi terpusat (lazy-read dari process.env)
// Semua nilai dibaca saat diakses supaya test bisa set env dulu.
// ============================================================
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const PROJECT_ROOT = path.resolve(path.dirname(__filename));

function env(key, fallback = '') {
  const value = process.env[key];
  return value === undefined || value === '' ? fallback : value;
}

function envNumber(key, fallback) {
  const n = Number(env(key, String(fallback)));
  return Number.isFinite(n) ? n : fallback;
}

/** Role yang boleh dipilih user biasa. DEVELOPER TIDAK termasuk. */
export const ALLOWED_ROLES = Object.freeze(['PENGGUNA', 'RESELLER', 'OWNER']);

export const ROLES = Object.freeze({
  PENGGUNA: Object.freeze({ label: '👤 PENGGUNA', durationDays: 7 }),
  RESELLER: Object.freeze({ label: '🛒 RESELLER', durationDays: 30 }),
  OWNER: Object.freeze({ label: '👑 OWNER', durationDays: 90 }),
  DEVELOPER: Object.freeze({ label: '👨‍💻 DEVELOPER', durationDays: 365 }), // internal saja
});

export const PAYMENT_STATUS = Object.freeze([
  'WAITING_PAYMENT',
  'PROOF_SUBMITTED',
  'API_PROCESSING',
  'SUCCESS',
  'REJECTED',
  'API_FAILED',
  'EXPIRED',
]);

export const config = {
  get projectRoot() { return PROJECT_ROOT; },

  get telegramBotToken() { return env('TELEGRAM_BOT_TOKEN'); },
  get bimxzApiKey() { return env('BIMXZ_API_KEY'); },
  get bimxzApiUrl() {
    return env('BIMXZ_API_URL', 'https://bimxzbugv2.up.railway.app').replace(/\/+$/, '');
  },

  get ownerId() { return envNumber('OWNER_ID', 0); },
  get developerIds() {
    return env('DEVELOPER_IDS', '')
      .split(',')
      .map((s) => Number(s.trim()))
      .filter((n) => Number.isFinite(n) && n > 0);
  },
  get adminIds() { return [this.ownerId, ...this.developerIds]; },

  get defaultLimit() { return envNumber('DEFAULT_LIMIT', 2); },
  get paymentAddLimit() { return envNumber('PAYMENT_ADD_LIMIT', 10); },

  get qrImagePath() { return path.resolve(PROJECT_ROOT, env('QR_IMAGE_PATH', 'assets/qris.png')); },
  get thumbnailPath() { return path.resolve(PROJECT_ROOT, env('THUMBNAIL_PATH', 'assets/thumbnail.jpg')); },

  get botName() { return env('BOT_NAME', 'BIMXZBUGXZ'); },
  get supportUsername() { return env('SUPPORT_USERNAME', '@administrator'); },
  get currency() { return env('CURRENCY', 'IDR'); },

  get accountPricePengguna() { return envNumber('ACCOUNT_PRICE_USER', 10000); },
  get accountPriceReseller() { return envNumber('ACCOUNT_PRICE_RESELLER', 20000); },
  get accountPriceOwner() { return envNumber('ACCOUNT_PRICE_OWNER', 30000); },
  get limitPrice() { return envNumber('LIMIT_PRICE', 10000); },

  get pendingPaymentTimeout() { return envNumber('PENDING_PAYMENT_TIMEOUT', 1800); },
  get encryptionKey() { return env('ENCRYPTION_KEY'); },

  get databasePath() { return path.resolve(PROJECT_ROOT, env('DB_PATH', 'data/database.sqlite')); },
  get logLevel() { return env('LOG_LEVEL', 'info'); },
};

export function accountPrice(role) {
  switch (role) {
    case 'RESELLER': return config.accountPriceReseller;
    case 'OWNER': return config.accountPriceOwner;
    default: return config.accountPricePengguna;
  }
}

export function roleDurationDays(role) {
  return ROLES[role]?.durationDays ?? 7;
}

export function roleLabel(role) {
  return ROLES[role]?.label ?? role ?? '-';
}

export function isAdminId(id) {
  return config.adminIds.includes(Number(id));
}

export function isOwnerId(id) {
  return Number(id) === config.ownerId;
}

/** Validasi konfigurasi saat bot start. Mengembalikan daftar masalah. */
export function validateConfig() {
  const problems = [];
  if (!config.telegramBotToken) problems.push('TELEGRAM_BOT_TOKEN kosong');
  if (!config.bimxzApiKey) problems.push('BIMXZ_API_KEY kosong');
  if (!config.ownerId) problems.push('OWNER_ID kosong / tidak valid');
  if (!config.encryptionKey) problems.push('ENCRYPTION_KEY kosong (wajib, minimal 16 karakter)');
  return problems;
}
