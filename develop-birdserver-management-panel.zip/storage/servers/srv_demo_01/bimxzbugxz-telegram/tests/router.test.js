// ============================================================
// tests/router.test.js — REGRESI: tombol inline harus bisa diklik
// 1) grammY harus mendispatch callback data (bukan exact-match 'data')
// 2) callbacksRouter menangani setiap payload tombol dengan benar
// ============================================================
import test from 'node:test';
import assert from 'node:assert/strict';
import { Bot } from 'grammy';
import { initDatabase, closeDatabase, getOrCreateUser } from '../database.js';
import { setSession, clearSession } from '../middleware.js';
import { callbacksRouter } from '../handlers/callbacks.js';

const BOT_INFO = {
  id: 123, is_bot: true, first_name: 'Bimx', username: 'bimxzbugxz_bot',
  can_join_groups: true, can_read_all_group_messages: false, supports_inline_queries: false,
};

test('grammY: bot.on("callback_query:data") menangkap SEMUA payload tombol', async () => {
  const bot = new Bot('123:fake-token', { botInfo: BOT_INFO });
  const hits = [];
  // pola yang SALAH (bug lama di bot.js):
  bot.callbackQuery('data', (ctx) => hits.push('BUGGY:' + ctx.callbackQuery.data));
  // pola yang BENAR (sekarang dipakai di bot.js):
  bot.on('callback_query:data', (ctx) => hits.push('OK:' + ctx.callbackQuery.data));

  const update = {
    update_id: 1,
    callback_query: {
      id: 'q1',
      from: { id: 1, is_bot: false, first_name: 'x' },
      chat_instance: 'c',
      data: 'create:start',
    },
  };
  await bot.handleUpdate(update);

  assert.ok(hits.includes('OK:create:start'), 'handler yang benar harus dipanggil');
  assert.ok(!hits.some((h) => h.startsWith('BUGGY')), 'pola lama tidak boleh match');
});

test('grammY: payload pay:confirm:PAY-xxx juga ter-dispatch', async () => {
  const bot = new Bot('123:fake-token', { botInfo: BOT_INFO });
  const hits = [];
  bot.on('callback_query:data', (ctx) => hits.push(ctx.callbackQuery.data));
  const update = {
    update_id: 2,
    callback_query: {
      id: 'q2',
      from: { id: 1, is_bot: false, first_name: 'x' },
      chat_instance: 'c',
      data: 'pay:confirm:PAY-20260809-0001',
    },
  };
  await bot.handleUpdate(update);
  assert.deepEqual(hits, ['pay:confirm:PAY-20260809-0001']);
});

// ------------------------------------------------------------
// Fake context untuk menguji callbacksRouter
// ------------------------------------------------------------
function makeFakeCtx(data, from) {
  const calls = { answers: [], replies: [], photos: [], documents: [] };
  let answered = false;
  const ctx = {
    from: from || { id: 9001, first_name: 'Tester', username: 'tester', is_bot: false },
    callbackQuery: {
      id: 'q9',
      from: from || { id: 9001, first_name: 'Tester', username: 'tester', is_bot: false },
      chat_instance: 'c',
      data,
      message: { message_id: 9, chat: { id: 9001, type: 'private' } },
    },
    api: {
      sendMessage: async () => ({ message_id: 100 }),
      sendPhoto: async () => ({ message_id: 101 }),
      sendDocument: async () => ({ message_id: 102 }),
      editMessageCaption: async () => ({}),
      editMessageReplyMarkup: async () => ({}),
    },
    answerCallbackQuery: async (opt) => {
      if (answered) throw new Error('query is too old or already answered');
      answered = true;
      calls.answers.push(opt || {});
      return {};
    },
    reply: async (text, opts) => { calls.replies.push({ text, opts }); return { message_id: 2 }; },
    replyWithPhoto: async (photo, opts) => { calls.photos.push({ photo, opts }); return { message_id: 3 }; },
    replyWithDocument: async (doc, opts) => { calls.documents.push({ doc, opts }); return { message_id: 4 }; },
  };
  return { ctx, calls };
}

initDatabase(':memory:');
getOrCreateUser(9001, { username: 'tester', first_name: 'Tester' });

test('router: menu -> kirim menu utama (dengan thumbnail)', async () => {
  const { ctx, calls } = makeFakeCtx('menu');
  await callbacksRouter(ctx);
  assert.ok(calls.photos.length >= 1 || calls.replies.length >= 1, 'harus ada pesan terkirim');
  assert.equal(calls.answers.length, 1, 'callback query harus dijawab');
});

test('router: help -> kirim bantuan', async () => {
  const { ctx, calls } = makeFakeCtx('help');
  await callbacksRouter(ctx);
  assert.ok(calls.photos.length >= 1 || calls.replies.length >= 1);
});

test('router: create:start -> mulai alur buat akun', async () => {
  clearSession(9001);
  const { ctx, calls } = makeFakeCtx('create:start');
  await callbacksRouter(ctx);
  const text = calls.replies.map((r) => r.text).join('\n');
  assert.match(text, /STEP 1\/3/);
});

test('router: create:role:PENGGUNA -> layar konfirmasi (butuh sesi role)', async () => {
  setSession(9001, { state: 'CREATE_ROLE', username: 'akun1', password: 'rahasia123', role: null });
  const { ctx, calls } = makeFakeCtx('create:role:PENGGUNA');
  await callbacksRouter(ctx);
  const photos = calls.photos.map((p) => String(p.opts?.caption || '')).join('\n');
  const replies = calls.replies.map((r) => r.text).join('\n');
  assert.match(photos + replies, /KONFIRMASI AKUN/);
});

test('router: limit:view -> layar MY LIMIT', async () => {
  const { ctx, calls } = makeFakeCtx('limit:view');
  await callbacksRouter(ctx);
  const photos = calls.photos.map((p) => String(p.opts?.caption || '')).join('\n');
  const replies = calls.replies.map((r) => r.text).join('\n');
  assert.match(photos + replies, /MY LIMIT/);
});

test('router: payment:limit -> membuat payment LIMIT & kirim QR', async () => {
  const { ctx, calls } = makeFakeCtx('payment:limit');
  await callbacksRouter(ctx);
  assert.ok(calls.photos.length >= 1, 'QR harus terkirim (file qris.png ada)');
  const caption = String(calls.photos[0]?.opts?.caption || '');
  assert.match(caption, /TAMBAH LIMIT/);
  assert.match(caption, /\+10 LIMIT/);
});

test('router: pay:proof:PAY-x -> toast instruksi kirim bukti', async () => {
  const { ctx, calls } = makeFakeCtx('pay:proof:PAY-20260809-0001');
  await callbacksRouter(ctx);
  assert.ok(calls.answers.length >= 1);
  assert.match(calls.answers[0].text || '', /bukti/i);
});

test('router: admin:menu oleh user biasa -> DITOLAK + toast', async () => {
  const { ctx, calls } = makeFakeCtx('admin:menu', { id: 12345, first_name: 'Biasa', is_bot: false });
  await callbacksRouter(ctx);
  assert.ok(calls.answers.length >= 1, 'callback harus dijawab');
  assert.match(calls.answers[0].text || '', /tidak memiliki akses/i);
});

test('router: payload tak dikenal -> pesan error', async () => {
  const { ctx, calls } = makeFakeCtx('foo:bar');
  await callbacksRouter(ctx);
  const text = calls.replies.map((r) => r.text).join('\n');
  assert.match(text, /tidak dikenal/);
});

test.after(() => closeDatabase());
