// ============================================================
// tests/account.test.js — create via limit, validasi, crypto, admin
// ============================================================
import test from 'node:test';
import assert from 'node:assert/strict';
import { initDatabase, closeDatabase, getDb, getOrCreateUser, getUserByTelegramId } from '../database.js';
import { createAccountWithLimit } from '../services/accountService.js';
import { validateUsername, validatePassword, validateRole } from '../handlers/createAccount.js';
import { encryptPassword, decryptPassword } from '../crypto.js';
import { isAdminId } from '../config.js';

process.env.ENCRYPTION_KEY = 'test-encryption-key-123456';
process.env.DEFAULT_LIMIT = '2';

initDatabase(':memory:');

test('validasi username', () => {
  assert.equal(validateUsername('akun123'), true);
  assert.equal(validateUsername('my_account-1'), true);
  assert.equal(validateUsername('ab'), false); // terlalu pendek
  assert.equal(validateUsername('a'.repeat(21)), false); // terlalu panjang
  assert.equal(validateUsername('akun dengan spasi'), false);
  assert.equal(validateUsername('akun@x'), false); // karakter terlarang
});

test('validasi password', () => {
  assert.equal(validatePassword('123456'), true);
  assert.equal(validatePassword('12345'), false);
  assert.equal(validatePassword(''), false);
});

test('validasi role: DEVELOPER TIDAK boleh dipilih user', () => {
  assert.equal(validateRole('PENGGUNA'), true);
  assert.equal(validateRole('RESELLER'), true);
  assert.equal(validateRole('OWNER'), true);
  assert.equal(validateRole('DEVELOPER'), false);
  assert.equal(validateRole('HACKER'), false);
});

test('create via limit sukses -> limit berkurang + log akun', async () => {
  getOrCreateUser(3001, { username: 'andi' });
  const mockApi = async () => ({
    ok: true, status: 200,
    data: { username: 'akunA', role: 'PENGGUNA', expiresAt: '2026-12-31T00:00:00.000Z' },
    raw: {},
  });
  const res = await createAccountWithLimit(3001, {
    username: 'akunA', password: 'rahasia123', role: 'PENGGUNA',
  }, { apiFn: mockApi });
  assert.equal(res.ok, true);
  assert.equal(res.remainingLimit, 1);
  assert.equal(getUserByTelegramId(3001).limit, 1);
  assert.equal(getUserByTelegramId(3001).total_created, 1);
});

test('API GAGAL -> limit TIDAK berkurang', async () => {
  getOrCreateUser(3002, { username: 'budi2' });
  const failApi = async () => ({
    ok: false, status: 500,
    error: { code: 'SERVER_ERROR', message: 'down' },
    data: null, raw: null,
  });
  const res = await createAccountWithLimit(3002, {
    username: 'akunB', password: 'rahasia123', role: 'PENGGUNA',
  }, { apiFn: failApi });
  assert.equal(res.ok, false);
  assert.equal(res.error, 'API_FAILED');
  assert.equal(getUserByTelegramId(3002).limit, 2); // TIDAK berkurang
  assert.equal(getUserByTelegramId(3002).total_created, 0);
});

test('limit 0 -> NO_LIMIT, API tidak dipanggil', async () => {
  getOrCreateUser(3003, { username: 'caca' });
  getDb().prepare('UPDATE users SET "limit" = 0 WHERE telegram_id = ?').run(3003);
  let called = false;
  const spyApi = async () => { called = true; return { ok: true, status: 200, data: {} }; };
  const res = await createAccountWithLimit(3003, {
    username: 'akunC', password: 'rahasia123', role: 'PENGGUNA',
  }, { apiFn: spyApi });
  assert.equal(res.ok, false);
  assert.equal(res.error, 'NO_LIMIT');
  assert.equal(called, false);
});

test('enkripsi & dekripsi password (AES-256-GCM)', () => {
  const enc = encryptPassword('sangat-rahasia');
  assert.notEqual(enc, 'sangat-rahasia');
  assert.equal(decryptPassword(enc), 'sangat-rahasia');
  assert.throws(() => decryptPassword('payload-invalid'));
});

test('validasi admin (OWNER/DEVELOPER)', () => {
  process.env.OWNER_ID = '999999';
  process.env.DEVELOPER_IDS = '888888,777777';
  assert.equal(isAdminId(999999), true);
  assert.equal(isAdminId(888888), true);
  assert.equal(isAdminId(777777), true);
  assert.equal(isAdminId(123456), false); // user biasa
});

test.after(() => closeDatabase());
