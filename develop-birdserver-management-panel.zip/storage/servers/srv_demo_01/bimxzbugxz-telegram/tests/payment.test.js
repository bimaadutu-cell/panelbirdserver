// ============================================================
// tests/payment.test.js — alur pembayaran QR (ACCOUNT & LIMIT)
// ============================================================
import test from 'node:test';
import assert from 'node:assert/strict';
import { initDatabase, closeDatabase, getDb, getOrCreateUser, getPaymentByPaymentId } from '../database.js';
import * as paymentService from '../services/paymentService.js';
import { formatDate } from '../helpers.js';

process.env.ENCRYPTION_KEY = 'test-encryption-key-123456';
process.env.PAYMENT_ADD_LIMIT = '10';

initDatabase(':memory:');

const telegramId = 2001;
getOrCreateUser(telegramId, { username: 'siti' });

const okApi = (username, role) => async () => ({
  ok: true, status: 200,
  data: { username, role, expiresAt: '2026-12-31T00:00:00.000Z' },
  raw: {},
});
const failApi = async () => ({
  ok: false, status: 500,
  error: { code: 'SERVER_ERROR', message: 'server down' },
  data: null, raw: null,
});

test('buat payment ACCOUNT, password TERSIMPAN TERENKRIPSI', () => {
  const p = paymentService.createAccountPayment({
    telegramId, username: 'akun1', password: 'rahasia123', role: 'RESELLER',
  });
  assert.equal(p.payment_type, 'ACCOUNT');
  assert.match(p.payment_id, /^PAY-\d{8}-\d{4}$/);
  assert.notEqual(p.encrypted_password, 'rahasia123');
  assert.ok(p.encrypted_password.includes(':')); // iv:tag:ciphertext
  assert.equal(p.duration, 30);
  assert.equal(p.role, 'RESELLER');
});

test('submit proof -> PROOF_SUBMITTED (tidak auto-approve)', () => {
  paymentService.createAccountPayment({
    telegramId, username: 'akun2', password: 'rahasia123', role: 'PENGGUNA',
  });
  const res = paymentService.submitProof({ telegramId, fileId: 'AgAC-photo', fileType: 'photo' });
  assert.equal(res.ok, true);
  assert.equal(res.payment.status, 'PROOF_SUBMITTED');
  assert.equal(res.payment.proof_file_id, 'AgAC-photo');
});

test('confirm LIMIT -> limit bertambah + SUCCESS', async () => {
  const p = paymentService.createLimitPayment({ telegramId });
  paymentService.submitProof({ telegramId, fileId: 'f-limit' });
  const res = await paymentService.confirmPayment(p.payment_id, 999999);
  assert.equal(res.ok, true);
  assert.equal(res.type, 'LIMIT');
  assert.ok(res.user.limit >= 10);
  assert.equal(getPaymentByPaymentId(p.payment_id).status, 'SUCCESS');
});

test('confirm ACCOUNT sukses -> API dipanggil, password dihapus', async () => {
  const p = paymentService.createAccountPayment({
    telegramId, username: 'akun3', password: 'rahasia123', role: 'OWNER',
  });
  paymentService.submitProof({ telegramId, fileId: 'f3' });
  const res = await paymentService.confirmPayment(p.payment_id, 999999, {
    apiFn: okApi('akun3', 'OWNER'),
  });
  assert.equal(res.ok, true);
  assert.equal(res.type, 'ACCOUNT');
  assert.equal(res.account.expiresAt, formatDate('2026-12-31T00:00:00.000Z'));
  const stored = getPaymentByPaymentId(p.payment_id);
  assert.equal(stored.status, 'SUCCESS');
  assert.equal(stored.encrypted_password, null); // password dihapus
});

test('ANTI DOUBLE APPROVE: payment sukses tidak bisa diproses ulang', async () => {
  const p = paymentService.createAccountPayment({
    telegramId, username: 'akun4', password: 'rahasia123', role: 'PENGGUNA',
  });
  paymentService.submitProof({ telegramId, fileId: 'f4' });
  const first = await paymentService.confirmPayment(p.payment_id, 999999, {
    apiFn: okApi('akun4', 'PENGGUNA'),
  });
  assert.equal(first.ok, true);
  const second = await paymentService.confirmPayment(p.payment_id, 999999, {
    apiFn: okApi('akun4', 'PENGGUNA'),
  });
  assert.equal(second.ok, false);
  assert.equal(second.error, 'INVALID_STATUS');
  const logs = getDb()
    .prepare('SELECT COUNT(*) AS c FROM account_logs WHERE payment_id = ?')
    .get(p.payment_id);
  assert.equal(logs.c, 1); // hanya SATU akun dibuat
});

test('API gagal -> API_FAILED, limit/akun tidak dibuat, retry bisa sukses', async () => {
  const p = paymentService.createAccountPayment({
    telegramId, username: 'akun5', password: 'rahasia123', role: 'PENGGUNA',
  });
  paymentService.submitProof({ telegramId, fileId: 'f5' });
  const res = await paymentService.confirmPayment(p.payment_id, 999999, { apiFn: failApi });
  assert.equal(res.ok, false);
  assert.equal(res.error, 'API_FAILED');
  const failed = getPaymentByPaymentId(p.payment_id);
  assert.equal(failed.status, 'API_FAILED');
  assert.ok(failed.encrypted_password); // password masih ada utk retry

  const retry = await paymentService.retryPayment(p.payment_id, 999999, {
    apiFn: okApi('akun5', 'PENGGUNA'),
  });
  assert.equal(retry.ok, true);
  const done = getPaymentByPaymentId(p.payment_id);
  assert.equal(done.status, 'SUCCESS');
  assert.equal(done.encrypted_password, null);
  assert.ok(done.api_attempts >= 1);
});

test('reject payment -> REJECTED + password dihapus', () => {
  const p = paymentService.createAccountPayment({
    telegramId, username: 'akun6', password: 'rahasia123', role: 'PENGGUNA',
  });
  paymentService.submitProof({ telegramId, fileId: 'f6' });
  const res = paymentService.rejectPayment(p.payment_id, 999999);
  assert.equal(res.ok, true);
  const stored = getPaymentByPaymentId(p.payment_id);
  assert.equal(stored.status, 'REJECTED');
  assert.equal(stored.encrypted_password, null);
});

test('payment kadaluarsa (timeout) -> EXPIRED + password dihapus', () => {
  const p = paymentService.createAccountPayment({
    telegramId, username: 'akun7', password: 'rahasia123', role: 'PENGGUNA',
  });
  getDb()
    .prepare('UPDATE payments SET created_at = ? WHERE payment_id = ?')
    .run(Math.floor(Date.now() / 1000) - 100000, p.payment_id);
  const expired = paymentService.expireOldPayments();
  assert.ok(expired.some((x) => x.payment_id === p.payment_id));
  const stored = getPaymentByPaymentId(p.payment_id);
  assert.equal(stored.status, 'EXPIRED');
  assert.equal(stored.encrypted_password, null);
});

test('cancel payment (WAITING_PAYMENT -> EXPIRED)', () => {
  const p = paymentService.createAccountPayment({
    telegramId, username: 'akun8', password: 'rahasia123', role: 'PENGGUNA',
  });
  const res = paymentService.cancelPayment(p.payment_id);
  assert.equal(res.ok, true);
  assert.equal(getPaymentByPaymentId(p.payment_id).status, 'EXPIRED');
});

test.after(() => closeDatabase());
