// ============================================================
// tests/database.test.js — user, limit, payment, stats
// ============================================================
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  initDatabase, closeDatabase, getDb,
  getOrCreateUser, getUserByTelegramId, addUserLimit, decrementUserLimit,
  insertPayment, getPaymentByPaymentId, getLatestPendingPayment,
  countPaymentsLike, insertAccountLog, getStats,
} from '../database.js';

process.env.DEFAULT_LIMIT = '2';

initDatabase(':memory:');

test('user baru mendapat limit default 2', () => {
  const user = getOrCreateUser(1001, { username: 'budi', first_name: 'Budi' });
  assert.equal(user.limit, 2);
  assert.equal(user.telegram_id, 1001);
});

test('getOrCreateUser tidak membuat duplikat', () => {
  getOrCreateUser(1001, { username: 'budi' });
  const row = getDb().prepare('SELECT COUNT(*) AS c FROM users WHERE telegram_id = 1001').get();
  assert.equal(row.c, 1);
});

test('tambah limit & kurangi limit', () => {
  const newLimit = addUserLimit(1001, 10);
  assert.equal(newLimit, 12);
  assert.equal(decrementUserLimit(1001), true);
  assert.equal(getUserByTelegramId(1001).limit, 11);
});

test('decrement gagal jika limit 0', () => {
  getOrCreateUser(1002, { username: 'dea' });
  getDb().prepare('UPDATE users SET "limit" = 0 WHERE telegram_id = ?').run(1002);
  assert.equal(decrementUserLimit(1002), false);
});

test('payment id unik & format PAY-YYYYMMDD-XXXX', () => {
  insertPayment({
    payment_id: 'PAY-20260809-0001',
    telegram_id: 1001,
    payment_type: 'ACCOUNT',
    account_username: 'akun1',
    encrypted_password: 'enc:data',
    role: 'PENGGUNA',
    duration: 7,
    amount: 10000,
    status: 'WAITING_PAYMENT',
  });
  const p = getPaymentByPaymentId('PAY-20260809-0001');
  assert.equal(p.status, 'WAITING_PAYMENT');
  assert.match(p.payment_id, /^PAY-\d{8}-\d{4}$/);
  assert.equal(countPaymentsLike('PAY-20260809-'), 1);
});

test('latest pending payment per user', () => {
  insertPayment({
    payment_id: 'PAY-20260809-0002',
    telegram_id: 1001,
    payment_type: 'LIMIT',
    add_limit: 10,
    amount: 10000,
    status: 'WAITING_PAYMENT',
  });
  const p = getLatestPendingPayment(1001);
  assert.equal(p.payment_id, 'PAY-20260809-0002');
});

test('stats agregat', () => {
  insertAccountLog({
    telegram_id: 1001, payment_id: null, api_username: 'akun1',
    role: 'PENGGUNA', expires_at: 'x', payment_method: 'LIMIT', status: 'SUCCESS',
  });
  const s = getStats();
  assert.equal(s.totalAccounts, 1);
  assert.equal(s.totalLimitUsed, 1);
  assert.ok(s.totalUsers >= 2);
});

test.after(() => closeDatabase());
