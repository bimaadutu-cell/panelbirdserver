// ============================================================
// helpers.js — Formatting, utilitas, dan helper kirim pesan
// ============================================================
import fs from 'node:fs';
import { InputFile } from 'grammy';
import { config, roleDurationDays } from './config.js';
import { logger } from './logger.js';
import { accountResultKeyboard } from './keyboards.js';

export function nowSeconds() {
  return Math.floor(Date.now() / 1000);
}

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function escHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function maskPassword(pw) {
  const len = Math.min(String(pw ?? '').length, 12);
  return '•'.repeat(Math.max(len, 1));
}

export function toDate(value) {
  if (!value) return null;
  if (value instanceof Date) return value;
  if (typeof value === 'number') return new Date(value < 1e12 ? value * 1000 : value);
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function formatDate(value) {
  const d = toDate(value);
  if (!d) return '-';
  return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
}

export function formatDateTime(value) {
  const d = toDate(value);
  if (!d) return '-';
  return d.toLocaleString('id-ID', {
    day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

export function formatMoney(amount) {
  const n = Number(amount) || 0;
  if (config.currency === 'IDR') return `Rp${n.toLocaleString('id-ID')}`;
  return `${n.toLocaleString('id-ID')} ${config.currency}`;
}

export function userMention(user) {
  if (!user) return 'User';
  return user.username ? `@${user.username}` : (user.first_name || `User ${user.telegram_id}`);
}

export function computeExpiry(role) {
  const d = new Date();
  d.setDate(d.getDate() + roleDurationDays(role));
  return d;
}

// ------------------------------------------------------------
// Kirim pesan dengan thumbnail (tidak crash jika file hilang)
// ------------------------------------------------------------
export async function sendWithThumbnail(ctx, caption, keyboard) {
  const thumb = config.thumbnailPath;
  if (fs.existsSync(thumb)) {
    try {
      await ctx.replyWithPhoto(new InputFile(thumb), {
        caption,
        parse_mode: 'HTML',
        reply_markup: keyboard,
      });
      return;
    } catch (err) {
      logger.warn('ui', `thumbnail failed, fallback to text: ${err.description || err.message}`);
    }
  }
  await ctx.reply(caption, { parse_mode: 'HTML', reply_markup: keyboard });
}

/** Kirim gambar QR pembayaran (configurable). */
export async function sendQr(ctx, caption, keyboard) {
  const qr = config.qrImagePath;
  if (fs.existsSync(qr)) {
    await ctx.replyWithPhoto(new InputFile(qr), {
      caption,
      parse_mode: 'HTML',
      reply_markup: keyboard,
    });
    return;
  }
  await ctx.reply('❌ QR pembayaran belum dikonfigurasi.\nHubungi administrator.', {
    reply_markup: keyboard,
  });
}

// ------------------------------------------------------------
// Hasil akun premium (dipakai alur LIMIT & QR)
// ------------------------------------------------------------
export function accountResultCaption(account, { remainingLimit, paymentId } = {}) {
  const username = escHtml(account.username || '-');
  const role = escHtml(account.role || '-');
  const expires = account.expiresAt || formatDate(computeExpiry(account.role));
  const limitLine = remainingLimit !== undefined && remainingLimit !== null
    ? `💎 Limit tersisa:\n<code>${remainingLimit}</code>`
    : '';
  const paymentLine = paymentId ? `🧾 Payment:\n<code>${paymentId}</code>` : '';
  return `╭━━━━━━━━━━━━━━━━━━━━━━╮
       ✨ ACCOUNT READY
╰━━━━━━━━━━━━━━━━━━━━━━╯

🎉 Selamat!

Akun BIMXZBUGXZ kamu berhasil
dibuat dan siap digunakan.

┌──────────────────────┐
│ 👤 USERNAME
│ └─ ${username}
│
│ 🔐 PASSWORD
│ └─ <code>••••••••••••</code>
│
│ 👑 ROLE
│ └─ ${role}
│
│ ⏳ DURATION
│ └─ ${roleDurationDays(account.role)} HARI
│
│ 📅 EXPIRES
│ └─ ${escHtml(expires)}
│
│ ⚡ STATUS
│ └─ <code>ACTIVE</code>
└──────────────────────┘

${paymentLine ? paymentLine + '\n' : ''}${limitLine ? limitLine + '\n' : ''}━━━━━━━━━━━━━━━━━━━━━━

🚀 BIMXZBUGXZ ACCOUNT SYSTEM`;
}

export async function sendAccountResult(ctx, account, opts = {}) {
  await sendWithThumbnail(ctx, accountResultCaption(account, opts), accountResultKeyboard());
}
