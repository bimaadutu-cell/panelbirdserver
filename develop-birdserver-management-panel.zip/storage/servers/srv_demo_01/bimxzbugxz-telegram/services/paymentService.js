// ============================================================
// services/paymentService.js — Alur pembayaran QR
// ACCOUNT: owner KONFIRMASI -> API -> kirim akun ke pembeli
// LIMIT  : owner KONFIRMASI -> limit bertambah
// Anti double approve: lock in-memory + guard status + transaksi.
// ============================================================
import * as db from '../database.js';
import { config, accountPrice, roleDurationDays } from '../config.js';
import { encryptPassword, decryptPassword } from '../crypto.js';
import { createBimxzAccount } from '../api.js';
import { logger } from '../logger.js';
import { formatDate, nowSeconds, computeExpiry } from '../helpers.js';

// Lock in-memory per payment (anti double approve / double click)
const paymentLocks = new Set();

function acquireLock(paymentId) {
  if (paymentLocks.has(paymentId)) return false;
  paymentLocks.add(paymentId);
  return true;
}

function releaseLock(paymentId) {
  paymentLocks.delete(paymentId);
}

// ------------------------------------------------------------
// Payment ID: PAY-YYYYMMDD-XXXX
// ------------------------------------------------------------
export function generatePaymentId() {
  const now = new Date();
  const ymd = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
  const prefix = `PAY-${ymd}-`;
  const count = db.countPaymentsLike(prefix);
  const seq = String(count + 1).padStart(4, '0');
  return `${prefix}${seq}`;
}

/** Buat payment ACCOUNT (password dienkripsi sebelum disimpan). */
export function createAccountPayment({ telegramId, username, password, role }) {
  const paymentId = generatePaymentId();
  const duration = roleDurationDays(role);
  const amount = accountPrice(role);
  const encrypted = encryptPassword(password);

  db.insertPayment({
    payment_id: paymentId,
    telegram_id: Number(telegramId),
    payment_type: 'ACCOUNT',
    account_username: username,
    encrypted_password: encrypted,
    role,
    duration,
    amount,
    status: 'WAITING_PAYMENT',
  });
  logger.info('payment', `PAYMENT ${paymentId} created (ACCOUNT)`);
  return db.getPaymentByPaymentId(paymentId);
}

/** Buat payment LIMIT. */
export function createLimitPayment({ telegramId }) {
  const paymentId = generatePaymentId();
  db.insertPayment({
    payment_id: paymentId,
    telegram_id: Number(telegramId),
    payment_type: 'LIMIT',
    add_limit: config.paymentAddLimit,
    amount: config.limitPrice,
    status: 'WAITING_PAYMENT',
  });
  logger.info('payment', `PAYMENT ${paymentId} created (LIMIT)`);
  return db.getPaymentByPaymentId(paymentId);
}

export function getPendingPayment(telegramId) {
  return db.getLatestPendingPayment(Number(telegramId));
}

export function getPayment(paymentId) {
  return db.getPaymentByPaymentId(paymentId);
}

/** Batalkan payment: WAITING_PAYMENT -> EXPIRED + hapus password. */
export function cancelPayment(paymentId) {
  const payment = db.getPaymentByPaymentId(paymentId);
  if (!payment) return { ok: false, error: 'NOT_FOUND' };
  if (payment.status !== 'WAITING_PAYMENT') {
    return { ok: false, error: 'INVALID_STATUS', status: payment.status };
  }
  const tx = db.getDb().transaction(() => {
    db.updatePaymentStatus(paymentId, 'EXPIRED');
    db.setPaymentEncryptedPasswordNull(paymentId);
  });
  tx();
  logger.info('payment', `PAYMENT ${paymentId} expired by cancel`);
  return { ok: true, payment };
}

/** User mengirim bukti pembayaran. Tidak auto-approve. */
export function submitProof({ telegramId, fileId, fileType = 'photo' }) {
  const payment = db.getLatestPendingPayment(Number(telegramId));
  if (!payment) return { ok: false, error: 'NO_PENDING_PAYMENT' };
  if (payment.status !== 'WAITING_PAYMENT') {
    return { ok: false, error: 'INVALID_STATUS', status: payment.status };
  }
  db.updatePaymentProof(payment.payment_id, { proofFileId: fileId, proofType: fileType });
  logger.info('payment', `PAYMENT ${payment.payment_id} proof submitted`);
  return { ok: true, payment: db.getPaymentByPaymentId(payment.payment_id) };
}

// ------------------------------------------------------------
// Internal: finalisasi sukses akun (dipakai confirm & retry)
// ------------------------------------------------------------
function finalizeAccountSuccess({ paymentId, reviewerId, payment, result }) {
  const expiresAt = result.data.expiresAt ? new Date(result.data.expiresAt) : computeExpiry(payment.role);
  const tx = db.getDb().transaction(() => {
    db.setPaymentSuccess(paymentId, reviewerId);
    db.setPaymentEncryptedPasswordNull(paymentId); // hapus password terenkripsi
    db.incrementTotalCreated(payment.telegram_id); // konsisten dengan alur LIMIT
    db.insertAccountLog({
      telegram_id: payment.telegram_id,
      payment_id: paymentId,
      api_username: result.data.username || payment.account_username,
      role: result.data.role || payment.role,
      expires_at: formatDate(expiresAt),
      payment_method: 'QR',
      status: 'SUCCESS',
    });
  });
  tx();
  return { ...result.data, expiresAt: formatDate(expiresAt) };
}

/**
 * Owner/developer mengkonfirmasi payment.
 * - ACCOUNT: status PROOF_SUBMITTED -> API_PROCESSING -> call API -> SUCCESS
 * - LIMIT  : status PROOF_SUBMITTED -> SUCCESS + limit bertambah
 */
export async function confirmPayment(paymentId, reviewerId, { apiFn = createBimxzAccount } = {}) {
  if (!acquireLock(paymentId)) {
    logger.warn('payment', `PAYMENT ${paymentId} locked, double-click blocked`);
    return { ok: false, error: 'LOCKED' };
  }
  try {
    const payment = db.getPaymentByPaymentId(paymentId);
    if (!payment) return { ok: false, error: 'NOT_FOUND' };
    if (payment.status !== 'PROOF_SUBMITTED') {
      return { ok: false, error: 'INVALID_STATUS', status: payment.status };
    }

    // --- TYPE LIMIT ---
    if (payment.payment_type === 'LIMIT') {
      const tx = db.getDb().transaction(() => {
        db.addUserLimit(payment.telegram_id, payment.add_limit);
        db.updatePaymentStatus(paymentId, 'SUCCESS', reviewerId);
        db.insertAdminLog({ adminId: reviewerId, action: 'CONFIRM_LIMIT', detail: paymentId });
      });
      tx();
      const user = db.getUserByTelegramId(payment.telegram_id);
      logger.info('payment', `PAYMENT ${paymentId} confirmed (LIMIT)`);
      return { ok: true, type: 'LIMIT', payment, user };
    }

    // --- TYPE ACCOUNT ---
    db.updatePaymentStatus(paymentId, 'API_PROCESSING', reviewerId);

    let password;
    try {
      password = decryptPassword(payment.encrypted_password);
    } catch (err) {
      db.updatePaymentStatus(paymentId, 'API_FAILED', reviewerId);
      db.incrementApiAttempts(paymentId, 'DECRYPT_FAILED');
      logger.error('payment', `PAYMENT ${paymentId} decrypt failed`);
      return { ok: false, error: 'DECRYPT_FAILED', payment };
    }

    const result = await apiFn({
      username: payment.account_username,
      password,
      role: payment.role,
    });
    password = null; // jangan simpan di memory lebih lama dari perlu

    if (result.ok) {
      const account = finalizeAccountSuccess({ paymentId, reviewerId, payment, result });
      logger.info('payment', `PAYMENT ${paymentId} confirmed (ACCOUNT) success`);
      return { ok: true, type: 'ACCOUNT', payment, account };
    }

    db.updatePaymentStatus(paymentId, 'API_FAILED', reviewerId);
    db.incrementApiAttempts(paymentId, result.error?.code || 'UNKNOWN');
    logger.warn('payment', `PAYMENT ${paymentId} API failed: ${result.error?.code}`);
    return { ok: false, error: 'API_FAILED', apiResult: result, payment };
  } finally {
    releaseLock(paymentId);
  }
}

/** Retry pembuatan akun setelah API_FAILED. */
export async function retryPayment(paymentId, reviewerId, { apiFn = createBimxzAccount } = {}) {
  if (!acquireLock(paymentId)) return { ok: false, error: 'LOCKED' };
  try {
    const payment = db.getPaymentByPaymentId(paymentId);
    if (!payment) return { ok: false, error: 'NOT_FOUND' };
    if (payment.status === 'SUCCESS') return { ok: false, error: 'ALREADY_SUCCESS' };
    if (payment.payment_type !== 'ACCOUNT') return { ok: false, error: 'WRONG_TYPE' };
    if (payment.status !== 'API_FAILED' && payment.status !== 'API_PROCESSING') {
      return { ok: false, error: 'INVALID_STATUS', status: payment.status };
    }

    db.updatePaymentStatus(paymentId, 'API_PROCESSING', reviewerId);

    let password;
    try {
      password = decryptPassword(payment.encrypted_password);
    } catch {
      db.incrementApiAttempts(paymentId, 'DECRYPT_FAILED');
      return { ok: false, error: 'DECRYPT_FAILED', payment };
    }

    const result = await apiFn({
      username: payment.account_username,
      password,
      role: payment.role,
    });
    password = null;

    if (result.ok) {
      const account = finalizeAccountSuccess({ paymentId, reviewerId, payment, result });
      logger.info('payment', `PAYMENT ${paymentId} retry success`);
      return { ok: true, type: 'ACCOUNT', payment, account };
    }

    db.updatePaymentStatus(paymentId, 'API_FAILED', reviewerId);
    db.incrementApiAttempts(paymentId, result.error?.code || 'UNKNOWN');
    return { ok: false, error: 'API_FAILED', apiResult: result, payment };
  } finally {
    releaseLock(paymentId);
  }
}

/** Tolak payment: REJECTED + hapus password terenkripsi. */
export function rejectPayment(paymentId, reviewerId) {
  if (!acquireLock(paymentId)) return { ok: false, error: 'LOCKED' };
  try {
    const payment = db.getPaymentByPaymentId(paymentId);
    if (!payment) return { ok: false, error: 'NOT_FOUND' };
    if (payment.status !== 'PROOF_SUBMITTED' && payment.status !== 'WAITING_PAYMENT') {
      return { ok: false, error: 'INVALID_STATUS', status: payment.status };
    }
    const tx = db.getDb().transaction(() => {
      db.updatePaymentStatus(paymentId, 'REJECTED', reviewerId);
      db.setPaymentEncryptedPasswordNull(paymentId);
      db.insertAdminLog({ adminId: reviewerId, action: 'REJECT_PAYMENT', detail: paymentId });
    });
    tx();
    logger.info('payment', `PAYMENT ${paymentId} rejected`);
    return { ok: true, payment };
  } finally {
    releaseLock(paymentId);
  }
}

/** Expire semua payment WAITING_PAYMENT yang melewati timeout. */
export function expireOldPayments() {
  const cutoff = nowSeconds() - config.pendingPaymentTimeout;
  const candidates = db.getExpiredCandidates(cutoff);
  const expired = [];
  for (const p of candidates) {
    const tx = db.getDb().transaction(() => {
      db.updatePaymentStatus(p.payment_id, 'EXPIRED');
      db.setPaymentEncryptedPasswordNull(p.payment_id);
    });
    tx();
    expired.push(p);
    logger.info('payment', `PAYMENT ${p.payment_id} expired by timeout`);
  }
  return expired;
}

export function getStats() {
  return db.getStats();
}
