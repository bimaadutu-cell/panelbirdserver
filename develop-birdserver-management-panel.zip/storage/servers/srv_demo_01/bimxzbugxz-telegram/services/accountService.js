// ============================================================
// services/accountService.js — Pembuatan akun via LIMIT
// Limit HANYA berkurang setelah API BIMXZBUGXZ sukses.
// ============================================================
import * as db from '../database.js';
import { createBimxzAccount } from '../api.js';
import { logger } from '../logger.js';
import { formatDate, computeExpiry } from '../helpers.js';

/**
 * Buat akun menggunakan limit.
 * @param {number} telegramId
 * @param {{username:string,password:string,role:string}} data
 * @param {{apiFn?:Function}} opts — injeksi apiFn untuk test
 */
export async function createAccountWithLimit(telegramId, data, { apiFn = createBimxzAccount } = {}) {
  const user = db.getUserByTelegramId(Number(telegramId));
  if (!user) return { ok: false, error: 'USER_NOT_FOUND' };

  // Cek limit TERBARU dari database
  if (Number(user.limit) < 1) {
    logger.warn('create', `user ${telegramId} rejected: no limit`);
    return { ok: false, error: 'NO_LIMIT', user };
  }

  // Request API — limit BELUM berkurang
  const result = await apiFn({ username: data.username, password: data.password, role: data.role });

  if (!result.ok) {
    logger.warn('create', `user ${telegramId} api failed: ${result.error?.code}`);
    return { ok: false, error: 'API_FAILED', apiResult: result, user };
  }

  const expiresAt = result.data.expiresAt ? new Date(result.data.expiresAt) : computeExpiry(data.role);

  // API sukses → baru kurangi limit (dalam transaksi)
  const tx = db.getDb().transaction(() => {
    const decremented = db.decrementUserLimit(Number(telegramId));
    if (!decremented) throw new Error('limit tidak tersedia saat transaksi');
    db.incrementTotalCreated(Number(telegramId));
    db.insertAccountLog({
      telegram_id: Number(telegramId),
      payment_id: null,
      api_username: result.data.username || data.username,
      role: result.data.role || data.role,
      expires_at: formatDate(expiresAt),
      payment_method: 'LIMIT',
      status: 'SUCCESS',
    });
  });
  tx();

  const updated = db.getUserByTelegramId(Number(telegramId));
  logger.info('create', `account created via LIMIT for ${telegramId}`);
  return {
    ok: true,
    data: { ...result.data, expiresAt: formatDate(expiresAt) },
    remainingLimit: updated ? updated.limit : null,
    user: updated,
  };
}
