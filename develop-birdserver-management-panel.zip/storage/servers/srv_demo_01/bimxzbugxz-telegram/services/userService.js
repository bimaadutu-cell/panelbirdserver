// ============================================================
// services/userService.js — Manajemen user & limit
// ============================================================
import * as db from '../database.js';
import { logger } from '../logger.js';

export function getOrCreateUser(telegramId, profile = {}) {
  return db.getOrCreateUser(telegramId, profile);
}

export function getUser(telegramId) {
  return db.getUserByTelegramId(Number(telegramId));
}

/** Tambah limit user (dipakai pembelian LIMIT & admin). */
export function addLimit(telegramId, amount, { adminId = null } = {}) {
  const id = Number(telegramId);
  const user = db.getUserByTelegramId(id);
  if (!user) return { ok: false, error: 'USER_NOT_FOUND' };

  const tx = db.getDb().transaction(() => {
    const newLimit = db.addUserLimit(id, amount);
    if (adminId) {
      db.insertAdminLog({ adminId, action: 'ADD_LIMIT', detail: `+${amount} untuk user ${id}` });
    }
    return newLimit;
  });
  const newLimit = tx();
  logger.info('user', `limit +${amount} untuk ${id} -> ${newLimit}`);
  return { ok: true, newLimit };
}

/** Kurangi limit 1. Dipanggil HANYA setelah API sukses. */
export function decrementLimit(telegramId) {
  const ok = db.decrementUserLimit(Number(telegramId));
  if (ok) logger.info('user', `limit -1 untuk ${telegramId}`);
  return ok;
}

export function listUsers(limit = 20) {
  return db.getAllUsers(limit);
}
