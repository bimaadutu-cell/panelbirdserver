// ============================================================
// api.js — Client API BIMXZBUGXZ
// POST {BIMXZ_API_URL}/api/apikey/create-user
// ============================================================
import { config } from './config.js';
import { logger } from './logger.js';

const TIMEOUT_MS = 15000;

/** Klasifikasi error API menjadi pesan aman (tanpa bocorkan API key). */
export function classifyApiError(status, _raw) {
  if (status === 400) return { code: 'BAD_REQUEST', message: 'Data akun ditolak server (400)' };
  if (status === 401 || status === 403) return { code: 'UNAUTHORIZED', message: 'API key tidak valid (401/403)' };
  if (status === 404) return { code: 'NOT_FOUND', message: 'Endpoint API tidak ditemukan (404)' };
  if (status === 429) return { code: 'RATE_LIMIT', message: 'Terlalu banyak request (429)' };
  if (status >= 500) return { code: 'SERVER_ERROR', message: `Server BIMXZBUGXZ bermasalah (${status})` };
  return { code: 'UNKNOWN', message: `Error tidak dikenal (${status || '-'})` };
}

/** Parser fleksibel: user bisa berada di user | data | result | account | root. */
function extractUserObject(data) {
  if (!data || typeof data !== 'object') return null;
  return data.user || data.data || data.result || data.account || null;
}

/** Normalisasi response sukses agar bentuk apa pun tetap terbaca. */
export function normalizeAccountResponse(data) {
  const user = extractUserObject(data) || {};
  return {
    username: user.username || user.name || user.account || '',
    role: user.role || '',
    expiresAt: user.expiresAt || user.expires_at || user.expiry || user.expire || user.expires || null,
    autoDelete: data.autoDelete ?? user.autoDelete ?? null,
  };
}

/**
 * Buat akun BIMXZBUGXZ.
 * @returns {{ok:true, data, raw, status} | {ok:false, status, error:{code,message}, data, raw}}
 */
export async function createBimxzAccount({ username, password, role }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  const url = `${config.bimxzApiUrl}/api/apikey/create-user`;
  const startedAt = Date.now();

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'x-api-key': config.bimxzApiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password, role }),
      signal: controller.signal,
    });

    const raw = await res.text();
    let data = null;
    try { data = raw ? JSON.parse(raw) : null; } catch { data = null; }

    const elapsed = Date.now() - startedAt;

    if (res.ok && data && data.ok === true) {
      logger.info('api', `account creation success (${elapsed}ms)`);
      return { ok: true, status: res.status, data: normalizeAccountResponse(data), raw: data };
    }

    const error = classifyApiError(res.status, raw);
    logger.warn('api', `account creation failed status=${res.status} code=${error.code}`);
    return { ok: false, status: res.status, error, data, raw };
  } catch (err) {
    const aborted = err?.name === 'AbortError';
    const error = aborted
      ? { code: 'TIMEOUT', message: 'API timeout' }
      : { code: 'NETWORK_ERROR', message: 'Tidak dapat terhubung ke server BIMXZBUGXZ' };
    logger.error('api', `account creation error code=${error.code}`);
    return { ok: false, status: 0, error, data: null, raw: null };
  } finally {
    clearTimeout(timer);
  }
}

/** Cek kesehatan API (untuk menu 🔌 API STATUS). Tanpa mengirim secret. */
export async function checkApiHealth() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(`${config.bimxzApiUrl}/`, {
      method: 'GET',
      signal: controller.signal,
    });
    return { ok: true, status: res.status, url: config.bimxzApiUrl };
  } catch (err) {
    return {
      ok: false,
      status: 0,
      url: config.bimxzApiUrl,
      error: err?.name === 'AbortError' ? 'TIMEOUT' : 'UNREACHABLE',
    };
  } finally {
    clearTimeout(timer);
  }
}
