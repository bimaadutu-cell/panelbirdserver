# 🤖 BIMXZBUGXZ OFFICIAL PROJECT — Telegram Bot

Bot Telegram **production-ready** untuk pembuatan akun **BIMXZBUGXZ**.
Dibangun dengan **Node.js 20+**, **grammY**, **SQLite (better-sqlite3)** — tanpa Python.

> Bisa dijalankan di **panel Pterodactyl**, **Railway**, **Docker**, atau VPS biasa.
> Cukup zip folder ini, upload ke panel, lalu jalankan `npm install && npm start`.

---

## ✨ Fitur

- 🆕 **Create Account** — username → password → role → konfirmasi
- 💎 **Bayar Pakai LIMIT** — akun dibuat otomatis, limit berkurang **hanya jika API sukses**
- 📱 **Bayar Pakai QR** — user kirim bukti → owner **KONFIRMASI** → bot panggil API → akun dikirim ke pembeli
- 💳 **Tambah Limit** — pembelian limit via QR, dikonfirmasi owner
- 👥 Role: `PENGGUNA` (7 hari), `RESELLER` (30 hari), `OWNER` (90 hari)
- ⚙️ **Admin Panel** untuk OWNER & DEVELOPER (users, pending payment, statistik, tambah limit, log akun, cek API)
- 🔐 Password dienkripsi **AES-256-GCM**, dihapus setelah transaksi selesai
- 🛡️ Anti double-approve, anti double-click, SQLite transaction
- 🖼️ Thumbnail & QR **configurable** (ganti file tanpa ubah kode)
- ⏳ Payment otomatis kadaluarsa (30 menit)
- 🧪 Unit test bawaan (`npm test`)

---

## 📁 Struktur Project

```
bimxzbugxz-telegram/
├── package.json
├── bot.js              # Entry point
├── config.js           # Konfigurasi env
├── database.js         # SQLite (better-sqlite3)
├── api.js              # Client API BIMXZBUGXZ
├── crypto.js           # Enkripsi AES-256-GCM
├── logger.js           # Logging aman
├── keyboards.js        # Inline keyboards
├── helpers.js          # Formatting & helper kirim
├── middleware.js       # Session + auth admin
├── handlers/           # start, createAccount, limit, payment, admin, callbacks
├── services/           # accountService, paymentService, userService
├── data/               # database.sqlite (dibuat otomatis)
├── assets/
│   ├── thumbnail.jpg   # Ganti sesuai keinginan
│   └── qris.png        # Ganti dengan QR payment kamu
├── tests/              # database, payment, account
├── .env.example
├── .gitignore
├── Dockerfile
└── README.md
```

---

## 🚀 Cara Install & Jalankan

### 1. Install Node.js 20+

```bash
node -v   # pastikan >= 20
```

### 2. Clone / upload project

```bash
cd bimxzbugxz-telegram
npm install
```

### 3. Buat bot Telegram

1. Chat **@BotFather** di Telegram
2. `/newbot` → ikuti petunjuk → dapatkan **token**
3. (Opsional) `/setcommands`:
   ```
   start - Mulai bot
   help - Bantuan
   cancel - Batalkan sesi
   addlimit - [ADMIN] Tambah limit user
   ```

### 4. Isi file `.env`

```bash
cp .env.example .env
```

Lalu isi:

| Variabel | Keterangan |
|---|---|
| `TELEGRAM_BOT_TOKEN` | Token dari @BotFather |
| `BIMXZ_API_KEY` | API key BIMXZBUGXZ |
| `BIMXZ_API_URL` | `https://bimxzbugv2.up.railway.app` |
| `OWNER_ID` | Telegram ID owner (penerima bukti & konfirmasi) |
| `DEVELOPER_IDS` | Telegram ID developer, pisah koma |
| `DEFAULT_LIMIT` | Limit awal user baru (default `2`) |
| `PAYMENT_ADD_LIMIT` | Limit yang ditambahkan saat beli LIMIT (default `10`) |
| `ENCRYPTION_KEY` | **WAJIB** — kunci enkripsi password (min 16 karakter) |
| `QR_IMAGE_PATH` | Path gambar QR |
| `THUMBNAIL_PATH` | Path thumbnail |

Cara dapat Telegram ID: chat **@userinfobot**, atau lihat ID sendiri via bot.

### 5. Siapkan asset

- Letakkan thumbnail di `assets/thumbnail.jpg`
- Letakkan QR payment di `assets/qris.png`
- Bot **tetap jalan** walau file tersebut tidak ada (fallback pesan teks)

### 6. Jalankan

```bash
npm start        # production
npm run dev      # development (auto-restart)
npm test         # unit test
```

---

## 🐳 Docker

```bash
docker build -t bimxzbugxz-telegram .
docker run --env-file .env bimxzbugxz-telegram
```

## ☁️ Railway

1. Push project ke GitHub
2. Buat service baru di Railway → **Deploy from GitHub repo**
3. Tambahkan semua variabel `.env` di tab **Variables**
4. Deploy — bot langsung jalan (long polling, tanpa web server)

## 🖥️ Panel Pterodactyl

1. Zip folder `bimxzbugxz-telegram` (tanpa `node_modules`, tanpa `.env`)
2. Upload di panel → startup command: `npm install && npm start`
3. Letakkan file `.env` di folder yang sama

---

## 💳 Alur Pembayaran QR (PENTING)

```
USER isi username+password+role
        ↓
bot buat payment (password dienkripsi)
        ↓
bot kirim QR
        ↓
user bayar & kirim bukti transfer
        ↓
owner terima FOTO BUKTI + DETAIL (payment id, username akun, role, masa aktif, harga, waktu)
        ↓
owner tekan ✅ KONFIRMASI
        ↓
bot panggil POST /api/apikey/create-user
        ↓
API sukses → akun dikirim ke PEMBELI
```

Akun **tidak pernah** dibuat sebelum owner menekan KONFIRMASI.

---

## 🔐 Keamanan

- Token & API key hanya di `.env` — tidak pernah di-hardcode
- Password **tidak pernah** di-log, tidak disimpan plaintext, dihapus setelah transaksi
- Limit **tidak berkurang** jika API gagal
- Callback owner divalidasi via `OWNER_ID` / `DEVELOPER_IDS`
- Satu payment hanya menghasilkan **satu** akun (lock + transaksi + guard status)

---

## 🧪 Testing

```bash
npm test
```

Test mencakup: limit default, create account, API sukses/gagal, limit tidak berkurang saat API gagal, payment ACCOUNT/LIMIT, proof submission, approve/reject, double approve, expired payment, enkripsi & penghapusan password, retry, validasi role, validasi admin, **dan router tombol inline** (memastikan setiap `callback_data` tombol ter-dispatch ke handler yang benar).

> 💡 **Catatan penting:** handler tombol inline didaftarkan dengan
> `bot.on('callback_query:data', router)` — jangan pakai `bot.callbackQuery('data', ...)`,
> karena string `'data'` dianggap sebagai *exact-match trigger* sehingga semua tombol mati.
> Bug ini sudah diperbaiki dan dilindungi oleh test `router.test.js`.
