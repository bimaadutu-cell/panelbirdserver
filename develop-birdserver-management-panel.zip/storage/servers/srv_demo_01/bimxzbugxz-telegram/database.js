// ============================================================
// database.js — SQLite (better-sqlite3) + semua data access
// Semua operasi sinkron (better-sqlite3) sehingga transaksi
// aman dan anti double-process.
// ============================================================
import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';
import { logger } from './logger.js';

let db = null;

export function initDatabase(dbPath = config.databasePath) {
  if (db) {
    try { db.close(); } catch { /* ignore */ }
    db = null;
  }
  if (dbPath !== ':memory:') {
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  }
  db = new Database(dbPath);
  if (dbPath !== ':memory:') {
    db.pragma('journal_mode = WAL');
  }
  db.pragma('busy_timeout = 5000');
  migrate();
  logger.info('db', `database ready (${dbPath})`);
  return db;
}

export function getDb() {
  if (!db) throw new Error('Database belum diinisialisasi. Panggil initDatabase() dulu.');
  return db;
}

export function closeDatabase() {
  if (db) {
    try { db.close(); } catch { /* ignore */ }
    db = null;
  }
}

function migrate() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      telegram_id INTEGER NOT NULL UNIQUE,
      username TEXT NOT NULL DEFAULT '',
      first_name TEXT NOT NULL DEFAULT '',
      "limit" INTEGER NOT NULL DEFAULT 0,
      total_created INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      payment_id TEXT NOT NULL UNIQUE,
      telegram_id INTEGER NOT NULL,
      payment_type TEXT NOT NULL,               -- ACCOUNT | LIMIT
      account_username TEXT,
      encrypted_password TEXT,
      role TEXT,
      duration INTEGER,
      amount INTEGER,
      add_limit INTEGER,
      proof_file_id TEXT,
      proof_type TEXT,
      status TEXT NOT NULL DEFAULT 'WAITING_PAYMENT',
      created_at INTEGER NOT NULL,
      reviewed_at INTEGER,
      reviewed_by INTEGER,
      api_attempts INTEGER NOT NULL DEFAULT 0,
      last_error TEXT,
      owner_chat_id INTEGER,
      owner_message_id INTEGER
    );

    CREATE TABLE IF NOT EXISTS account_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      telegram_id INTEGER NOT NULL,
      payment_id TEXT,
      api_username TEXT NOT NULL,
      role TEXT NOT NULL,
      expires_at TEXT,
      payment_method TEXT NOT NULL,             -- LIMIT | QR
      status TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admin_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      admin_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      detail TEXT,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
    CREATE INDEX IF NOT EXISTS idx_payments_telegram ON payments(telegram_id, status);
    CREATE INDEX IF NOT EXISTS idx_logs_telegram ON account_logs(telegram_id);
  `);
}

function now() {
  return Math.floor(Date.now() / 1000);
}

// ------------------------------------------------------------
// USERS
// ------------------------------------------------------------
export function getOrCreateUser(telegramId, profile = {}) {
  const id = Number(telegramId);
  const existing = getUserByTelegramId(id);
  if (existing) {
    const username = profile.username ?? existing.username;
    const firstName = profile.first_name ?? existing.first_name;
    if (username !== existing.username || firstName !== existing.first_name) {
      updateUserProfile(id, { username, first_name: firstName });
      return getUserByTelegramId(id);
    }
    return existing;
  }
  const insert = getDb().prepare(`
    INSERT INTO users (telegram_id, username, first_name, "limit", total_created, created_at, updated_at)
    VALUES (?, ?, ?, ?, 0, ?, ?)
  `);
  insert.run(id, profile.username ?? '', profile.first_name ?? '', config.defaultLimit, now(), now());
  logger.info('user', `new user ${id} created with limit ${config.defaultLimit}`);
  return getUserByTelegramId(id);
}

export function getUserByTelegramId(telegramId) {
  return getDb().prepare('SELECT * FROM users WHERE telegram_id = ?').get(Number(telegramId)) ?? null;
}

export function updateUserProfile(telegramId, { username, first_name }) {
  getDb().prepare(`
    UPDATE users SET username = ?, first_name = ?, updated_at = ? WHERE telegram_id = ?
  `).run(username ?? '', first_name ?? '', now(), Number(telegramId));
}

/** Tambah limit, return limit terbaru. */
export function addUserLimit(telegramId, amount) {
  const id = Number(telegramId);
  getDb().prepare(`
    UPDATE users SET "limit" = "limit" + ?, updated_at = ? WHERE telegram_id = ?
  `).run(Number(amount), now(), id);
  const user = getUserByTelegramId(id);
  return user ? user.limit : null;
}

/** Kurangi limit 1 jika tersedia. Return true jika berhasil. */
export function decrementUserLimit(telegramId) {
  const info = getDb().prepare(`
    UPDATE users SET "limit" = "limit" - 1, updated_at = ? WHERE telegram_id = ? AND "limit" >= 1
  `).run(now(), Number(telegramId));
  return info.changes > 0;
}

export function incrementTotalCreated(telegramId) {
  getDb().prepare(`
    UPDATE users SET total_created = total_created + 1, updated_at = ? WHERE telegram_id = ?
  `).run(now(), Number(telegramId));
}

export function getAllUsers(limit = 20) {
  return getDb().prepare('SELECT * FROM users ORDER BY id DESC LIMIT ?').all(limit);
}

export function countUsers() {
  return getDb().prepare('SELECT COUNT(*) AS c FROM users').get().c;
}

// ------------------------------------------------------------
// PAYMENTS
// ------------------------------------------------------------
export function insertPayment(row) {
  getDb().prepare(`
    INSERT INTO payments (
      payment_id, telegram_id, payment_type, account_username, encrypted_password,
      role, duration, amount, add_limit, status, created_at
    ) VALUES (@payment_id, @telegram_id, @payment_type, @account_username, @encrypted_password,
      @role, @duration, @amount, @add_limit, @status, @created_at)
  `).run({
    payment_id: row.payment_id,
    telegram_id: Number(row.telegram_id),
    payment_type: row.payment_type,
    account_username: row.account_username ?? null,
    encrypted_password: row.encrypted_password ?? null,
    role: row.role ?? null,
    duration: row.duration ?? null,
    amount: row.amount ?? null,
    add_limit: row.add_limit ?? null,
    status: row.status ?? 'WAITING_PAYMENT',
    created_at: row.created_at ?? now(),
  });
}

export function getPaymentByPaymentId(paymentId) {
  return getDb().prepare('SELECT * FROM payments WHERE payment_id = ?').get(paymentId) ?? null;
}

export function getLatestPendingPayment(telegramId) {
  return getDb().prepare(`
    SELECT * FROM payments
    WHERE telegram_id = ? AND status = 'WAITING_PAYMENT'
    ORDER BY id DESC LIMIT 1
  `).get(Number(telegramId)) ?? null;
}

export function getPendingPayments(limit = 25) {
  return getDb().prepare(`
    SELECT * FROM payments
    WHERE status IN ('WAITING_PAYMENT','PROOF_SUBMITTED','API_PROCESSING','API_FAILED')
    ORDER BY id DESC LIMIT ?
  `).all(limit);
}

export function countPaymentsLike(prefix) {
  return getDb().prepare('SELECT COUNT(*) AS c FROM payments WHERE payment_id LIKE ?')
    .get(`${prefix}%`).c;
}

export function updatePaymentStatus(paymentId, status, reviewerId = null) {
  getDb().prepare(`
    UPDATE payments SET status = ?, reviewed_by = COALESCE(?, reviewed_by),
      reviewed_at = CASE WHEN ? = 'SUCCESS' OR ? = 'REJECTED' THEN ? ELSE reviewed_at END
    WHERE payment_id = ?
  `).run(status, reviewerId, status, status, now(), paymentId);
}

export function updatePaymentProof(paymentId, { proofFileId, proofType }) {
  getDb().prepare(`
    UPDATE payments SET proof_file_id = ?, proof_type = ?, status = 'PROOF_SUBMITTED' WHERE payment_id = ?
  `).run(proofFileId, proofType, paymentId);
}

export function setPaymentEncryptedPasswordNull(paymentId) {
  getDb().prepare('UPDATE payments SET encrypted_password = NULL WHERE payment_id = ?').run(paymentId);
}

export function incrementApiAttempts(paymentId, errorCode) {
  getDb().prepare(`
    UPDATE payments SET api_attempts = api_attempts + 1, last_error = ? WHERE payment_id = ?
  `).run(errorCode ?? null, paymentId);
}

export function setPaymentSuccess(paymentId, reviewerId) {
  updatePaymentStatus(paymentId, 'SUCCESS', reviewerId);
}

export function setPaymentOwnerMessage(paymentId, chatId, messageId) {
  getDb().prepare(`
    UPDATE payments SET owner_chat_id = ?, owner_message_id = ? WHERE payment_id = ?
  `).run(Number(chatId), Number(messageId), paymentId);
}

export function getExpiredCandidates(cutoff) {
  return getDb().prepare(`
    SELECT * FROM payments WHERE status = 'WAITING_PAYMENT' AND created_at < ?
  `).all(cutoff);
}

// ------------------------------------------------------------
// ACCOUNT LOGS
// ------------------------------------------------------------
export function insertAccountLog(row) {
  getDb().prepare(`
    INSERT INTO account_logs (telegram_id, payment_id, api_username, role, expires_at, payment_method, status, created_at)
    VALUES (@telegram_id, @payment_id, @api_username, @role, @expires_at, @payment_method, @status, @created_at)
  `).run({
    telegram_id: Number(row.telegram_id),
    payment_id: row.payment_id ?? null,
    api_username: row.api_username,
    role: row.role,
    expires_at: row.expires_at ?? null,
    payment_method: row.payment_method,
    status: row.status ?? 'SUCCESS',
    created_at: row.created_at ?? now(),
  });
}

export function getRecentAccountLogs(limit = 25) {
  return getDb().prepare('SELECT * FROM account_logs ORDER BY id DESC LIMIT ?').all(limit);
}

// ------------------------------------------------------------
// ADMIN LOGS
// ------------------------------------------------------------
export function insertAdminLog({ adminId, action, detail }) {
  getDb().prepare(`
    INSERT INTO admin_logs (admin_id, action, detail, created_at) VALUES (?, ?, ?, ?)
  `).run(Number(adminId), action, detail ?? null, now());
}

// ------------------------------------------------------------
// STATS
// ------------------------------------------------------------
export function getStats() {
  const count = (sql) => getDb().prepare(sql).get().c;
  return {
    totalUsers: count('SELECT COUNT(*) AS c FROM users'),
    pendingPayments: count(`SELECT COUNT(*) AS c FROM payments WHERE status IN ('WAITING_PAYMENT','PROOF_SUBMITTED','API_PROCESSING','API_FAILED')`),
    successPayments: count(`SELECT COUNT(*) AS c FROM payments WHERE status = 'SUCCESS'`),
    rejectedPayments: count(`SELECT COUNT(*) AS c FROM payments WHERE status = 'REJECTED'`),
    expiredPayments: count(`SELECT COUNT(*) AS c FROM payments WHERE status = 'EXPIRED'`),
    totalAccounts: count('SELECT COUNT(*) AS c FROM account_logs'),
    totalLimitUsed: count(`SELECT COUNT(*) AS c FROM account_logs WHERE payment_method = 'LIMIT'`),
    totalLimitPurchased: getDb().prepare(`
      SELECT COALESCE(SUM(add_limit), 0) AS s FROM payments WHERE payment_type = 'LIMIT' AND status = 'SUCCESS'
    `).get().s,
  };
}
