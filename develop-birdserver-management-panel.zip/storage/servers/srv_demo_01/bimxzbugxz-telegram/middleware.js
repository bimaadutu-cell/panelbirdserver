// ============================================================
// middleware.js — Session sementara + otentikasi admin
// ============================================================
import { config, isAdminId } from './config.js';
import { logger } from './logger.js';

// --- Session sementara (Map + timeout + cleanup) ---
const sessions = new Map();
const SESSION_TTL_MS = 30 * 60 * 1000; // 30 menit

export function getSession(telegramId) {
  const key = Number(telegramId);
  const s = sessions.get(key);
  if (!s) return null;
  if (Date.now() - s.updatedAt > SESSION_TTL_MS) {
    sessions.delete(key);
    logger.info('session', `session ${key} expired`);
    return null;
  }
  s.updatedAt = Date.now();
  return s;
}

export function setSession(telegramId, data) {
  const key = Number(telegramId);
  sessions.set(key, { ...data, createdAt: Date.now(), updatedAt: Date.now() });
}

export function clearSession(telegramId) {
  sessions.delete(Number(telegramId));
}

export function cleanupSessions() {
  const now = Date.now();
  let removed = 0;
  for (const [key, s] of sessions) {
    if (now - s.updatedAt > SESSION_TTL_MS) {
      sessions.delete(key);
      removed += 1;
    }
  }
  if (removed > 0) logger.info('session', `cleaned ${removed} expired sessions`);
}

export function sessionCount() {
  return sessions.size;
}

// --- Otentikasi admin ---
export function adminGuard(ctx) {
  const id = ctx.from?.id;
  if (!id || !isAdminId(id)) {
    ctx.answerCallbackQuery({ text: '❌ Kamu tidak memiliki akses.' }).catch(() => {});
    logger.warn('admin', `blocked unauthorized callback from ${id ?? 'anon'}`);
    return false;
  }
  return true;
}

export function ownerGuard(ctx) {
  const id = ctx.from?.id;
  if (!id || Number(id) !== config.ownerId) {
    ctx.answerCallbackQuery({ text: '❌ Kamu tidak memiliki akses.' }).catch(() => {});
    logger.warn('admin', `blocked non-owner callback from ${id ?? 'anon'}`);
    return false;
  }
  return true;
}
