// ============================================================
// logger.js — Logging ringan & aman (tanpa dependensi eksternal)
// JANGAN PERNAH mengirim password / token / api key ke logger.
// ============================================================
import { config } from './config.js';

const LEVELS = { debug: 0, info: 1, warn: 2, error: 3 };

function currentLevel() {
  return LEVELS[config.logLevel] ?? LEVELS.info;
}

function redact(value) {
  if (typeof value !== 'string') return value;
  return value
    .replace(/(TELEGRAM_BOT_TOKEN\s*=\s*)\S+/gi, '$1[REDACTED]')
    .replace(/(BIMXZ_API_KEY\s*=\s*)\S+/gi, '$1[REDACTED]')
    .replace(/(ENCRYPTION_KEY\s*=\s*)\S+/gi, '$1[REDACTED]')
    .replace(/(x-api-key:\s*)\S+/gi, '$1[REDACTED]')
    .replace(/(Authorization:\s*)\S+/gi, '$1[REDACTED]');
}

function write(level, tag, message) {
  if (LEVELS[level] < currentLevel()) return;
  const line = `[${new Date().toISOString()}] [${level.toUpperCase()}] [${tag}] ${redact(String(message ?? ''))}`;
  if (level === 'error') console.error(line);
  else console.log(line);
}

export const logger = {
  debug: (tag, message) => write('debug', tag, message),
  info: (tag, message) => write('info', tag, message),
  warn: (tag, message) => write('warn', tag, message),
  error: (tag, message) => write('error', tag, message),
};
