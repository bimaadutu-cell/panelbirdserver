// ============================================================
// crypto.js — Enkripsi password AES-256-GCM (Node.js crypto)
// Password hanya disimpan terenkripsi di database (payload QR),
// didekripsi hanya di memory saat owner mengkonfirmasi.
// ============================================================
import crypto from 'node:crypto';
import { config } from './config.js';
import { logger } from './logger.js';

function getKey() {
  const secret = config.encryptionKey;
  if (!secret) {
    throw new Error('ENCRYPTION_KEY belum dikonfigurasi di .env');
  }
  // Derive 32-byte key dari secret (sha256)
  return crypto.createHash('sha256').update(secret).digest();
}

/**
 * Enkripsi password.
 * Format payload: <iv hex>:<authTag hex>:<ciphertext hex>
 */
export function encryptPassword(plain) {
  const key = getKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted.toString('hex')}`;
}

/** Dekripsi password dari payload hasil encryptPassword(). */
export function decryptPassword(payload) {
  if (!payload || typeof payload !== 'string') {
    throw new Error('Payload terenkripsi tidak valid');
  }
  const parts = payload.split(':');
  if (parts.length !== 3) {
    throw new Error('Payload terenkripsi tidak valid');
  }
  const [ivHex, tagHex, dataHex] = parts;
  const key = getKey();
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(dataHex, 'hex')),
    decipher.final(),
  ]);
  return decrypted.toString('utf8');
}

/** Uji cepat enkripsi/dekripsi (untuk startup check & tests). */
export function selfTest() {
  const sample = 'test-password-123';
  const encrypted = encryptPassword(sample);
  const decrypted = decryptPassword(encrypted);
  if (decrypted !== sample) {
    throw new Error('Crypto self-test gagal');
  }
  logger.debug('crypto', 'self-test ok');
  return true;
}
