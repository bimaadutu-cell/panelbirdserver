// ============================================================
// handlers/callbacks.js — Router utama semua callback data
// ============================================================
import fs from 'node:fs';
import { InlineKeyboard, InputFile } from 'grammy';
import { config } from '../config.js';
import { adminGuard, setSession } from '../middleware.js';
import { getPayment, confirmPayment, retryPayment, rejectPayment } from '../services/paymentService.js';
import { getUserByTelegramId } from '../database.js';
import { accountResultCaption, escHtml, userMention } from '../helpers.js';
import { accountResultKeyboard, ownerRetryKeyboard } from '../keyboards.js';
import { logger } from '../logger.js';
import { sendMainMenu } from './start.js';
import {
  startCreate, cancelCreate, chooseRole, editData, payWithLimit, payWithQr,
} from './createAccount.js';
import { viewLimit } from './limit.js';
import { startLimitPurchase, proofHintCallback, paymentCancelCallback } from './payment.js';
import {
  adminMenu, adminUsers, adminPending, adminStats, adminLog, adminApiStatus,
} from './admin.js';
import { helpCommand } from './start.js';

export async function callbacksRouter(ctx) {
  const data = ctx.callbackQuery?.data || '';
  const [ns, ...rest] = data.split(':');

  try {
    switch (ns) {
      case 'create': return createCallback(ctx, rest, data);
      case 'limit': return limitCallback(ctx, rest, data);
      case 'payment': return paymentCallback(ctx, rest, data);
      case 'pay': return payCallback(ctx, rest, data);
      case 'admin': return adminCallback(ctx, rest, data);
      case 'help': return helpCallback(ctx);
      case 'menu': return menuCallback(ctx);
      default: {
        await ctx.reply('❌ Perintah tidak dikenal.');
      }
    }
  } catch (err) {
    logger.error('callback', `error ${data}: ${err.message}`);
    await ctx.reply('⚠️ Terjadi kesalahan sementara.\nSilakan coba kembali.').catch(() => {});
  } finally {
    // Selalu jawab callback query (hapus loading di tombol).
    // Jika handler sudah menjawab dengan toast, panggilan ini diabaikan Telegram.
    await ctx.answerCallbackQuery().catch(() => {});
  }
}

// ------------------------------------------------------------
async function createCallback(ctx, rest, _data) {
  const action = rest[0];
  switch (action) {
    case 'start': return startCreate(ctx);
    case 'cancel': return cancelCreate(ctx);
    case 'edit': return editData(ctx);
    case 'role': return chooseRole(ctx, rest[1]);
    case 'pay':
      if (rest[1] === 'limit') return payWithLimit(ctx);
      if (rest[1] === 'qr') return payWithQr(ctx);
      return ctx.reply('❌ Metode pembayaran tidak dikenal.');
    default:
      return ctx.reply('❌ Aksi tidak dikenal.');
  }
}

async function limitCallback(ctx, rest, _data) {
  if (rest[0] === 'view') return viewLimit(ctx);
  return ctx.reply('❌ Aksi tidak dikenal.');
}

async function paymentCallback(ctx, rest, _data) {
  if (rest[0] === 'limit') return startLimitPurchase(ctx);
  return ctx.reply('❌ Aksi tidak dikenal.');
}

// ------------------------------------------------------------
// Callback payment: proof / cancel / confirm / reject / retry / close
// ------------------------------------------------------------
async function payCallback(ctx, rest, _data) {
  const action = rest[0];
  const paymentId = rest.slice(1).join(':');

  if (action === 'proof') {
    return proofHintCallback(ctx, paymentId);
  }
  if (action === 'cancel') {
    return paymentCancelCallback(ctx, paymentId);
  }

  // Semua aksi owner (confirm/reject/retry/close) butuh otorisasi
  if (!adminGuard(ctx)) return;
  const from = ctx.from;

  if (action === 'confirm') {
    return ownerConfirm(ctx, from.id, paymentId);
  }
  if (action === 'reject') {
    return ownerReject(ctx, from.id, paymentId);
  }
  if (action === 'retry') {
    return ownerRetry(ctx, from.id, paymentId);
  }
  if (action === 'close') {
    return ownerClose(ctx, paymentId);
  }
  return ctx.reply('❌ Aksi tidak dikenal.');
}

// ✅ KONFIRMASI
async function ownerConfirm(ctx, reviewerId, paymentId) {
  await ctx.answerCallbackQuery().catch(() => {});
  const result = await confirmPayment(paymentId, reviewerId);

  if (result.error === 'LOCKED' || result.error === 'INVALID_STATUS') {
    await ctx.answerCallbackQuery({ text: '⚠️ Transaksi sudah diproses.' }).catch(() => {});
    return;
  }
  if (result.error === 'NOT_FOUND') {
    await ctx.answerCallbackQuery({ text: 'Payment tidak ditemukan.' }).catch(() => {});
    return;
  }

  if (!result.ok) {
    // API_FAILED / DECRYPT_FAILED
    await editOwnerMessage(ctx, paymentId, failedOwnerCaption(paymentId, result), ownerRetryKeyboard(paymentId));
    const user = getUserByTelegramId(result.payment?.telegram_id);
    if (user) {
      await ctx.api.sendMessage(
        user.telegram_id,
        `⏳ Pembayaran kamu sudah dikonfirmasi.\n\nNamun server pembuatan akun sedang\nmengalami masalah.\n\nAkun belum berhasil dibuat.\n\nAdministrator akan memprosesnya kembali.`,
      ).catch(() => {});
    }
    return;
  }

  if (result.type === 'LIMIT') {
    await editOwnerMessage(ctx, paymentId, limitSuccessOwnerCaption(result));
    const user = result.user;
    await ctx.api.sendMessage(
      result.payment.telegram_id,
      `╭━━━━━━━━━━━━━━━━━━━━━━╮
       🎉 LIMIT DITAMBAHKAN
╰━━━━━━━━━━━━━━━━━━━━━━╯

Pembayaran berhasil dikonfirmasi.

💎 Limit ditambahkan:
+${result.payment.add_limit}

💎 Limit sekarang:
<code>${user ? user.limit : '?'}</code>

Terima kasih.`,
      { parse_mode: 'HTML' },
    ).catch(() => {});
    return;
  }

  // ACCOUNT success — kirim hasil ke PEMBELI, edit pesan owner
  await editOwnerMessage(ctx, paymentId, accountSuccessOwnerCaption(result));
  await sendAccountResultTo(result.payment.telegram_id, result.account, paymentId, ctx);
}

// ❌ TOLAK
async function ownerReject(ctx, reviewerId, paymentId) {
  await ctx.answerCallbackQuery().catch(() => {});
  const result = rejectPayment(paymentId, reviewerId);
  if (!result.ok) {
    await ctx.answerCallbackQuery({ text: '⚠️ Transaksi sudah diproses.' }).catch(() => {});
    return;
  }
  await editOwnerMessage(ctx, paymentId, rejectedOwnerCaption(paymentId));
  await ctx.api.sendMessage(
    result.payment.telegram_id,
    `╭━━━━━━━━━━━━━━━━━━━━━━╮
     ❌ PEMBAYARAN DITOLAK
╰━━━━━━━━━━━━━━━━━━━━━━╯

Order:
<code>${paymentId}</code>

Bukti pembayaran tidak dapat
dikonfirmasi.

Akun tidak dibuat.

Silakan hubungi administrator
jika terjadi kesalahan.`,
    { parse_mode: 'HTML' },
  ).catch(() => {});
}

// 🔄 RETRY
async function ownerRetry(ctx, reviewerId, paymentId) {
  await ctx.answerCallbackQuery().catch(() => {});
  const result = await retryPayment(paymentId, reviewerId);

  if (result.error === 'ALREADY_SUCCESS' || result.error === 'INVALID_STATUS') {
    await ctx.answerCallbackQuery({ text: '⚠️ Transaksi sudah diproses.' }).catch(() => {});
    return;
  }
  if (!result.ok) {
    await editOwnerMessage(ctx, paymentId, failedOwnerCaption(paymentId, result), ownerRetryKeyboard(paymentId));
    return;
  }
  await editOwnerMessage(ctx, paymentId, accountSuccessOwnerCaption(result));
  const buyer = getUserByTelegramId(result.payment.telegram_id);
  if (buyer) {
    await sendAccountResultTo(buyer.telegram_id, result.account, paymentId, ctx);
  }
}

// ❌ TUTUP (hapus tombol dari pesan owner)
async function ownerClose(ctx, paymentId) {
  const payment = getPayment(paymentId);
  if (payment?.owner_message_id) {
    await ctx.api.editMessageCaption(payment.owner_chat_id, payment.owner_message_id, {
      caption: `🧾 ${paymentId}\n\nTransaksi ditutup.`,
      reply_markup: new InlineKeyboard(),
    }).catch(() => {});
  }
  await ctx.answerCallbackQuery({ text: 'Ditutup' }).catch(() => {});
}

// ------------------------------------------------------------
// Helper: kirim hasil akun ke pembeli (tanpa thumbnail owner chat)
// ------------------------------------------------------------
/** Kirim hasil akun premium ke chat pembeli (bukan ke owner). */
async function sendAccountResultTo(telegramId, account, paymentId, ctx) {
  const caption = accountResultCaption(account, { paymentId });
  const kb = accountResultKeyboard();
  if (fs.existsSync(config.thumbnailPath)) {
    try {
      await ctx.api.sendPhoto(telegramId, new InputFile(config.thumbnailPath), {
        caption,
        parse_mode: 'HTML',
        reply_markup: kb,
      });
      return;
    } catch (err) {
      logger.warn('payment', `thumbnail to buyer failed: ${err.description || err.message}`);
    }
  }
  await ctx.api.sendMessage(telegramId, caption, { parse_mode: 'HTML', reply_markup: kb });
}

// ------------------------------------------------------------
// Helper: edit pesan owner
// ------------------------------------------------------------
async function editOwnerMessage(ctx, paymentId, caption, keyboard = new InlineKeyboard()) {
  const payment = getPayment(paymentId);
  if (!payment?.owner_message_id) return;
  await ctx.api.editMessageCaption(payment.owner_chat_id, payment.owner_message_id, {
    caption,
    parse_mode: 'HTML',
    // InlineKeyboard kosong = HAPUS tombol approve/reject dari pesan owner
    reply_markup: keyboard,
  }).catch(() => {});
}

function accountSuccessOwnerCaption(result) {
  const user = getUserByTelegramId(result.payment.telegram_id);
  return `╭━━━━━━━━━━━━━━━━━━━━━━╮
       ✅ PAYMENT SUCCESS
╰━━━━━━━━━━━━━━━━━━━━━━╯

Payment:
<code>${result.payment.payment_id}</code>

Pembeli:
${escHtml(userMention(user))}

Username:
<code>${escHtml(result.account.username || result.payment.account_username)}</code>

Role:
${escHtml(result.account.role || result.payment.role)}

Status:
<code>AKUN BERHASIL DIBUAT</code>`;
}

function limitSuccessOwnerCaption(result) {
  const user = result.user;
  return `╭━━━━━━━━━━━━━━━━━━━━━━╮
       💎 LIMIT SUCCESS
╰━━━━━━━━━━━━━━━━━━━━━━╯

Payment:
<code>${result.payment.payment_id}</code>

Pembeli:
${escHtml(userMention(user))}

Pembelian:
+${result.payment.add_limit} LIMIT

Status:
<code>LIMIT DITAMBAHKAN</code>`;
}

function failedOwnerCaption(paymentId, result) {
  const payment = getPayment(paymentId);
  const detail = payment ? `${payment.account_username} (${payment.role})` : '-';
  return `╭━━━━━━━━━━━━━━━━━━━━━━╮
       ⚠️ API BIMXZ GAGAL
╰━━━━━━━━━━━━━━━━━━━━━━╯

Payment:
<code>${paymentId}</code>

Username:
<code>${escHtml(detail)}</code>

Role:
${payment?.role || '-'}

Akun belum berhasil dibuat.

Error internal dicatat di log.`;
}

function rejectedOwnerCaption(paymentId) {
  return `╭━━━━━━━━━━━━━━━━━━━━━━╮
        ❌ PAYMENT REJECTED
╰━━━━━━━━━━━━━━━━━━━━━━╯

Payment:
<code>${paymentId}</code>

Status:
<code>DITOLAK</code>`;
}

// ------------------------------------------------------------
async function adminCallback(ctx, rest, _data) {
  const action = rest[0];
  switch (action) {
    case 'menu': return adminMenu(ctx);
    case 'users': return adminUsers(ctx);
    case 'pending': return adminPending(ctx);
    case 'stats': return adminStats(ctx);
    case 'log': return adminLog(ctx);
    case 'apistatus': return adminApiStatus(ctx);
    case 'addlimit': {
      if (!adminGuard(ctx)) return;
      setSession(ctx.from.id, { state: 'ADMIN_LIMIT_ID' });
      await ctx.reply('➕ TAMBAH LIMIT\n\nMasukkan <b>Telegram ID</b> user:');
      return;
    }
    default:
      return ctx.reply('❌ Aksi tidak dikenal.');
  }
}

async function helpCallback(ctx) {
  return helpCommand(ctx);
}

async function menuCallback(ctx) {
  await sendMainMenu(ctx);
}
