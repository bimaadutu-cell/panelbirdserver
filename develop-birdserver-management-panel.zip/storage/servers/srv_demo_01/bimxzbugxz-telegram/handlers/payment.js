// ============================================================
// handlers/payment.js — Pembayaran QR & bukti transfer
// ============================================================
import { config } from '../config.js';
import * as db from '../database.js';
import { getSession, setSession, clearSession } from '../middleware.js';
import { createLimitPayment, submitProof, cancelPayment } from '../services/paymentService.js';
import { getUserByTelegramId } from '../database.js';
import { paymentKeyboard, ownerReviewKeyboard } from '../keyboards.js';
import { sendQr, escHtml, formatMoney, formatDateTime, userMention } from '../helpers.js';
import { logger } from '../logger.js';

// ------------------------------------------------------------
// 💳 TAMBAH LIMIT (payment LIMIT)
// ------------------------------------------------------------
export async function startLimitPurchase(ctx) {
  const from = ctx.from;
  if (!from) return;
  const payment = createLimitPayment({ telegramId: from.id });
  setSession(from.id, {
    state: 'LIMIT_PAYMENT',
    paymentId: payment.payment_id,
    username: null,
    password: null,
    role: null,
  });
  const caption = `╭━━━━━━━━━━━━━━━━━━━━━━╮
       💎 TAMBAH LIMIT
╰━━━━━━━━━━━━━━━━━━━━━━╯

🧾 Order ID
<code>${payment.payment_id}</code>

📦 Produk
+${payment.add_limit} LIMIT

💰 Harga
<code>${formatMoney(payment.amount)}</code>

────────────────────

📱 Silakan scan QR di atas.

Setelah pembayaran selesai,
kirim bukti transfer ke bot.

⚠️ Limit ditambahkan setelah
pembayaran dikonfirmasi owner.`;
  await sendQr(ctx, caption, paymentKeyboard(payment.payment_id));
}

// ------------------------------------------------------------
// User mengirim foto bukti
// ------------------------------------------------------------
export async function handleProofPhoto(ctx) {
  const photos = ctx.message?.photo;
  if (!photos || photos.length === 0) return;
  const fileId = photos[photos.length - 1].file_id; // resolusi terbesar
  await processProof(ctx, fileId, 'photo');
}

export async function handleProofDocument(ctx) {
  const doc = ctx.message?.document;
  if (!doc) return;
  const mime = doc.mime_type || '';
  if (!mime.startsWith('image/')) {
    await ctx.reply('❌ Kirim bukti pembayaran dalam bentuk gambar (foto/scan).');
    return;
  }
  await processProof(ctx, doc.file_id, 'document');
}

async function processProof(ctx, fileId, fileType) {
  const from = ctx.from;
  const result = submitProof({ telegramId: from.id, fileId, fileType });
  if (!result.ok) {
    if (result.error === 'NO_PENDING_PAYMENT') {
      await ctx.reply('ℹ️ Tidak ada transaksi yang menunggu bukti pembayaran.\nSilakan buat transaksi baru dari menu.');
    } else if (result.error === 'INVALID_STATUS') {
      await ctx.reply('ℹ️ Transaksi kamu sedang diproses. Mohon tunggu konfirmasi owner.');
    } else {
      await ctx.reply('⚠️ Terjadi kesalahan saat memproses bukti.');
    }
    return;
  }
  const payment = result.payment;
  await ctx.reply(`✅ Bukti pembayaran diterima!\n\n🧾 Order: <code>${payment.payment_id}</code>\n📌 Status: <code>PROOF SUBMITTED</code>\n\n⏳ Menunggu konfirmasi owner.`);
  await notifyOwnerProof(ctx, payment);
}

// ------------------------------------------------------------
// Teruskan bukti + detail ke OWNER
// ------------------------------------------------------------
function ownerCaption(payment, user) {
  const buyer = userMention(user);
  const base = `╭━━━━━━━━━━━━━━━━━━━━━━╮
       💰 PAYMENT REVIEW
╰━━━━━━━━━━━━━━━━━━━━━━╯

🧾 Payment ID
<code>${payment.payment_id}</code>

👤 Pembeli
${escHtml(buyer)}

🆔 Telegram ID
<code>${payment.telegram_id}</code>

📦 Produk
BIMXZBUGXZ ${payment.payment_type === 'LIMIT' ? 'LIMIT' : 'ACCOUNT'}

📌 Status
<code>PROOF SUBMITTED</code>

⏰ Waktu pembayaran
${escHtml(formatDateTime(payment.created_at))}`;

  if (payment.payment_type === 'LIMIT') {
    return `${base}

💎 Pembelian:
+${payment.add_limit} LIMIT

💰 Harga:
${escHtml(formatMoney(payment.amount))}

Silakan periksa bukti pembayaran
di foto di atas.`;
  }

  return `${base}

👤 Username akun
<code>${escHtml(payment.account_username)}</code>

👑 Role
${escHtml(payment.role)}

⏳ Masa aktif
${payment.duration} Hari

💰 Harga
${escHtml(formatMoney(payment.amount))}

Silakan periksa bukti pembayaran
di foto di atas.`;
}

async function notifyOwnerProof(ctx, payment) {
  const ownerId = config.ownerId;
  if (!ownerId) return;
  const user = getUserByTelegramId(payment.telegram_id);
  const caption = ownerCaption(payment, user);
  const kb = ownerReviewKeyboard(payment.payment_id);

  try {
    const sent = payment.proof_type === 'document'
      ? await ctx.api.sendDocument(ownerId, payment.proof_file_id, { caption, parse_mode: 'HTML', reply_markup: kb })
      : await ctx.api.sendPhoto(ownerId, payment.proof_file_id, { caption, parse_mode: 'HTML', reply_markup: kb });
    db.setPaymentOwnerMessage(payment.payment_id, ownerId, sent.message_id);
    logger.info('payment', `PAYMENT ${payment.payment_id} forwarded to owner`);
  } catch (err) {
    logger.error('payment', `forward proof failed for ${payment.payment_id}: ${err.description || err.message}`);
    await ctx.api.sendMessage(
      ownerId,
      `⚠️ Gagal mengirim foto bukti, berikut detailnya:\n\n${caption}`,
      { parse_mode: 'HTML', reply_markup: kb },
    ).catch(() => {});
  }
}

// ------------------------------------------------------------
// Callback: KIRIM BUKTI (petunjuk) & BATAL
// ------------------------------------------------------------
export async function proofHintCallback(ctx, paymentId) {
  await ctx.answerCallbackQuery({
    text: 'Silakan kirim foto bukti transfer ke chat ini.',
  }).catch(() => {});
}

export async function paymentCancelCallback(ctx, paymentId) {
  const from = ctx.from;
  const session = getSession(from.id);
  if (session?.paymentId === paymentId) clearSession(from.id);
  const result = cancelPayment(paymentId);
  await ctx.answerCallbackQuery({ text: '❌ Transaksi dibatalkan' }).catch(() => {});
  if (result.ok) {
    await ctx.reply(`❌ Transaksi dibatalkan.\n\n🧾 Order: <code>${paymentId}</code>\n📌 Status: <code>EXPIRED</code>`);
  } else if (result.error === 'INVALID_STATUS') {
    await ctx.reply(`ℹ️ Transaksi <code>${paymentId}</code> sedang diproses dan tidak dapat dibatalkan.`);
  }
}
