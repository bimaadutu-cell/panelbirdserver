// ============================================================
// handlers/createAccount.js — Alur pembuatan akun (state session)
// CREATE_USERNAME -> CREATE_PASSWORD -> CREATE_ROLE -> CREATE_CONFIRM
// ============================================================
import { config, ALLOWED_ROLES, accountPrice, roleDurationDays } from '../config.js';
import { getSession, setSession, clearSession } from '../middleware.js';
import { getUser } from '../services/userService.js';
import { createAccountWithLimit } from '../services/accountService.js';
import { createAccountPayment } from '../services/paymentService.js';
import { roleKeyboard, confirmKeyboard, noLimitKeyboard, apiFailKeyboard } from '../keyboards.js';
import { sendWithThumbnail, sendQr, sendAccountResult, escHtml, maskPassword, formatMoney } from '../helpers.js';
import { sendMainMenu } from './start.js';

const USERNAME_RE = /^[a-zA-Z0-9_.-]{3,20}$/;

export function validateUsername(username) {
  if (typeof username !== 'string') return false;
  if (username.length < 3 || username.length > 20) return false;
  return USERNAME_RE.test(username);
}

export function validatePassword(password) {
  if (typeof password !== 'string') return false;
  return password.length >= 6 && password.length <= 64;
}

export function validateRole(role) {
  return ALLOWED_ROLES.includes(role);
}

export async function startCreate(ctx) {
  const from = ctx.from;
  if (!from) return;
  setSession(from.id, {
    state: 'CREATE_USERNAME',
    username: null,
    password: null,
    role: null,
    paymentId: null,
  });
  await ctx.reply(`╭━━━━━━━━━━━━━━━━━━━━━━╮
       🆕 CREATE ACCOUNT
╰━━━━━━━━━━━━━━━━━━━━━━╯

Mari buat akun ${config.botName}.

Kamu akan diminta mengisi:

👤 Username
🔐 Password
👑 Role

📝 <b>STEP 1/3</b>

Masukkan <b>username</b> akun.

Contoh:
<code>myaccount123</code>

Valid: 3-20 karakter, hanya
huruf, angka, titik, _ dan -.
`);
}

export async function cancelCreate(ctx) {
  const from = ctx.from;
  if (!from) return;
  clearSession(from.id);
  await ctx.answerCallbackQuery({ text: '❌ Dibatalkan' }).catch(() => {});
  await sendMainMenu(ctx);
}

// ------------------------------------------------------------
// Router teks selama alur create (return true jika terproses)
// ------------------------------------------------------------
export async function handleCreateText(ctx) {
  const from = ctx.from;
  const session = getSession(from.id);
  if (!session) return false;

  if (session.state !== 'CREATE_USERNAME' && session.state !== 'CREATE_PASSWORD') {
    // user mengetik teks di tengah alur tombol
    await ctx.reply('ℹ️ Silakan gunakan tombol di bawah untuk melanjutkan.');
    return true;
  }

  const text = (ctx.message.text || '').trim();

  if (session.state === 'CREATE_USERNAME') {
    if (!validateUsername(text)) {
      await ctx.reply('❌ Username tidak valid.\n\nSilakan masukkan username kembali.\nValid: 3-20 karakter, hanya huruf, angka, titik, _ dan -.');
      return true;
    }
    session.username = text;
    session.state = 'CREATE_PASSWORD';
    await ctx.reply('🔐 <b>STEP 2/3</b>\n\nMasukkan <b>password</b> akun.\n\nMinimal 6 karakter.\n\n🔒 Password tidak akan pernah dibagikan dan hanya digunakan untuk membuat akun.');
    return true;
  }

  // CREATE_PASSWORD
  if (!validatePassword(text)) {
    await ctx.reply('❌ Password tidak valid.\n\nMinimal 6 karakter, maksimal 64 karakter.\nSilakan masukkan password kembali.');
    return true;
  }
  session.password = text;
  session.state = 'CREATE_ROLE';
  await ctx.reply('👑 <b>STEP 3/3</b>\n\nPilih role akun:', { reply_markup: roleKeyboard() });
  return true;
}

// ------------------------------------------------------------
// Callback: pilih role (create:role:XXX)
// ------------------------------------------------------------
export async function chooseRole(ctx, role) {
  const from = ctx.from;
  const session = getSession(from.id);
  if (!session || session.state !== 'CREATE_ROLE') {
    await ctx.answerCallbackQuery({ text: 'Sesi tidak ditemukan. Mulai ulang dengan /start' }).catch(() => {});
    return;
  }
  if (!validateRole(role)) {
    await ctx.answerCallbackQuery({ text: '❌ Role tidak valid.' }).catch(() => {});
    return;
  }
  session.role = role;
  session.state = 'CREATE_CONFIRM';
  await ctx.answerCallbackQuery().catch(() => {});

  const price = accountPrice(role);
  const days = roleDurationDays(role);
  const user = getUser(from.id);
  const caption = `╭━━━━━━━━━━━━━━━━━━━━━━╮
      📋 KONFIRMASI AKUN
╰━━━━━━━━━━━━━━━━━━━━━━╯

👤 Username
<code>${escHtml(session.username)}</code>

🔐 Password
<code>${maskPassword(session.password)}</code>

👑 Role
<code>${role}</code>

⏳ Masa aktif
<code>${days} Hari</code>

💰 Harga
<code>${formatMoney(price)}</code>

💎 Limit kamu
<code>${user ? user.limit : '?'}</code>

────────────────────

Data sudah benar?
Pilih metode pembayaran:`;
  await sendWithThumbnail(ctx, caption, confirmKeyboard());
}

// ------------------------------------------------------------
// Callback: edit data (create:edit)
// ------------------------------------------------------------
export async function editData(ctx) {
  const from = ctx.from;
  const session = getSession(from.id);
  if (!session) {
    await ctx.answerCallbackQuery({ text: 'Sesi tidak ditemukan' }).catch(() => {});
    return;
  }
  await ctx.answerCallbackQuery({ text: '✏️ Ulangi pengisian data' }).catch(() => {});
  await startCreate(ctx);
}

// ------------------------------------------------------------
// Callback: bayar pakai limit (create:pay:limit)
// ------------------------------------------------------------
export async function payWithLimit(ctx) {
  const from = ctx.from;
  const session = getSession(from.id);
  if (!session || session.state !== 'CREATE_CONFIRM' || !session.username || !session.password || !session.role) {
    await ctx.answerCallbackQuery({ text: 'Sesi tidak ditemukan. Mulai ulang.' }).catch(() => {});
    return;
  }
  await ctx.answerCallbackQuery().catch(() => {});

  const { username, password, role } = session;
  const result = await createAccountWithLimit(from.id, { username, password, role });

  if (result.ok) {
    clearSession(from.id); // hapus password dari session
    await sendAccountResult(ctx, result.data, { remainingLimit: result.remainingLimit });
    return;
  }

  if (result.error === 'NO_LIMIT') {
    await ctx.reply('❌ Limit kamu tidak cukup.\n\nKamu tetap bisa membeli akun dengan metode QR, atau tambah limit terlebih dahulu.', {
      reply_markup: noLimitKeyboard(),
    });
    return;
  }

  // API gagal -> limit TIDAK berkurang
  await ctx.reply('❌ Gagal membuat akun.\n\nSilakan coba lagi beberapa saat lagi.\n\n(Limit kamu tidak berkurang)', {
    reply_markup: apiFailKeyboard(),
  });
}

// ------------------------------------------------------------
// Callback: bayar pakai QR (create:pay:qr)
// ------------------------------------------------------------
export async function payWithQr(ctx) {
  const from = ctx.from;
  const session = getSession(from.id);
  if (!session || session.state !== 'CREATE_CONFIRM' || !session.username || !session.password || !session.role) {
    await ctx.answerCallbackQuery({ text: 'Sesi tidak ditemukan. Mulai ulang.' }).catch(() => {});
    return;
  }
  await ctx.answerCallbackQuery().catch(() => {});

  const payment = createAccountPayment({
    telegramId: from.id,
    username: session.username,
    password: session.password,
    role: session.role,
  });

  session.paymentId = payment.payment_id;
  session.password = null; // password sudah aman (terenkripsi) di database
  session.username = null;
  session.role = null;

  const caption = `╭━━━━━━━━━━━━━━━━━━━━━━╮
          💳 PEMBAYARAN
╰━━━━━━━━━━━━━━━━━━━━━━╯

🧾 Order ID
<code>${payment.payment_id}</code>

📦 Produk
BIMXZBUGXZ ACCOUNT

👤 Username
<code>${escHtml(payment.account_username)}</code>

👑 Role
<code>${payment.role}</code>

⏳ Masa aktif
<code>${payment.duration} Hari</code>

💰 Harga
<code>${formatMoney(payment.amount)}</code>

────────────────────

📱 Silakan scan QR di atas.

Setelah pembayaran selesai,
kirim bukti transfer ke bot.

⚠️ Akun belum dibuat sebelum
pembayaran dikonfirmasi owner.`;
  await sendQr(ctx, caption, paymentKeyboard(payment.payment_id));
}
