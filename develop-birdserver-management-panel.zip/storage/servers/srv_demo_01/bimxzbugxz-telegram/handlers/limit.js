// ============================================================
// handlers/limit.js — 💎 MY LIMIT
// ============================================================
import { config } from '../config.js';
import { getUser } from '../services/userService.js';
import { limitMenuKeyboard } from '../keyboards.js';
import { sendWithThumbnail, escHtml, formatDate, formatMoney, userMention } from '../helpers.js';

export async function viewLimit(ctx) {
  const from = ctx.from;
  if (!from) return;
  const user = getUser(from.id);
  if (!user) {
    await ctx.reply('❌ Data user tidak ditemukan. Ketik /start untuk mendaftar.');
    return;
  }
  const caption = `╭━━━━━━━━━━━━━━━━━━━━━━╮
          💎 MY LIMIT
╰━━━━━━━━━━━━━━━━━━━━━━╯

👤 User:
${escHtml(userMention(user))}

💎 Limit tersisa:
<code>${user.limit}</code>

📊 Total akun dibuat:
<code>${user.total_created}</code>

📅 Bergabung:
${escHtml(formatDate(user.created_at))}

━━━━━━━━━━━━━━━━━━━━━━

💰 Harga ${config.botName} ACCOUNT:
👤 PENGGUNA — ${escHtml(formatMoney(config.accountPricePengguna))} (7 hari)
🛒 RESELLER — ${escHtml(formatMoney(config.accountPriceReseller))} (30 hari)
👑 OWNER — ${escHtml(formatMoney(config.accountPriceOwner))} (90 hari)`;
  await sendWithThumbnail(ctx, caption, limitMenuKeyboard());
}
