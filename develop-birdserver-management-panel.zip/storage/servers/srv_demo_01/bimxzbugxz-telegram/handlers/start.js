// ============================================================
// handlers/start.js — /start, /help, /cancel, menu utama
// ============================================================
import { config, isAdminId } from '../config.js';
import { getOrCreateUser, getUser } from '../services/userService.js';
import { clearSession } from '../middleware.js';
import { mainMenuKeyboard, backMenuKeyboard } from '../keyboards.js';
import { sendWithThumbnail, escHtml } from '../helpers.js';

export async function sendMainMenu(ctx) {
  const from = ctx.from;
  if (!from) return;
  const user = getUser(from.id);
  const caption = `╭━━━━━━━━━━━━━━━━━━━━━━╮
       🤖 ${config.botName}
      ACCOUNT SYSTEM
╰━━━━━━━━━━━━━━━━━━━━━━╯

👋 Halo, ${escHtml(from.first_name || 'Kawan')}!

Selamat datang di sistem
pembuatan akun ${config.botName}.

⚡ Proses otomatis
🔐 Sistem aman
💎 Limit: <code>${user ? user.limit : '?'}</code>

Silakan pilih menu:`;
  await sendWithThumbnail(ctx, caption, mainMenuKeyboard(isAdminId(from.id)));
}

export async function startCommand(ctx) {
  const from = ctx.from;
  if (!from) return;
  // 1. ambil Telegram ID, 2. cek database, 3. buat user jika belum ada
  getOrCreateUser(from.id, {
    username: from.username || '',
    first_name: from.first_name || '',
  });
  clearSession(from.id);
  await sendMainMenu(ctx);
}

export async function helpCommand(ctx) {
  const from = ctx.from;
  if (!from) return;
  const caption = `╭━━━━━━━━━━━━━━━━━━━━━━╮
       🤖 CARA MENGGUNAKAN
╰━━━━━━━━━━━━━━━━━━━━━━╯

1. Tekan <b>CREATE AKUN</b>.
2. Masukkan username.
3. Masukkan password.
4. Pilih role.
5. Pilih pembayaran.

💎 Jika menggunakan <b>LIMIT</b>:
akun dibuat otomatis jika API berhasil.

📱 Jika menggunakan <b>QR</b>:
lakukan pembayaran, kirim bukti,
tunggu owner mengkonfirmasi.

Setelah owner mengkonfirmasi,
bot otomatis membuat akun.

ROLE:

👤 PENGGUNA — 7 hari
🛒 RESELLER — 30 hari
👑 OWNER — 90 hari

━━━━━━━━━━━━━━━━━━━━━━

Butuh bantuan? ${config.supportUsername}`;
  await sendWithThumbnail(ctx, caption, backMenuKeyboard());
}

export async function cancelCommand(ctx) {
  const from = ctx.from;
  if (!from) return;
  clearSession(from.id);
  await ctx.reply('❌ Sesi dibatalkan.\nKembali ke menu utama 👇', {
    reply_markup: mainMenuKeyboard(isAdminId(from.id)),
  });
}
