# 🏪 BOT STORE V3 — PROFESSIONAL DIGITAL STORE

Bot Auto Order Digital Store full realtime — Pterodactyl + Telegram (+ WhatsApp opsional).
100% config-driven: admin cukup edit file di `config/`, tidak perlu edit source code.

## ✨ Fitur V3

- 🔐 Verifikasi Join Channel + Grup Telegram (dicek tiap interaksi)
- 🎨 Menu inline keyboard modern — `editMessageText` (tidak spam chat)
- 🖥️ Order Panel Pterodactyl otomatis (create user + server)
- 📱 BimzCreated (USER / RESELLER / OWNER) — config-driven
- 🐛 APK Yanzz (Basic/VIP, Bulanan/Permanen) — config-driven
- 💰 Multi payment: QRIS / DANA / GoPay / OVO / Transfer
- ✅ Verifikasi invoice + bukti pembayaran
- 📜 Riwayat, 👤 Profil, 📢 Pengumuman, 📞 Support, ⚙ Pengaturan
- 🛡 Rate limit, anti-spam, queue system, invoice expired, anti double payment
- 🧹 Scheduler auto-delete panel expired

## 🚀 Install di Pterodactyl (NodeJS Egg)

1. Buat server baru di Pterodactyl dengan **Egg: NodeJS VIP** (atau NodeJS biasa, versi ≥ 18).
2. Upload isi ZIP ini ke folder root server (`/home/container`).
3. Set **Startup Command**:
   ```
   npm install && node index.js
   ```
4. Buka tab **Startup**, pastikan variable `TELEGRAM_BOT_TOKEN` diisi
   (atau isi manual di file `.env`).
5. Edit file di folder `config/` sesuai kebutuhan:
   - `config/telegram.js` → channel & grup verifikasi
   - `config/panel.js` → server Pterodactyl (URL + PTLA)
   - `config/prices.js` → harga per role & size
   - `config/products.js` → produk APK Yanzz
   - `config/bimzcreated.js` → paket BimzCreated
   - `config/payment.js` → metode pembayaran
   - `config/owner.js` → daftar admin
   - `config/store.js` → nama toko, kontak, pengumuman
6. **Start** server. Log akan menunjukkan `Telegram: @namabotmu`.

## 🔀 Skip Logic Platform

| TELEGRAM_BOT_TOKEN | WhatsApp | Hasil                                  |
| ------------------ | -------- | -------------------------------------- |
| ✅ Diisi           | -        | Telegram aktif, WA di-skip             |
| ❌ Kosong          | ✅ ON    | WhatsApp aktif, Telegram di-skip       |
| ✅ Diisi           | ✅ ON + `FORCE_WA=1` | Dua-duanya aktif           |

## 📂 Struktur Project

```
config/         → semua konfigurasi (edit di sini)
handlers/       → menu.js (V3), flow.js, admin.js
middlewares/    → verifyJoin.js, rateLimit.js
platforms/      → telegram.js, whatsapp.js
services/
  panel/        → pterodactyl.js (auto-discover node/nest/egg)
  payment/      → invoice.js, verifier.js
  order/        → orderService.js
database/       → db.js (SQLite)
scheduler/      → cron auto-delete panel expired
helpers/        → format
utils/          → logger, queue
media/          → banner, logo, QRIS image
```

## 🔧 Update Konfigurasi

Semua perubahan config hot-readable pada request berikutnya (kecuali `panel.js`
metadata cache yang di-refresh tiap `metaCacheTTL` detik).

## 📜 Lisensi

Private. © BIMZ Digital Store 2026.
