Simpan asset toko di sini: logo.jpg, banner.jpg, welcome.jpg, qris.jpg
