// ==============================================
// FLOW USER V3.2 — Platform-agnostic (WA & Telegram)
// ==============================================
// Perubahan besar V3.2:
// - Halaman sambutan + persetujuan ketentuan (di platforms/telegram.js)
// - Form terpisah:
//     * PANEL      : name, username, email, whatsapp
//     * BIMZ       : name, bimzUsername, bimzPassword, whatsapp, email, role
//     * APK BUG    : name, apkUsername, apkPassword, whatsapp  (TANPA PAYMENT)
// - Persetujuan (agreement) step WAJIB sebelum order diproses
// - APK BUG tidak menggunakan QRIS / payment otomatis → langsung menuju
//   tombol kontak Yanzz (WhatsApp + Telegram)
// - Setelah BimzCreated selesai bayar → tombol WhatsApp & Telegram Admin
// - Semua kontak dari config/contact.js
// - Semua gambar dari config/images.js
// - Verifikasi bukti pembayaran async (OCR strict)
// ==============================================
const fs = require("fs");
const path = require("path");
const db = require("../database/db");
const store = require("../config/store");
const banner = require("../config/banner");
const productsCfg = require("../config/products");
const pricesCfg = require("../config/prices");
const paymentCfg = require("../config/payment");
const panelCfg = require("../config/panel");
const bimzCfg = require("../config/bimzcreated");
const analyzer = require("../services/panel/analyzer");
const bonusCfg = require("../config/bonus");
const contactCfg = require("../config/contact");
const images = require("../config/images");
const reportCfg = require("../config/report");
const orderSvc = require("../services/order/orderService");
const invoiceSvc = require("../services/payment/invoice");
const verifier = require("../services/payment/verifier");
const rateLimit = require("../middlewares/rateLimit");
const logger = require("../utils/logger");
const { rupiah, fmtDate, genOrderId } = require("../helpers/format");
const adminHandler = require("./admin");
const aiHandler = require("./ai");
const fbbHandler = require("./filebuilder");

const mediaOr = (p) => (p && fs.existsSync(p) ? p : null);

const SIZES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, "unlimited"];
function servers() { return panelCfg.servers; }

// ==============================================
// FORM DEFINITIONS
// ==============================================
const FORM_PANEL = [
  { key: "name",     prompt: "📝 Silakan kirim *Nama lengkap*:" },
  { key: "username", prompt: "👤 Kirim *Username Panel* (huruf/angka, tanpa spasi):" },
  { key: "email",    prompt: "📧 Kirim *Email* aktif:" },
  { key: "whatsapp", prompt: "📱 Kirim *Nomor WhatsApp* (contoh 6281234567890):" },
];

const FORM_BIMZ = [
  { key: "name",         prompt: "📝 Silakan kirim *Nama lengkap*:" },
  { key: "bimzUsername", prompt: "👤 Kirim *Username Akun BimzCreated* yang Anda inginkan (huruf/angka, tanpa spasi):" },
  { key: "bimzPassword", prompt: "🔑 Kirim *Password Akun BimzCreated* (min. 6 karakter):" },
  { key: "whatsapp",     prompt: "📱 Kirim *Nomor WhatsApp* (contoh 6281234567890):" },
  { key: "email",        prompt: "📧 Kirim *Email* aktif:" },
];

const FORM_APKBUG = [
  { key: "name",        prompt: "📝 Silakan kirim *Nama lengkap*:" },
  { key: "apkUsername", prompt: "👤 Kirim *Username APK* yang Anda inginkan (huruf/angka, tanpa spasi):" },
  { key: "apkPassword", prompt: "🔑 Kirim *Password APK* (min. 6 karakter):" },
  { key: "whatsapp",    prompt: "📱 Kirim *Nomor WhatsApp* (contoh 6281234567890):" },
];

function formFor(type) {
  if (type === "bimz") return FORM_BIMZ;
  if (type === "apk")  return FORM_APKBUG;
  return FORM_PANEL;
}

function validate(field, value) {
  const v = (value || "").trim();
  if (!v) return "Kosong.";
  if (field === "name" && v.length < 2) return "Nama minimal 2 huruf.";
  if (/username$/i.test(field) && !/^[a-zA-Z0-9_.]{3,20}$/.test(v))
    return "Username 3-20 karakter (huruf/angka/underscore/titik).";
  if (/password$/i.test(field) && v.length < 6) return "Password minimal 6 karakter.";
  if (field === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return "Email tidak valid.";
  if (field === "whatsapp" && !/^\d{9,15}$/.test(v.replace(/\D/g, ""))) return "Nomor WhatsApp tidak valid.";
  return null;
}

// ==============================================
// SUMMARY & AGREEMENT
// ==============================================
function summaryText(session) {
  const f = session.form || {};
  const lines = [`📋 *RINGKASAN DATA ORDER*`, `━━━━━━━━━━━━━━━━━━`];
  if (session.type === "panel") {
    const price = orderSvc.panelPrice(session.serverKey, session.role, session.size);
    lines.push(
      `Jenis        : Panel Pterodactyl`,
      `Server       : ${session.serverKey}`,
      `Paket        : ${session.role} — ${session.size === "unlimited" ? "UNLIMITED" : session.size + "GB"}`,
      `Harga        : ${rupiah(price)}`,
      `Nama         : ${f.name}`,
      `Username     : ${f.username}`,
      `Email        : ${f.email}`,
      `WhatsApp     : ${f.whatsapp}`,
    );
  } else if (session.type === "bimz") {
    const p = bimzCfg.packages[session.bimzRole];
    lines.push(
      `Jenis        : BimzCreated (APK CPanel)`,
      `Role         : ${p.label} — ${rupiah(p.price)}`,
      `Nama         : ${f.name}`,
      `Username Akun: ${f.bimzUsername}`,
      `Password Akun: ${f.bimzPassword}`,
      `WhatsApp     : ${f.whatsapp}`,
      `Email        : ${f.email}`,
    );
  } else if (session.type === "apk") {
    const it = orderSvc.apkPrice(session.itemId);
    lines.push(
      `Jenis        : APK BUG`,
      `Paket        : ${it?.item?.name || session.itemId}${it ? " — " + rupiah(it.item.price) : ""}`,
      `Nama         : ${f.name}`,
      `Username APK : ${f.apkUsername}`,
      `Password APK : ${f.apkPassword}`,
      `WhatsApp     : ${f.whatsapp}`,
    );
  }
  lines.push(`━━━━━━━━━━━━━━━━━━`);
  lines.push(
    ``,
    `⚠️ *PERSETUJUAN WAJIB*`,
    `Dengan menekan *Saya Setuju*, Anda menyatakan:`,
    `• Seluruh data yang Anda isi sudah benar.`,
    `• Anda memahami bahwa kesalahan pengisian data menjadi tanggung jawab Anda.`,
  );
  return lines.join("\n");
}

async function askAgreement(ctx, session) {
  session.step = "agreement";
  await db.setSession(ctx.chatId, ctx.platform, session);
  await ctx.reply(summaryText(session), {
    buttons: [
      { id: "agree:yes", text: "✅ Saya Setuju" },
      { id: "agree:no",  text: "❌ Batalkan" },
    ],
  });
}

// ==============================================
// LEGACY MENU (WhatsApp fallback)
// ==============================================
async function showWelcome(ctx) {
  await ctx.reply(banner.welcome, { image: mediaOr(images.welcome()) });
}
async function showMainMenu(ctx) {
  const btns = [];
  for (const s of servers()) btns.push({ id: `panel:${s.key}`, text: `🖥️ ${s.name}` });
  btns.push({ id: `bimz:menu`, text: `📱 BimzCreated (APK CPanel)` });
  btns.push({ id: `apk:menu`, text: `🐛 APK BUG` });
  btns.push({ id: `bonus:claim`, text: `🎁 Bonus Harian` });
  btns.push({ id: `profil`, text: `👤 Profil` });
  btns.push({ id: `myorders`, text: `📦 Riwayat Order` });
  await ctx.reply(`${banner.menuHeader}\n\nPilih layanan:`, { buttons: btns });
}
async function showPanelRoles(ctx, serverKey) {
  const s = servers().find((x) => x.key === serverKey);
  if (!s) return ctx.reply("Server tidak ditemukan.");
  const roles = Object.keys(pricesCfg[serverKey] || {});
  const labelMap = { user: "Paket Basic", reseller: "Paket Pro", owner: "Paket Elite" };
  await ctx.reply(`ORDER BY ${s.name.toUpperCase()}\nPilih paket:`, {
    buttons: roles.map((r) => ({ id: `role:${serverKey}:${r}`, text: labelMap[r] || r })),
  });
}
async function showPanelSizes(ctx, serverKey, role) {
  const table = pricesCfg[serverKey]?.[role];
  if (!table) return ctx.reply("Harga tidak tersedia.");
  const btns = SIZES.filter((s) => table[s] != null).map((s) => ({
    id: `size:${serverKey}:${role}:${s}`,
    text: `${s === "unlimited" ? "UNLIMITED" : s + " GB"} — ${rupiah(table[s])}`,
  }));
  await ctx.reply(`Paket — ${serverKey.toUpperCase()}:`, { buttons: btns });
}

// ==============================================
// FORM STEP HANDLER
// ==============================================
async function askForm(ctx, session, key, prompt) {
  session.step = "form";
  session.formKey = key;
  await db.setSession(ctx.chatId, ctx.platform, session);
  await ctx.reply(prompt);
}

async function beginForm(ctx, session) {
  const form = formFor(session.type);
  session.form = {};
  return askForm(ctx, session, form[0].key, form[0].prompt);
}

// ==============================================
// PAYMENT
// ==============================================
async function askPaymentMethod(ctx, session) {
  const methods = invoiceSvc.activeMethods();
  session.step = "choose_payment";
  await db.setSession(ctx.chatId, ctx.platform, session);
  const bal = db.getBalance(ctx.chatId, ctx.platform);
  await ctx.reply(
    `💳 Pilih metode pembayaran:\n(Saldo Anda: *${rupiah(bal)}*)`,
    { buttons: methods.map((m) => ({ id: `pay:${m.key}`, text: m.label })) }
  );
}

async function issueInvoice(ctx, session, method) {
  let order, amount;
  if (session.type === "panel") {
    amount = orderSvc.panelPrice(session.serverKey, session.role, session.size);
    if (!amount) return ctx.reply("❌ Harga tidak ditemukan.");
    order = orderSvc.newOrder({
      chatId: ctx.chatId, platform: ctx.platform, type: "panel",
      serverKey: session.serverKey, role: session.role, size: session.size,
      amount, customer: session.form,
    });
  } else if (session.type === "bimz") {
    const p = bimzCfg.packages[session.bimzRole];
    if (!p) return ctx.reply("❌ Paket BimzCreated tidak ditemukan.");
    amount = p.price;
    order = orderSvc.newOrder({
      chatId: ctx.chatId, platform: ctx.platform, type: "bimz",
      role: session.bimzRole, amount, customer: session.form,
    });
    db.createBimzOrder({
      id: order.id, invoiceId: null,
      chatId: ctx.chatId, platform: ctx.platform,
      role: session.bimzRole, price: amount, customer: session.form,
      status: "awaiting_payment",
    });
  } else {
    return ctx.reply("❌ Tipe order tidak dikenal untuk pembayaran.");
  }

  // ==== BAYAR PAKAI SALDO ====
  if (method === "saldo") {
    const bal = db.getBalance(ctx.chatId, ctx.platform);
    if (bal < amount) {
      db.updateOrder(order.id, { status: "failed" });
      await db.setSession(ctx.chatId, ctx.platform, null);
      return ctx.reply(
        `❌ Saldo Anda tidak mencukupi.\n` +
        `Saldo saat ini: *${rupiah(bal)}*\n` +
        `Dibutuhkan   : *${rupiah(amount)}*\n\n` +
        `Silakan lakukan Top Up atau klaim *Bonus Harian*.`
      );
    }
    const inv = invoiceSvc.createInvoice({
      orderId: order.id, chatId: ctx.chatId, platform: ctx.platform,
      amount, method: "saldo",
    });
    db.raw.prepare(`UPDATE orders SET invoice_id=? WHERE id=?`).run(inv.id, order.id);
    db.addBalance({
      chatId: ctx.chatId, platform: ctx.platform, amount: -amount,
      type: "debit_order", note: `Order ${order.id}`,
    });
    db.markInvoicePaid(inv.id);
    verifier.recordPayment({
      invoice: inv, reportedAmount: amount, reference: "SALDO",
      imageBuffer: null, status: "valid",
    });
    await ctx.reply(`✅ Pembayaran menggunakan saldo berhasil. Memproses order...`);
    return deliverOrder(ctx, order.id);
  }

  // ==== METODE MANUAL ====
  const inv = invoiceSvc.createInvoice({
    orderId: order.id, chatId: ctx.chatId, platform: ctx.platform,
    amount, method,
  });
  db.raw.prepare(`UPDATE orders SET invoice_id=? WHERE id=?`).run(inv.id, order.id);

  const instr = invoiceSvc.paymentInstruction(method, amount);
  if (!instr) return ctx.reply("❌ Metode pembayaran tidak tersedia.");
  const card = invoiceSvc.invoiceCard({ ...inv });
  const imgPath = method === "qris" ? mediaOr(images.qris()) : (instr.image ? mediaOr(path.join(__dirname, "..", instr.image)) : null);
  await ctx.reply(`${card}\n\n${instr.text}`, { image: imgPath });
  await ctx.reply(
    "Setelah transfer, ketik:\n" +
    "*bayar <nominal> <ref>*\n" +
    "contoh: *bayar 1500 A1B2*\n\n" +
    "Lalu kirim FOTO bukti transfer yang JELAS.\n\n" +
    `⚠️ Verifikasi ketat OCR aktif. Bot akan membaca isi bukti pembayaran. ` +
    `Pastikan bukti asli, status *Berhasil/Selesai*, dengan merchant *${paymentCfg.merchantName}*.`
  );
  session.step = "await_payment";
  session.invoiceId = inv.id;
  session.orderId = order.id;
  await db.setSession(ctx.chatId, ctx.platform, session);
}

async function processPayment(ctx, session, reportedAmount, reference) {
  session.reportedAmount = reportedAmount;
  session.reference = reference;
  session.step = "await_proof";
  await db.setSession(ctx.chatId, ctx.platform, session);
  await ctx.reply(
    `Diterima:\n• Nominal: ${rupiah(reportedAmount)}\n• Ref    : ${reference}\n\n` +
    `Sekarang kirim FOTO bukti transfer.`
  );
}

async function verifyProof(ctx, session) {
  const check = await verifier.verify({
    invoiceId: session.invoiceId,
    reportedAmount: session.reportedAmount,
    reference: session.reference,
    imageBuffer: ctx.imageBuffer,
    chatId: ctx.chatId,
  });
  if (!check.ok) {
    const invStub = { id: session.invoiceId, amount: session.reportedAmount || 0, method: "?", status: "pending" };
    const cur = db.getInvoice(session.invoiceId); if (cur) { invStub.status = cur.status; invStub.method = cur.method; invStub.amount = cur.amount; }
    const info = verifier.recordPayment({
      invoice: invStub,
      reportedAmount: session.reportedAmount,
      reference: session.reference,
      imageBuffer: ctx.imageBuffer,
      status: "invalid",
      reason: check.reason,
    });
    if (info.rejected) {
      await db.setSession(ctx.chatId, ctx.platform, null);
      return ctx.reply(
        `❌ *PEMBAYARAN DITOLAK PERMANEN*\n` +
        `Alasan: ${check.reason}\n` +
        `Percobaan gagal: ${info.attempts}/${info.max}\n\n` +
        `Invoice ini ditutup. Silakan buat order baru.\n\n` +
        `⚠️ Panel TIDAK dibuat, saldo TIDAK bertambah, produk TIDAK dikirim.`
      );
    }
    return ctx.reply(
      `❌ *VERIFIKASI GAGAL*\n` +
      `Alasan: ${check.reason}\n` +
      `Percobaan: ${info.attempts}/${info.max}\n\n` +
      `Silakan kirim ulang bukti *yang benar dan sesuai invoice*, atau ketik *batal*.\n` +
      `Invoice tetap *PENDING*.`
    );
  }
  const inv = check.invoice;
  db.markInvoicePaid(inv.id);
  verifier.recordPayment({
    invoice: inv,
    reportedAmount: session.reportedAmount,
    reference: session.reference,
    imageBuffer: ctx.imageBuffer,
    status: "valid",
  });
  await ctx.reply("✅ Pembayaran valid! Memproses order...");
  await deliverOrder(ctx, inv.order_id);
  await db.setSession(ctx.chatId, ctx.platform, null);
}

// ==============================================
// DELIVER
// ==============================================
function bimzAdminButtons() {
  return [
    { id: `link:wa:${contactCfg.bimzcreated.whatsapp}`, text: "📲 WhatsApp Admin", url: contactCfg.waLink(contactCfg.bimzcreated.whatsapp, "Halo Admin, saya baru order BimzCreated") },
    { id: `link:tg:${contactCfg.bimzcreated.telegramUsername}`, text: "📩 Telegram Admin", url: contactCfg.tgLink(contactCfg.bimzcreated.telegramUsername) },
  ];
}
function yanzzButtons(order) {
  const prefill = `Halo Yanzz, saya order APK BUG (order ${order?.id || ""}).`;
  return [
    { id: `link:wa:${contactCfg.apkBug.whatsapp}`, text: "📲 WhatsApp Yanzz", url: contactCfg.waLink(contactCfg.apkBug.whatsapp, prefill) },
    { id: `link:tg:${contactCfg.apkBug.telegramUsername}`, text: "📩 Telegram Yanzz", url: contactCfg.tgLink(contactCfg.apkBug.telegramUsername) },
  ];
}

async function deliverOrder(ctx, orderId) {
  const order = db.getOrder(orderId);
  if (!order) return ctx.reply("❌ Order tidak ditemukan.");

  if (order.type === "panel") {
    try {
      const info = await orderSvc.fulfillPanel(order);
      db.incrementOrderCount(ctx.chatId, ctx.platform);
      // Kirim foto panel.jpg dulu, lalu detail
      const panelImg = mediaOr(images.panel());
      if (panelImg) await ctx.reply("🎉 *Panel Berhasil Dibuat!*", { image: panelImg });
      return ctx.reply(orderSvc.formatPanelDelivery(info));
    } catch (e) {
      db.updateOrder(order.id, { status: "failed" });
      logger.error("fulfillPanel error:", e.message);
      return ctx.reply(`❌ Gagal membuat panel: ${e.message}\nHubungi admin: ${contactCfg.owner.whatsapp}`);
    }
  }

  if (order.type === "bimz") {
    const p = bimzCfg.packages[order.role];
    db.updateOrder(order.id, { status: "delivered" });
    db.markBimzDelivered(order.id);
    db.incrementOrderCount(ctx.chatId, ctx.platform);
    const bimzImg = mediaOr(images.bimzcreated());
    if (bimzImg) await ctx.reply("📱 *BimzCreated Order*", { image: bimzImg });
    await ctx.reply(
      `✅ *ORDER BIMZCREATED (APK CPANEL) BERHASIL*\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `Order ID   : ${order.id}\n` +
      `Role       : ${p.label}\n` +
      `Harga      : ${rupiah(p.price)}\n` +
      `Masa Aktif : ${p.masaAktif}\n` +
      `Limit      : ${p.limit}\n` +
      `Username   : ${order.customer?.bimzUsername}\n` +
      `Password   : ${order.customer?.bimzPassword}\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `Silakan hubungi admin untuk aktivasi akun Anda.`,
      { buttons: bimzAdminButtons() }
    );
    if (ctx.notifyAdmin) await ctx.notifyAdmin(
      `🆕 BimzCreated order ${order.id}\nRole: ${order.role}\nUser: ${order.customer?.name}\n` +
      `Username Akun: ${order.customer?.bimzUsername}\nPassword Akun: ${order.customer?.bimzPassword}\n` +
      `WA: ${order.customer?.whatsapp}\nEmail: ${order.customer?.email}`
    );
    return;
  }

  // APK BUG delivered path (dipanggil dari agreement, TANPA pembayaran)
  db.updateOrder(order.id, { status: "delivered" });
  db.incrementOrderCount(ctx.chatId, ctx.platform);
  const apkImg = mediaOr(images.apkbug());
  if (apkImg) await ctx.reply("🐛 *Order APK BUG*", { image: apkImg });
  await ctx.reply(
    `✅ *FORMULIR APK BUG DITERIMA*\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `Order ID    : ${order.id}\n` +
    `Nama        : ${order.customer?.name}\n` +
    `Username APK: ${order.customer?.apkUsername}\n` +
    `Password APK: ${order.customer?.apkPassword}\n` +
    `WhatsApp    : ${order.customer?.whatsapp}\n` +
    `━━━━━━━━━━━━━━━━━━\n\n` +
    `APK BUG tidak menggunakan pembayaran otomatis.\n` +
    `Silakan lanjutkan pembayaran & konfirmasi langsung ke *${contactCfg.apkBug.name}*:`,
    { buttons: yanzzButtons(order) }
  );
  if (ctx.notifyAdmin) await ctx.notifyAdmin(
    `🆕 APK BUG order ${order.id}\nNama: ${order.customer?.name}\n` +
    `Username APK: ${order.customer?.apkUsername}\nPassword APK: ${order.customer?.apkPassword}\n` +
    `WA: ${order.customer?.whatsapp}\nPaket: ${order.customer?._apkPaket || "-"}`
  );
}

// ==============================================
// Bonus & Profil
// ==============================================
function bonusStatus(chatId, platform) {
  if (bonusCfg.enabled === false || bonusCfg.enable === false) return { canClaim: false, reason: "Fitur bonus dinonaktifkan." };
  const last = db.lastBonusClaim(chatId, platform);
  const cd = (bonusCfg.cooldownHours || bonusCfg.cooldown || 24) * 3600_000;
  if (!last) return { canClaim: true, remainingMs: 0 };
  const remaining = (last.claimed_at + cd) - Date.now();
  if (remaining <= 0) return { canClaim: true, remainingMs: 0, last };
  return { canClaim: false, remainingMs: remaining, last };
}
function fmtRemaining(ms) {
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  return `${h} Jam ${m} Menit`;
}
async function claimBonus(ctx) {
  const st = bonusStatus(ctx.chatId, ctx.platform);
  if (!st.canClaim) {
    if (st.reason) return ctx.reply(`ℹ️ ${st.reason}`);
    return ctx.reply(`⏳ Anda sudah klaim bonus.\nSilakan kembali dalam:\n*${fmtRemaining(st.remainingMs)}*`);
  }
  db.recordBonusClaim({ chatId: ctx.chatId, platform: ctx.platform, amount: bonusCfg.amount });
  const newBal = db.addBalance({
    chatId: ctx.chatId, platform: ctx.platform,
    amount: bonusCfg.amount, type: "credit_bonus", note: "Bonus Harian",
  });
  const msg = (bonusCfg.message || "Bonus diklaim: {amount}. Saldo: {balance}.")
    .replace("{amount}", rupiah(bonusCfg.amount))
    .replace("{balance}", rupiah(newBal));
  return ctx.reply(`🎁 *BONUS HARIAN*\n\n${msg}`);
}

async function showProfile(ctx) {
  const u = db.getUser(ctx.chatId, ctx.platform) || {};
  const st = bonusStatus(ctx.chatId, ctx.platform);
  const claimStatus = st.canClaim ? "✅ Dapat diklaim sekarang" : `⏳ ${fmtRemaining(st.remainingMs)}`;
  await ctx.reply(
    `👤 *PROFIL*\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `Nama         : ${u.name || "-"}\n` +
    `Username     : ${u.username || "-"}\n` +
    `Status       : ${u.role || "user"}\n` +
    `Saldo        : *${rupiah(u.balance || 0)}*\n` +
    `Bergabung    : ${u.created_at ? fmtDate(u.created_at) : "-"}\n` +
    `Total Order  : ${u.total_order || 0}\n` +
    `Bonus Harian : ${rupiah(bonusCfg.amount)} / ${bonusCfg.cooldownHours || bonusCfg.cooldown}j\n` +
    `Status Claim : ${claimStatus}\n` +
    `━━━━━━━━━━━━━━━━━━`
  );
}

// ==============================================
// MESSAGE HANDLER
// ==============================================
async function handleMessage(ctx) {
  const text = (ctx.text || "").trim();
  const lower = text.toLowerCase();

  const rl = rateLimit.check(ctx.chatId);
  if (!rl.allowed) return;

  if (ctx.isAdmin && text.startsWith(require("../config/settings").admin.prefix)) {
    return adminHandler.handle(ctx, text);
  }

  let session = db.getSession(ctx.chatId) || { step: "idle" };

  // Dispatch callback ke ModeAI / FileBotBuild bila prefix cocok
  if (ctx.callbackData) {
    const cb0 = ctx.callbackData;
    if (cb0.startsWith("ai:"))  return aiHandler.handleCallback(ctx, cb0, session);
    if (cb0.startsWith("fbb:")) return fbbHandler.handleCallback(ctx, cb0, session);
    if (cb0.startsWith("admin:setfitur:")) {
      if (!ctx.isAdmin) return ctx.reply("❌ Akses ditolak.");
      const presetId = cb0.split(":")[2];
      const o = adminHandler.loadOverrides();
      o.menu = o.menu || {};
      o.menu.activePreset = Number(presetId);
      adminHandler.saveOverrides(o);
      adminHandler.reload(ctx);
      // Tampilkan menu baru langsung
      return showMainMenu(ctx);
    }
    if (cb0 === "m:report") {
      session.step = "report:input";
      await db.setSession(ctx.chatId, ctx.platform, session);
      return ctx.reply(
        "🚨 *MODE LAPORAN*\n\n" +
        "Silakan tuliskan laporan Anda (Bug, Error, Kritik, Saran, dll).\n" +
        "Laporan akan langsung diteruskan ke Admin.",
        { buttons: [{ id: "report:exit", text: "❌ Keluar Mode Laporan" }] }
      );
    }
    if (cb0 === "report:exit") {
      session.step = "idle";
      await db.setSession(ctx.chatId, ctx.platform, session);
      return showMainMenu(ctx);
    }
  }

  if (/^batal$|^cancel$/i.test(lower)) {
    await db.setSession(ctx.chatId, ctx.platform, null);
    return ctx.reply("Order dibatalkan. Ketik *menu* untuk mulai lagi.");
  }
  if (/^status$/i.test(lower)) return showMyOrders(ctx);
  if (/^bonus$|^daily$|^klaim$/i.test(lower)) return claimBonus(ctx);
  if (/^profil$|^profile$|^saldo$/i.test(lower)) return showProfile(ctx);

  // ModeAI / FileBotBuild text handling
  if (session.step === "ai:chat")   return aiHandler.handleChat(ctx, session);
  if (session.step === "fbb:describe") return fbbHandler.confirmIdea(ctx, session);
  if (session.step === "report:input") {
    if (/^batal$|^cancel$|^exit$/i.test(lower)) {
      session.step = "idle";
      await db.setSession(ctx.chatId, ctx.platform, session);
      return showMainMenu(ctx);
    }
    
    // Kirim laporan ke admin
    const reportMsg = `🚨 *LAPORAN BARU*\n\n` +
      `Dari: ${ctx.chatId} (@${ctx.userJid})\n` +
      `Platform: ${ctx.platform}\n` +
      `Isi Laporan:\n${text}`;
      
    await ctx.notifyAdmin(reportMsg);

    session.step = "idle";
    await db.setSession(ctx.chatId, ctx.platform, session);
    await ctx.reply("✅ Laporan Anda telah terkirim. Terima kasih!");
    return showMainMenu(ctx);
  }

  const cb = ctx.callbackData;
  if (cb) return handleCallback(ctx, cb, session);

  if (session.step === "await_payment") {
    const m = lower.match(/^bayar\s+(\d[\d.,]*)\s+([a-z0-9]{4,})/i);
    if (m) {
      const amount = Number(m[1].replace(/[.,]/g, ""));
      const ref = m[2];
      return processPayment(ctx, session, amount, ref);
    }
    return ctx.reply("Ketik *bayar <nominal> <ref>*\ncontoh: bayar 1500 A1B2");
  }
  if (session.step === "await_proof") {
    if (ctx.isImage) return verifyProof(ctx, session);
    return ctx.reply("📸 Silakan kirim FOTO bukti transfer.");
  }
  if (session.step === "form") {
    session.form = session.form || {};
    const form = formFor(session.type);
    const idx = form.findIndex((f) => f.key === session.formKey);
    const cur = form[idx];
    const err = validate(cur.key, text);
    if (err) return ctx.reply(`❌ ${err}`);
    session.form[cur.key] = text.trim();

    // Simpan ke user (hanya field profil dasar)
    if (["name", "username", "email", "whatsapp"].includes(cur.key)) {
      db.upsertUser({
        platform: ctx.platform, chatId: ctx.chatId, jid: ctx.userJid,
        [cur.key]: text.trim(),
      });
    }
    const next = form[idx + 1];
    if (next) return askForm(ctx, session, next.key, next.prompt);
    // Form selesai → tampilkan ringkasan + persetujuan
    return askAgreement(ctx, session);
  }

  if (/^(halo|hai|hi|p|menu|order|beli|start|\/start)$/i.test(lower) || session.step === "idle") {
    if (session.step === "idle") {
      await showWelcome(ctx);
      return showMainMenu(ctx);
    }
  }
  await ctx.reply("Ketik *menu* untuk mulai order.");
}

async function handleCallback(ctx, cb, session) {
  if (cb === "myorders") return showMyOrders(ctx);
  if (cb === "profil") return showProfile(ctx);
  if (cb === "bonus:claim") return claimBonus(ctx);

  // AGREEMENT
  if (cb === "agree:no") {
    await db.setSession(ctx.chatId, ctx.platform, null);
    return ctx.reply("❌ Order dibatalkan. Ketik *menu* untuk mulai lagi.");
  }
  if (cb === "agree:yes") {
    if (!session || session.step !== "agreement") return ctx.reply("Sesi tidak ditemukan. Ketik *menu*.");
    // APK BUG: tanpa payment → langsung deliver + kontak Yanzz
    if (session.type === "apk") {
      const f = orderSvc.apkPrice(session.itemId);
      if (!f) { await db.setSession(ctx.chatId, ctx.platform, null); return ctx.reply("Paket tidak ditemukan."); }
      const cust = { ...session.form, _apkPaket: f.item.name };
      const order = orderSvc.newOrder({
        chatId: ctx.chatId, platform: ctx.platform, type: "apk",
        amount: f.item.price, customer: cust,
      });
      // langsung mark delivered (form-only, tanpa pembayaran)
      await deliverOrder(ctx, order.id);
      return db.setSession(ctx.chatId, ctx.platform, null);
    }
    // Panel / Bimz → lanjut ke pilih metode pembayaran
    return askPaymentMethod(ctx, session);
  }

  if (cb.startsWith("panel:")) {
    const key = cb.split(":")[1];
    // Sederhanakan: Langsung ke paket BASIC
    return showPanelSizes(ctx, key, "user"); 
  }
  if (cb.startsWith("role:")) {
    const [, key, role] = cb.split(":");
    return showPanelSizes(ctx, key, role);
  }
  if (cb.startsWith("size:")) {
    const [, key, role, size] = cb.split(":");
    
    // Analyzer check before order
    const server = panelCfg.servers.find(s => s.key === key);
    if (server) {
      await ctx.reply("🔍 *Menganalisis status panel...*");
      const status = await analyzer.analyze(server);
      if (!status.online || !status.apiValid) {
        return ctx.reply(
          `❌ *PANEL SEDANG OFFLINE*\n\n` +
          `Server Panel *${server.name}* sedang tidak dapat digunakan.\n` +
          `Status: ${status.status}\n` +
          `Error: ${status.error || "API Failure"}\n\n` +
          `Silakan coba kembali nanti.`
        );
      }
    }

    session = { step: "form", type: "panel", serverKey: key, role, size, form: {} };
    await db.setSession(ctx.chatId, ctx.platform, session);
    return beginForm(ctx, session);
  }
  if (cb === "apk:menu") {
    const cat = productsCfg.categories[0];
    return ctx.reply(`🐛 Pilih paket APK BUG:`, {
      buttons: cat.items.map((i) => ({ id: `apkitem:${i.id}`, text: `${i.name} — ${rupiah(i.price)}` })),
    });
  }
  if (cb.startsWith("apkitem:")) {
    const id = cb.split(":")[1];
    const f = orderSvc.apkPrice(id);
    if (!f) return ctx.reply("Produk tidak ditemukan.");
    session = { step: "form", type: "apk", itemId: id, form: {} };
    await db.setSession(ctx.chatId, ctx.platform, session);
    return beginForm(ctx, session);
  }
  if (cb === "bimz:menu") {
    const btns = Object.entries(bimzCfg.packages).map(([k, p]) =>
      ({ id: `bimzpkg:${k}`, text: `${p.label} — ${rupiah(p.price)}` })
    );
    return ctx.reply(`📱 *BimzCreated (APK CPanel)*\n${bimzCfg.description}`, { buttons: btns });
  }
  if (cb.startsWith("bimzpkg:")) {
    const role = cb.split(":")[1];
    const p = bimzCfg.packages[role];
    if (!p) return ctx.reply("Paket tidak ditemukan.");
    await ctx.reply(
      `📱 *BimzCreated (APK CPanel) — ${p.label}*\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `Harga     : *${rupiah(p.price)}*\n` +
      `Masa Aktif: ${p.masaAktif}\n` +
      `Limit     : ${p.limit}\n` +
      `Fitur     :\n• ${p.features.join("\n• ")}\n` +
      `Info      : ${p.info}\n` +
      `⚠️ ${p.warning}\n` +
      `━━━━━━━━━━━━━━━━━━`,
      { buttons: [{ id: `bimzbuy:${role}`, text: `🛒 Beli Sekarang — ${rupiah(p.price)}` }] }
    );
    return;
  }
  if (cb.startsWith("bimzbuy:")) {
    const role = cb.split(":")[1];
    if (!bimzCfg.packages[role]) return ctx.reply("Paket tidak ditemukan.");

    // Analyzer check for BimzCreated (assuming it uses the 'bimz' server key or similar)
    const server = panelCfg.servers.find(s => s.key === "bimz" || s.key === "main");
    if (server) {
      await ctx.reply("🔍 *Menganalisis status panel BimzCreated...*");
      const status = await analyzer.analyze(server);
      if (!status.online || !status.apiValid) {
        return ctx.reply(
          `❌ *PANEL BIMZCREATED OFFLINE*\n\n` +
          `Server sedang tidak dapat digunakan untuk pembelian role.\n` +
          `Silakan coba kembali nanti.`
        );
      }
    }

    session = { step: "form", type: "bimz", bimzRole: role, form: {} };
    await db.setSession(ctx.chatId, ctx.platform, session);
    return beginForm(ctx, session);
  }
  if (cb.startsWith("pay:")) {
    const method = cb.split(":")[1];
    return issueInvoice(ctx, session, method);
  }
}

async function showMyOrders(ctx) {
  const rows = db.ordersByChat(ctx.chatId, 10);
  if (!rows.length) return ctx.reply("Belum ada order.");
  const lines = rows.map((r) =>
    `• ${r.id} — ${r.type.toUpperCase()} — ${rupiah(r.amount)} — ${r.status.toUpperCase()}` +
    (r.expired_at ? `\n  expired: ${fmtDate(r.expired_at)}` : "")
  );
  return ctx.reply("📦 *Order Anda*\n\n" + lines.join("\n"));
}

module.exports = { handleMessage, claimBonus, showProfile, beginForm, askAgreement };
