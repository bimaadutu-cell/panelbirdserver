// ==============================================
// HANDLER MODEAI (V3.3)
// ==============================================
// State session: { step: "ai:pick" } → user memilih model
//                { step: "ai:chat", model: "gemini"|"lovable"|"chatgpt" }
// Callback data:
//   ai:open              → tampilkan pemilih model
//   ai:pick:<model>      → set model, mulai chat
//   ai:change            → kembali ke pemilih model
//   ai:reset             → reset memory
//   ai:exit              → keluar dari ModeAI
// ==============================================
const db = require("../database/db");
const images = require("../config/images");
const aiCfg = require("../config/ai");
const modelsCfg = require("../config/models");
const aiRouter = require("../services/ai");
const aiSession = require("../services/ai/session");

function mediaOr(p) { const fs = require("fs"); return p && fs.existsSync(p) ? p : null; }

function modelPickerButtons() {
  const keys = ["gemini", "chatgpt", "lovable"];
  const btns = keys.map((k) => {
    const st = aiRouter.status(k);
    const suffix = st.ok ? "" : (st.reason === aiCfg.ui.comingSoon ? " (Akan Hadir)" : " ⚠️");
    return { id: `ai:pick:${k}`, text: `${aiRouter.labelOf(k)}${suffix}` };
  });
  btns.push({ id: "m:home", text: "⬅ Keluar" });
  return btns;
}

function chatControls() {
  return [
    { id: "ai:change", text: "🔄 Ganti Model" },
    { id: "ai:reset",  text: "🗑 Reset Chat" },
    { id: "ai:exit",   text: "🚪 Keluar ModeAI" },
  ];
}

async function openPicker(ctx) {
  await db.setSession(ctx.chatId, ctx.platform, { step: "ai:pick" });
  const img = mediaOr(images.banner());
  const txt =
    `🧠 *MODE AI — Pilih Model*\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `• Gemini    : Chat AI Google Gemini\n` +
    `• ChatGPT   : (Akan Hadir)\n` +
    `• Lovable AI: Chat AI berbasis Lovable Gateway\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `Silakan pilih model yang ingin digunakan.`;
  return ctx.reply(txt, { buttons: modelPickerButtons(), image: img });
}

async function pickModel(ctx, modelKey) {
  const st = aiRouter.status(modelKey);
  if (!st.ok) {
    await ctx.reply(`⚠️ ${aiRouter.labelOf(modelKey)} — ${st.reason}`);
    return openPicker(ctx);
  }
  aiSession.set(ctx.platform, ctx.chatId, { model: modelKey });
  await db.setSession(ctx.chatId, ctx.platform, { step: "ai:chat", model: modelKey });
  return ctx.reply(
    `✅ *ModeAI Aktif — ${aiRouter.labelOf(modelKey)}*\n\n` +
    `Silakan tulis pertanyaan atau perintah apapun.\n` +
    `Bot akan menjawab langsung dari AI dengan memory percakapan.\n\n` +
    `Gunakan tombol di bawah untuk kontrol.`,
    { buttons: chatControls() },
  );
}

async function resetMemory(ctx) {
  aiSession.reset(ctx.platform, ctx.chatId);
  return ctx.reply("🗑 *Memory percakapan direset.*\nSilakan lanjut chat.", { buttons: chatControls() });
}

async function exitMode(ctx) {
  aiSession.clear(ctx.platform, ctx.chatId);
  await db.setSession(ctx.chatId, ctx.platform, null);
  return ctx.reply("🚪 *Keluar dari ModeAI.*\nKetik *menu* untuk kembali ke Menu Utama.");
}

function chunk(text, size) {
  const out = []; let i = 0;
  while (i < text.length) { out.push(text.slice(i, i + size)); i += size; }
  return out;
}

async function handleChat(ctx, session) {
  const modelKey = session.model;
  const text = (ctx.text || "").trim();
  if (!text) return ctx.reply("Kirim pertanyaan berupa teks.");
  const mem = aiSession.get(ctx.platform, ctx.chatId) || aiSession.set(ctx.platform, ctx.chatId, { model: modelKey });
  aiSession.push(ctx.platform, ctx.chatId, "user", text);
  await ctx.reply(aiCfg.ui.thinkingText);
  try {
    const history = (aiSession.get(ctx.platform, ctx.chatId) || {}).history || [];
    const result = await aiRouter.chat({ modelKey, history });
    const responseText = typeof result === "string" ? result : (result.text || "");
    aiSession.push(ctx.platform, ctx.chatId, "assistant", responseText);
    const max = aiCfg.maxResponseChars || 3800;
    const parts = chunk(responseText, max);
    for (let i = 0; i < parts.length; i++) {
      const isLast = i === parts.length - 1;
      await ctx.reply(parts[i], isLast ? { buttons: chatControls() } : {});
    }
  } catch (e) {
    await ctx.reply(`❌ ${e.message}`, { buttons: chatControls() });
  }
}

async function handleCallback(ctx, cb, session) {
  if (cb === "ai:open")   return openPicker(ctx);
  if (cb === "ai:change") return openPicker(ctx);
  if (cb === "ai:reset")  return resetMemory(ctx);
  if (cb === "ai:exit")   return exitMode(ctx);
  if (cb.startsWith("ai:pick:")) return pickModel(ctx, cb.split(":")[2]);
  return false;
}

module.exports = { openPicker, handleChat, handleCallback };
