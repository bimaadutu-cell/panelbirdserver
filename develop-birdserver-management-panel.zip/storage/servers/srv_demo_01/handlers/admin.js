// Menu admin: kelola produk/harga/server/banner/broadcast/pengumuman/backup/restore.
// Config disimpan sebagai file JS. Perubahan runtime disimpan sebagai overlay JSON
// di config/_overrides.json, di-merge saat reload.
const fs = require("fs");
const path = require("path");
const db = require("../database/db");
const panelSvc = require("../services/panel/pterodactyl");
const logger = require("../utils/logger");
const store = require("../config/store");

const OVERRIDE_FILE = path.join(__dirname, "..", "config", "_overrides.json");
function loadOverrides() {
  try { return JSON.parse(fs.readFileSync(OVERRIDE_FILE, "utf8")); } catch { return {}; }
}
function saveOverrides(o) { fs.writeFileSync(OVERRIDE_FILE, JSON.stringify(o, null, 2)); }

const HELP = `🛠️ *ADMIN MENU*
/help                — bantuan
/reload              — reload config
/status              — cek status semua server panel
/setfitur            — ganti tampilan menu utama
/discover <serverKey>— refresh meta panel (node/nest/egg/loc)
/servers             — daftar server
/addserver <key> <name> <url> <ptla>
/delserver <key>
/setprice <serverKey> <role> <sizeOrUnlimited> <hargaRupiah>
/setpayment <method> <field> <value>   (contoh: /setpayment dana number 08123)
/setstore <field> <value>              (contoh: /setstore name "TOKO BARU")
/announce <text>
/broadcast <text>
/backup              — backup config ke file
/restore             — instruksi restore
/expire              — jalankan auto-delete manual`;

async function handle(ctx, text) {
  const [cmd, ...rest] = text.slice(1).split(/\s+/);
  const args = rest.join(" ");
  try {
    switch (cmd.toLowerCase()) {
      case "help": case "menu": return ctx.reply(HELP);
      case "status": return statusAll(ctx);
      case "setfitur": return setFitur(ctx);
      case "servers": return listServers(ctx);
      case "discover": return discover(ctx, rest[0]);
      case "addserver": return addServer(ctx, rest);
      case "delserver": return delServer(ctx, rest[0]);
      case "setprice": return setPrice(ctx, rest);
      case "setpayment": return setPayment(ctx, rest);
      case "setstore": return setStore(ctx, rest);
      case "announce": return announce(ctx, args);
      case "broadcast": return broadcast(ctx, args);
      case "reload": return reload(ctx);
      case "backup": return backup(ctx);
      case "restore": return ctx.reply("Restore: replace config/_overrides.json dengan file backup, lalu /reload.");
      case "expire": return manualExpire(ctx);
      case "setbonus": return setBonus(ctx, rest);
      case "setbimzprice": return setBimzPrice(ctx, rest);
      case "addbalance": return addBalance(ctx, rest);
      default: return ctx.reply(`❓ Command tidak dikenal. Ketik /help.`);
    }
  } catch (e) {
    logger.error("admin cmd error:", e.message);
    return ctx.reply(`❌ Error: ${e.message}`);
  }
}

async function statusAll(ctx) {
  const panelCfg = reloadRequire("../config/panel");
  const rows = await Promise.all(panelCfg.servers.map((s) => panelSvc.serverStatus(s)));
  const lines = rows.map((r) =>
    `${r.status === "ONLINE" ? "🟢" : "🔴"} ${r.name} (${r.key})\n  URL: ${r.url}\n  Ping: ${r.ping}ms  API: ${r.apiOk ? "OK" : "FAIL"}`);
  await ctx.reply("📡 *STATUS SERVER*\n\n" + lines.join("\n\n"));
}

function listServers(ctx) {
  const panelCfg = reloadRequire("../config/panel");
  const lines = panelCfg.servers.map((s) => `• ${s.key} — ${s.name} — ${s.url}`);
  return ctx.reply("🖥️ *SERVER*\n\n" + (lines.join("\n") || "(kosong)"));
}

async function discover(ctx, key) {
  const panelCfg = reloadRequire("../config/panel");
  const s = panelCfg.servers.find((x) => x.key === key);
  if (!s) return ctx.reply(`Server ${key} tidak ada.`);
  const meta = await panelSvc.discoverMeta(s, { force: true });
  return ctx.reply(`✅ Meta ${key} diperbarui:\nNodes: ${meta.nodes.length}\nNests: ${meta.nests.length}\nEggs: ${meta.eggs.length}\nLocations: ${meta.locations.length}`);
}

function addServer(ctx, rest) {
  const [key, name, url, ptla] = rest;
  if (!key || !name || !url || !ptla) return ctx.reply("Format: /addserver <key> <name> <url> <ptla>");
  const o = loadOverrides();
  o.panel = o.panel || { servers: [] };
  o.panel.servers = (o.panel.servers || []).filter((s) => s.key !== key);
  o.panel.servers.push({ key, name, url, ptla, defaults: {} });
  saveOverrides(o);
  reload(ctx);
  return ctx.reply(`✅ Server ${key} ditambahkan. Jalankan /discover ${key}.`);
}

function delServer(ctx, key) {
  const o = loadOverrides();
  if (!o.panel?.servers) return ctx.reply("Tidak ada override.");
  o.panel.servers = o.panel.servers.filter((s) => s.key !== key);
  saveOverrides(o); reload(ctx);
  return ctx.reply(`✅ Server ${key} dihapus dari override.`);
}

function setPrice(ctx, rest) {
  const [key, role, size, price] = rest;
  if (!key || !role || !size || !price) return ctx.reply("Format: /setprice <serverKey> <role> <sizeOrUnlimited> <harga>");
  const o = loadOverrides();
  o.prices = o.prices || {};
  o.prices[key] = o.prices[key] || {};
  o.prices[key][role] = o.prices[key][role] || {};
  o.prices[key][role][size] = Number(price);
  saveOverrides(o); reload(ctx);
  return ctx.reply(`✅ Harga ${key}.${role}.${size} = ${price}`);
}

function setPayment(ctx, rest) {
  const [method, field, ...val] = rest;
  if (!method || !field || !val.length) return ctx.reply("Format: /setpayment <method> <field> <value>");
  const o = loadOverrides();
  o.payment = o.payment || { methods: {} };
  o.payment.methods[method] = { ...(o.payment.methods[method] || {}), [field]: val.join(" ") };
  saveOverrides(o); reload(ctx);
  return ctx.reply(`✅ payment.${method}.${field} = ${val.join(" ")}`);
}

function setStore(ctx, rest) {
  const [field, ...val] = rest;
  if (!field || !val.length) return ctx.reply("Format: /setstore <field> <value>");
  const o = loadOverrides();
  o.store = { ...(o.store || {}), [field]: val.join(" ") };
  saveOverrides(o); reload(ctx);
  return ctx.reply(`✅ store.${field} = ${val.join(" ")}`);
}

function announce(ctx, text) {
  if (!text) return ctx.reply("Format: /announce <teks>");
  db.addAnnouncement(text);
  return ctx.reply("✅ Pengumuman disimpan.");
}

async function broadcast(ctx, text) {
  if (!text) return ctx.reply("Format: /broadcast <teks>");
  const users = db.allUsers();
  let sent = 0, failed = 0;
  for (const u of users) {
    try {
      if (ctx.broadcast) await ctx.broadcast(u, text);
      sent++;
    } catch { failed++; }
  }
  return ctx.reply(`📣 Broadcast selesai. Sukses: ${sent}, gagal: ${failed}.`);
}

function setFitur(ctx) {
  const menuCfg = reloadRequire("../config/menu");
  const buttons = Object.keys(menuCfg.presets).map((id) => ({
    id: `admin:setfitur:${id}`,
    text: `${Number(menuCfg.activePreset) === Number(id) ? "🟢" : "⚪"} Set Fitur ${id}`
  }));
  buttons.push({ id: "m:home", text: "❌ Tutup" });
  
  // Gunakan format buttons yang didukung ctx.reply di platforms/telegram.js & whatsapp.js
  return ctx.reply("⚙ *SET FITUR MENU*\n\nSilakan pilih preset menu.", {
    buttons: buttons
  });
}

function reload(ctx) {
  // Hapus cache require utk semua config
  for (const k of Object.keys(require.cache)) {
    if (k.includes(path.sep + "config" + path.sep)) delete require.cache[k];
  }
  // Paksa reload menu.js secara eksplisit
  try {
    const menuPath = path.resolve(__dirname, "../config/menu.js");
    delete require.cache[menuPath];
  } catch (e) {}
  
  if (ctx?.reply) ctx.reply("♻️ Config direload.");
}

function backup(ctx) {
  const o = loadOverrides();
  const backup = path.join(__dirname, "..", "logs", `backup-${Date.now()}.json`);
  fs.writeFileSync(backup, JSON.stringify(o, null, 2));
  return ctx.reply(`✅ Backup: ${backup}`);
}

function setBonus(ctx, rest) {
  const [field, value] = rest;
  if (!field || value == null) return ctx.reply("Format: /setbonus <amount|cooldownHours|enabled> <nilai>");
  const o = loadOverrides();
  o.bonus = o.bonus || {};
  o.bonus[field] = field === "enabled" ? (value === "true") : Number(value);
  saveOverrides(o); reload(ctx);
  return ctx.reply(`✅ bonus.${field} = ${value}`);
}

function setBimzPrice(ctx, rest) {
  const [role, price] = rest;
  if (!role || !price) return ctx.reply("Format: /setbimzprice <user|reseller|owner> <harga>");
  const o = loadOverrides();
  o.bimzcreated = o.bimzcreated || { packages: {} };
  o.bimzcreated.packages[role] = { ...(o.bimzcreated.packages[role] || {}), price: Number(price) };
  saveOverrides(o); reload(ctx);
  return ctx.reply(`✅ bimzcreated.${role}.price = ${price}`);
}

function addBalance(ctx, rest) {
  const [platform, chatId, amount] = rest;
  if (!platform || !chatId || !amount) return ctx.reply("Format: /addbalance <platform> <chatId> <amount>");
  const bal = db.addBalance({
    platform, chatId, amount: Number(amount),
    type: "admin_adjust", note: `by admin ${ctx.chatId}`,
  });
  return ctx.reply(`✅ Saldo ${chatId}@${platform} = ${bal}`);
}

async function manualExpire(ctx) {
  const orderSvc = require("../services/order/orderService");
  const n = await orderSvc.deleteExpiredPanels();
  return ctx.reply(`✅ Auto-delete dijalankan. ${n} panel diproses.`);
}

function reloadRequire(p) {
  const abs = require.resolve(p, { paths: [__dirname] });
  delete require.cache[abs];
  return require(p);
}

module.exports = { handle, reload };
