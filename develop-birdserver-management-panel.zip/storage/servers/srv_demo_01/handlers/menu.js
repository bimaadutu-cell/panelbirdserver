// ==============================================
// MENU V3.2 — INLINE KEYBOARD + EDIT MESSAGE
// ==============================================
// - "BimzCreated" → "BimzCreated (APK CPanel)"
// - "APK Yanzz" → "APK BUG" (form-only, tanpa QRIS)
// - Semua kontak dari config/contact.js
// - Semua gambar dari config/images.js
// ==============================================
const store = require("../config/store");
const banner = require("../config/banner");
const panelCfg = require("../config/panel");
const pricesCfg = require("../config/prices");
const productsCfg = require("../config/products");
const bimzCfg = require("../config/bimzcreated");
const paymentCfg = require("../config/payment");
const bonusCfg = require("../config/bonus");
const contactCfg = require("../config/contact");
const announcementCfg = require("../config/announcement");
const images = require("../config/images");
const menuCfg = require("../config/menu");
const db = require("../database/db");
const { rupiah, fmtDate } = require("../helpers/format");

const SIZES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, "unlimited"];
const row = (...btns) => btns;

// ------- KEYBOARDS -------

function kbMain() {
  // Selalu baca ulang config/menu.js untuk memastikan perubahan realtime
  const menuPath = require.resolve("../config/menu");
  delete require.cache[menuPath];
  const dynamicMenuCfg = require("../config/menu");
  
  const currentMenu = dynamicMenuCfg.presets[dynamicMenuCfg.activePreset] || dynamicMenuCfg.presets[1];
  
  // Gunakan map untuk menghindari duplikasi dan memastikan tombol bersih sesuai preset
  const buttons = currentMenu.map(b => ({
    text: b.text,
    callback_data: b.callback_data
  }));
  
  // Tambahkan Lapor ke Admin jika tidak ada di preset
  if (!buttons.some(b => b.callback_data === "m:report")) {
    buttons.push({ text: "🚨 Lapor ke Admin", callback_data: "m:report" });
  }
  
  // Selalu tambahkan Top Up, Pengumuman, dan Pengaturan di akhir
  if (!buttons.some(b => b.callback_data === "m:topup")) buttons.push({ text: "💰 Top Up", callback_data: "m:topup" });
  if (!buttons.some(b => b.callback_data === "m:pengumuman")) buttons.push({ text: "📢 Pengumuman", callback_data: "m:pengumuman" });
  if (!buttons.some(b => b.callback_data === "m:pengaturan")) buttons.push({ text: "⚙ Pengaturan", callback_data: "m:pengaturan" });

  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
  
  return { inline_keyboard: rows };
}

function kbBack(to = "m:home") {
  return { inline_keyboard: [[{ text: "⬅ Kembali", callback_data: to }]] };
}

function kbPanelDev() {
  const rows = panelCfg.servers.map((s) => [{
    text: `${s.key === "bimz" ? "👑" : "⚡"} Order By ${s.name}`,
    callback_data: `p:srv:${s.key}`,
  }]);
  rows.push([{ text: "⬅ Kembali", callback_data: "m:home" }]);
  return { inline_keyboard: rows };
}

function kbPanelRoles(serverKey) {
  const roles = Object.keys(pricesCfg[serverKey] || {});
  // NOTE: label USER/RESELLER/OWNER HANYA muncul di menu BimzCreated.
  // Di menu Panel, kita relabel jadi Basic / Pro / Elite.
  const displayMap = { user: "🟢 Paket Basic", reseller: "🔵 Paket Pro", owner: "🟣 Paket Elite" };
  const rows = roles.map((r) => [{
    text: displayMap[r] || `• ${r.toUpperCase()}`,
    callback_data: `p:role:${serverKey}:${r}`,
  }]);
  rows.push([{ text: "⬅ Kembali", callback_data: "m:panel" }]);
  return { inline_keyboard: rows };
}

function kbPanelSizes(serverKey, role) {
  const table = pricesCfg[serverKey]?.[role] || {};
  const list = SIZES.filter((s) => table[s] != null);
  const buttons = list.map((s) => ({
    text: s === "unlimited" ? `♾ Unlimited — ${rupiah(table.unlimited)}` : `💾 ${s}GB — ${rupiah(table[s])}`,
    callback_data: `p:size:${serverKey}:${role}:${s}`,
  }));
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) rows.push(buttons.slice(i, i + 2));
  rows.push([{ text: "⬅ Kembali", callback_data: `p:srv:${serverKey}` }]);
  return { inline_keyboard: rows };
}

function kbBimz() {
  // Role USER/RESELLER/OWNER hanya di menu ini.
  const rows = Object.entries(bimzCfg.packages).map(([k, p]) => [{
    text: `${p.label} — ${rupiah(p.price)}`, callback_data: `b:pkg:${k}`,
  }]);
  rows.push([{ text: "⬅ Kembali", callback_data: "m:home" }]);
  return { inline_keyboard: rows };
}

function kbBimzDetail(role) {
  return {
    inline_keyboard: [
      [{ text: `🛒 Beli Sekarang`, callback_data: `b:buy:${role}` }],
      [{ text: "⬅ Kembali", callback_data: "m:bimz" }],
    ],
  };
}

function kbBonus() {
  return {
    inline_keyboard: [
      [{ text: "🎁 Klaim Sekarang", callback_data: "b:bonus:claim" }],
      [{ text: "⬅ Kembali", callback_data: "m:home" }],
    ],
  };
}

function kbApk() {
  // APK BUG — semua item dilabel BUG
  const cat = productsCfg.categories.find((c) => c.id === "apk_yanzz") || productsCfg.categories[0];
  const rows = cat.items.map((i) => [{
    text: `🐛 ${i.name} — ${rupiah(i.price)}`, callback_data: `a:item:${i.id}`,
  }]);
  rows.push([{ text: "⬅ Kembali", callback_data: "m:home" }]);
  return { inline_keyboard: rows };
}

// ------- TEXT VIEWS -------

function txtHome() {
  return `🏪 *BIMZ DIGITAL STORE*\n\nSelamat datang.\nSilakan pilih layanan.`;
}
function txtPanelDev() {
  return `🖥️ *ORDER PANEL PTERODACTYL*\n\nPilih Developer/Server.`;
}
function txtPanelRoles(s) {
  return `🖥️ *PANEL BY ${s.name.toUpperCase()}*\n\nPilih paket:`;
}
function txtPanelSizes(s, role) {
  const label = { user: "Basic", reseller: "Pro", owner: "Elite" }[role] || role;
  return `💾 *PAKET ${label.toUpperCase()} — ${s.name.toUpperCase()}*\n\nPilih ukuran RAM:`;
}

function txtBimzDetail(role) {
  const p = bimzCfg.packages[role];
  if (!p) return "Paket tidak ditemukan.";
  return `📱 *BIMZCREATED (APK CPANEL) — ${p.label}*\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `Harga     : *${rupiah(p.price)}*\n` +
    `Masa Aktif: ${p.masaAktif}\n` +
    `Limit     : ${p.limit}\n` +
    `Fitur:\n• ${p.features.join("\n• ")}\n` +
    `Info      : ${p.info}\n` +
    `⚠️ ${p.warning}\n` +
    `━━━━━━━━━━━━━━━━━━`;
}

function txtBonus(chatId, platform) {
  const last = db.lastBonusClaim(chatId, platform);
  const cd = (bonusCfg.cooldownHours || bonusCfg.cooldown || 24) * 3600000;
  let status = "✅ Dapat diklaim sekarang";
  if (last) {
    const remaining = (last.claimed_at + cd) - Date.now();
    if (remaining > 0) {
      const h = Math.floor(remaining / 3600000);
      const m = Math.floor((remaining % 3600000) / 60000);
      status = `⏳ Silakan kembali dalam:\n*${h} Jam ${m} Menit*`;
    }
  }
  return `🎁 *BONUS HARIAN*\n\n` +
    `Nominal  : *${rupiah(bonusCfg.amount)}*\n` +
    `Cooldown : ${bonusCfg.cooldownHours || bonusCfg.cooldown} Jam\n\n${status}`;
}
function txtBimz() {
  const lines = Object.values(bimzCfg.packages).map((p) => {
    return `\n${p.label} — *${rupiah(p.price)}*\n• Limit: ${p.limit}\n• ${p.features.join("\n• ")}`;
  }).join("\n");
  return `📱 *BIMZCREATED (APK CPANEL)*\n\n${bimzCfg.description}\n${lines}`;
}
function txtApk() {
  return `🐛 *APK BUG*\n\n` +
    `Menu ini adalah *formulir pemesanan* APK BUG.\n` +
    `Setelah mengisi form, Anda akan diarahkan menghubungi *${contactCfg.apkBug.name}* langsung via WhatsApp / Telegram.\n\n` +
    `Silakan pilih paket:`;
}
function txtTopUp() {
  const methods = Object.entries(paymentCfg.methods)
    .filter(([k, v]) => v.enabled && k !== "saldo")
    .map(([, v]) => `• ${v.label}${v.number ? ` — ${v.number} a.n ${v.name || "-"}` : ""}`)
    .join("\n");
  return `💰 *TOP UP SALDO*\n\nMetode aktif:\n${methods || "-"}\n\nHubungi admin untuk konfirmasi top up.`;
}
function txtPengumuman() {
  return `${announcementCfg.title}\n\n${announcementCfg.text || store.announcement || "Belum ada pengumuman."}`;
}
function txtSupport() {
  return `📞 *SUPPORT*\n\n` +
    `• 👤 Admin Utama\n` +
    `   WhatsApp : ${contactCfg.owner.whatsapp}\n` +
    `   Telegram : @${contactCfg.owner.telegramUsername}\n\n` +
    `• 📱 BimzCreated (APK CPanel)\n` +
    `   WhatsApp : ${contactCfg.bimzcreated.whatsapp}\n` +
    `   Telegram : @${contactCfg.bimzcreated.telegramUsername}\n\n` +
    `• 🐛 APK BUG (${contactCfg.apkBug.name})\n` +
    `   WhatsApp : ${contactCfg.apkBug.whatsapp}\n` +
    `   Telegram : @${contactCfg.apkBug.telegramUsername}`;
}
function txtPengaturan() {
  return `⚙ *PENGATURAN*\n\nUntuk mengubah preferensi order, hubungi admin.`;
}
function txtProfil(chatId, platform) {
  const u = db.getUser(chatId, platform) || {};
  const last = db.lastBonusClaim(chatId, platform);
  const cd = (bonusCfg.cooldownHours || bonusCfg.cooldown || 24) * 3600000;
  let claim = "✅ Dapat diklaim";
  if (last) {
    const remaining = (last.claimed_at + cd) - Date.now();
    if (remaining > 0) {
      const h = Math.floor(remaining / 3600000);
      const m = Math.floor((remaining % 3600000) / 60000);
      claim = `⏳ ${h}j ${m}m`;
    }
  }
  return `👤 *PROFIL*\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `Nama         : ${u.name || "-"}\n` +
    `Username     : ${u.username || "-"}\n` +
    `Status       : ${u.role || "user"}\n` +
    `Saldo        : *${rupiah(u.balance || 0)}*\n` +
    `Bergabung    : ${u.created_at ? fmtDate(u.created_at) : "-"}\n` +
    `Total Order  : ${u.total_order || 0}\n` +
    `Bonus Harian : ${rupiah(bonusCfg.amount)} / ${bonusCfg.cooldownHours || bonusCfg.cooldown}j\n` +
    `Status Claim : ${claim}\n` +
    `━━━━━━━━━━━━━━━━━━`;
}
function txtRiwayat(chatId) {
  const rows = db.ordersByChat(chatId, 10);
  if (!rows.length) return `📜 *RIWAYAT*\n\nBelum ada order.`;
  const lines = rows.map((r) =>
    `• \`${r.id}\` — ${r.type.toUpperCase()} — ${rupiah(r.amount)} — *${r.status.toUpperCase()}*`
  );
  return `📜 *RIWAYAT ORDER*\n\n${lines.join("\n")}`;
}

// ---- Halaman gambar untuk menu (dipakai platforms/telegram.js) ----
const menuImages = {
  home: images.welcome,
  bimz: images.bimzcreated,
  apk: images.apkbug,
  bonus: images.bonus,
  profil: images.profile,
  pengumuman: images.announcement,
  panel: images.banner,
};

module.exports = {
  kbMain, kbBack, kbPanelDev, kbPanelRoles, kbPanelSizes, kbBimz, kbBimzDetail, kbApk, kbBonus,
  txtHome, txtPanelDev, txtPanelRoles, txtPanelSizes, txtBimz, txtBimzDetail, txtApk,
  txtTopUp, txtBonus, txtPengumuman, txtSupport, txtPengaturan, txtProfil, txtRiwayat,
  menuImages, SIZES,
};
