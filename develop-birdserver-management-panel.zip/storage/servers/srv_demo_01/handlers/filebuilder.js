// ==============================================
// HANDLER FILEBOTBUILD (V5 — PROGRESS TEXT BERURUTAN)
// ==============================================
// Progress bot mengedit pesan yang sama dengan urutan tahap
// (bukan hanya persen loading).
// ==============================================
const fs = require("fs");
const db = require("../database/db");
const images = require("../config/images");
const fbCfg = require("../config/filebuilder");
const { listBuilders } = require("../services/filebuilder/multiBuilder");
const builder = require("../services/filebuilder/builder");

function platformButtons() {
  const keys = Object.keys(fbCfg.platforms);
  return keys.map((k) => ({ id: `fbb:plat:${k}`, text: fbCfg.platforms[k].label }))
             .concat([{ id: "m:home", text: "⬅ Batalkan" }]);
}

function activeBuildersSummary() {
  const all = listBuilders();
  const ready = all.filter((b) => b.ready);
  if (!ready.length) return "⚠️ Belum ada builder aktif — isi API Key di config/providers.js";
  return ready.map((b, i) => `${i + 1}. ${b.label}`).join("\n");
}

async function openPicker(ctx) {
  if (!fbCfg.enabled) return ctx.reply("⚠️ FileBotBuild sedang dinonaktifkan.");
  await db.setSession(ctx.chatId, ctx.platform, { step: "fbb:pick" });
  const img = images.banner && fs.existsSync(images.banner() || "") ? images.banner() : null;
  const builderList = activeBuildersSummary();
  return ctx.reply(
    `📦 *FILEBOTBUILD V5 — Multi AI Builder*\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `Buat *source code* bot lengkap secara otomatis.\n` +
    `Input ide hingga *${(fbCfg.maxIdeaWords || 100000).toLocaleString("id-ID")} kata*.\n\n` +
    `🤖 *Provider Aktif:*\n${builderList}\n\n` +
    `1. Pilih platform target\n` +
    `2. Jelaskan ide bot\n` +
    `3. AI generate & kirim file .zip\n` +
    `━━━━━━━━━━━━━━━━━━`,
    { buttons: platformButtons(), image: img },
  );
}

async function pickPlatform(ctx, platform) {
  if (!fbCfg.platforms[platform]) return ctx.reply("Platform tidak dikenali.");
  await db.setSession(ctx.chatId, ctx.platform, { step: "fbb:describe", platform });
  return ctx.reply(
    `✏️ *Deskripsikan bot yang ingin dibuat*\n` +
    `Target: *${fbCfg.platforms[platform].label}*\n\n` +
    `Kirim deskripsi (10 karakter – ${(fbCfg.maxIdeaWords || 100000).toLocaleString("id-ID")} kata).\n` +
    `Ketik *batal* untuk membatalkan.`,
  );
}

async function confirmIdea(ctx, session) {
  const idea = (ctx.text || "").trim();
  const err = builder.validateIdea(idea);
  if (err) return ctx.reply(`❌ ${err}`);
  await db.setSession(ctx.chatId, ctx.platform, {
    step: "fbb:confirm", platform: session.platform, idea,
  });
  const preview = idea.length > 300 ? idea.slice(0, 300) + "..." : idea;
  return ctx.reply(
    `📋 *KONFIRMASI IDE*\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `Platform : ${fbCfg.platforms[session.platform].label}\n` +
    `Panjang  : ${idea.length.toLocaleString("id-ID")} karakter\n` +
    `Ide      : ${preview}\n` +
    `━━━━━━━━━━━━━━━━━━\n\n` +
    `Bot akan mencoba setiap provider secara otomatis (retry + fallback).\n` +
    `Lanjutkan build?`,
    { buttons: [
      { id: "fbb:confirm", text: "✅ Ya, Build Sekarang" },
      { id: "fbb:cancel",  text: "❌ Batalkan" },
    ] },
  );
}

async function runBuild(ctx, session) {
  await db.setSession(ctx.chatId, ctx.platform, {
    step: "fbb:building", platform: session.platform, idea: session.idea,
  });

  const HEADER = "⚙️ *FILEBOTBUILD V5 — Multi AI Builder*";
  const steps = [];
  let progressMsg = null;

  function render() {
    return HEADER + "\n━━━━━━━━━━━━━━━━━━\n" + steps.slice(-9).join("\n");
  }

  try {
    progressMsg = await ctx.reply(HEADER + "\n━━━━━━━━━━━━━━━━━━\n⏳ Memulai...");
  } catch { progressMsg = null; }

  async function onStep(label) {
    steps.push(label);
    const text = render();
    if (ctx.editMessage && progressMsg?.message_id) {
      await ctx.editMessage(progressMsg.message_id, text).catch(() => {});
    } else {
      await ctx.reply(text).catch(() => {});
    }
  }

  try {
    const { zipPath, projectName, fileCount, builderUsed, model, chunkCount } = await builder.build({
      platform: session.platform,
      idea: session.idea,
      onStep,
    });

    await ctx.reply(
      `✅ *BUILD SELESAI*\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `Nama     : \`${projectName}\`\n` +
      `Platform : ${fbCfg.platforms[session.platform].label}\n` +
      `Provider : ${builderUsed || "AI"}\n` +
      `Model    : ${model || "-"}\n` +
      `Chunk    : ${chunkCount || 1}\n` +
      `File     : ${fileCount} file\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `📦 Mengirim file ZIP...`,
    );

    if (ctx.sendDocument) {
      await ctx.sendDocument(zipPath, `${projectName}.zip`);
    } else {
      await ctx.reply(`ZIP tersimpan di: ${zipPath}`);
    }

    // Bersihkan ZIP setelah 10 menit
    setTimeout(() => { try { fs.unlinkSync(zipPath); } catch {} }, 10 * 60 * 1000);
  } catch (e) {
    await ctx.reply(
      `❌ *Build gagal*\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `${e.message}\n\n` +
      `Cek log detail di \`logs/ai-build.log\`.\n` +
      `Perbaiki konfigurasi di \`config/providers.js\`.`,
    );
  } finally {
    await db.setSession(ctx.chatId, ctx.platform, null);
  }
}

async function handleCallback(ctx, cb, session) {
  if (cb === "fbb:open")   return openPicker(ctx);
  if (cb === "fbb:cancel") {
    await db.setSession(ctx.chatId, ctx.platform, null);
    return ctx.reply("❌ FileBotBuild dibatalkan.");
  }
  if (cb.startsWith("fbb:plat:")) return pickPlatform(ctx, cb.split(":")[2]);
  if (cb === "fbb:confirm") {
    if (!session || session.step !== "fbb:confirm") return ctx.reply("Sesi tidak ditemukan.");
    return runBuild(ctx, session);
  }
  return false;
}

module.exports = { openPicker, confirmIdea, handleCallback };
